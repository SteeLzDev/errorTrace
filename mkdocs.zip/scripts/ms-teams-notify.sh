#!/bin/bash
# Get the options
parse_args() {
    case "$1" in
        "--app"|"-a")
            APPNAME="$2"
            ;;
        "--env"|"-e")
            APPENV="$2"
            ;;
        "--stat"|"-s")
            STATUS="$2"
            ;;
        *)
            echo "Argumento Invalido '$1'." 1>&2
            exit 1
            ;;
    esac
}

while [[ "$#" -ge 2 ]]; do
    parse_args "$1" "$2"
    shift; shift
done

echo -e "\nDisparando aviso de deploy $APPNAME em $APPENV no Microsoft Teams\n"
export http_proxy=http://spobrproxy.serasa.intranet:3128
export https_proxy=http://spobrproxy.serasa.intranet:3128
curl --silent --header 'Content-Type:application/json' --data '{"title":"JENKINS","text":"Deploy no ambiente de '$APPENV' **'$STATUS'** - **'$APPNAME'**"}' https://experian.webhook.office.com/webhookb2/6e0f77c9-8042-49b0-becb-51757493de52@be67623c-1932-42a6-9d24-6c359fe5ea71/IncomingWebhook/c449eb93ebd74850bfcd46cd97d04024/3368a3ec-61cb-40ee-a4b6-db3d0b039aac