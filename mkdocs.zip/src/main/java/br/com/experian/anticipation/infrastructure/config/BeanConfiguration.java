package br.com.experian.anticipation.infrastructure.config;

import br.com.experian.anticipation.domain.client.AccountClient;
import br.com.experian.anticipation.domain.client.OnboardingClient;
import br.com.experian.anticipation.domain.client.RegistrationClient;
import br.com.experian.anticipation.domain.repository.AgreementRepository;
import br.com.experian.anticipation.domain.service.OnboardingService;
import br.com.experian.anticipation.domain.service.impl.OnboardingServiceImpl;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
public class BeanConfiguration {

    @Bean
    public OnboardingService onboardingService(@Value("${api.onboarding.capital-source.document}") String capitalSourceDocument,
                                               @Value("${api.onboarding.capital-source.redirect}") String capitalSourceRedirect,
                                               OnboardingClient onboardingClient,
                                               AccountClient accountClient,
                                               RegistrationClient registrationClient,
                                               AgreementRepository agreementRepository) {
        return new OnboardingServiceImpl(capitalSourceDocument, capitalSourceRedirect, onboardingClient, accountClient, registrationClient, agreementRepository);
    }
}