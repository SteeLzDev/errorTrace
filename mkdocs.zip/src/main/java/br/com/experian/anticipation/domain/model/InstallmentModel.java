package br.com.experian.anticipation.domain.model;


import br.com.experian.anticipation.domain.constant.PaymentType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InstallmentModel {

    private Integer count;
    private Integer number;
    private BigDecimal amount;
    private PaymentType paymentType;
    private BigDecimal discount;
}
