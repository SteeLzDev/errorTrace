package br.com.experian.anticipation.infrastructure.repository.document;

import br.com.experian.anticipation.domain.model.Agreement;
import lombok.Builder;
import lombok.Getter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

@Builder
@Getter
@Document(collection = "Agreement")
public class AgreementDocument {
    @Id
    private String id;
    private String userId;
    private String businessId;
    private String nationalRegistrationId;
    private Agreement.Status status;
    private int version;
    private String url;
    private LocalDateTime acceptedAt;
    private LocalDateTime revokedAt;
    private LocalDateTime updatedAt;
}