package br.com.experian.anticipation.domain.dto.response;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class BusinessRegistration {
    private String companyName;
    private String companyAlias;
    private String nationalRegistrationId;
    private String phoneNumber;
    private Address address;

    @Getter
    @Builder
    public static class Address {
        private String street;
        private String number;
        private String complement;
        private String neighborhood;
        private String city;
        private String state;
        private String zipCode;
        private String country;
    }
}