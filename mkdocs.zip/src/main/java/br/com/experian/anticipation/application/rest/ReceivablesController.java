package br.com.experian.anticipation.application.rest;

import br.com.experian.anticipation.application.mapper.ReceivablesResponseMapper;
import br.com.experian.anticipation.domain.dto.response.ReceivablesResponseDto;
import br.com.experian.anticipation.domain.model.ReceivablesModel;
import br.com.experian.anticipation.domain.service.ReceivablesService;
import br.com.experian.observability.annotation.LogMethod;
import br.com.experian.swagger.anticipation.api.ReceivablesApi;
import br.com.experian.swagger.anticipation.model.PaginationTO;
import br.com.experian.swagger.anticipation.model.ReceivableGroupedResponseTO;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.Collections;
import java.util.Optional;


@RestController
public class ReceivablesController extends  BaseController implements ReceivablesApi {

    private final ReceivablesService receivablesService;
    private final HttpServletRequest request;

    public ReceivablesController(ReceivablesService receivablesService, HttpServletRequest request) {
        this.receivablesService = receivablesService;
        this.request = request;
    }

    @Override
    @PreAuthorize(HAS_RULES)
    @LogMethod(LogMethod.LogType.FULL)
    public ResponseEntity<ReceivableGroupedResponseTO> findAvailables(LocalDate date, Integer limit, Integer offset) {
        final String supplierDocument = extractSupplierDocument();

        final int pageLimit = limit != null ? limit : 10;
        final int pageOffset = offset != null ? offset : 1;

        Optional<ReceivablesResponseDto> receivablesOptional = receivablesService.getReceivables(supplierDocument, pageLimit, pageOffset);
                if(receivablesOptional.isEmpty()) {
                    return ResponseEntity.ok(createEmptyGroupedResponseTO());
                }
                ReceivablesModel receivablesModel = receivablesOptional.get().getReceivables();

        ReceivableGroupedResponseTO response = ReceivablesResponseMapper.toGroupedResponseTO(receivablesModel);
                return ResponseEntity.ok(response);
        }



    private String extractSupplierDocument() {
        String header = request.getHeader("X-Supplier-Document");
        if (header != null && !header.isBlank()) {
            return header.trim();
        }
        throw new IllegalArgumentException("Supplier document is required (header X-Supplier-Document)");
    }

    private ReceivableGroupedResponseTO createEmptyGroupedResponseTO() {
        PaginationTO emptyPagination = new PaginationTO()
                .size(10)
                .totalElements(0)
                .totalPages(0)
                .number(0);

        return new ReceivableGroupedResponseTO()
                .content(Collections.emptyList())
                .page(emptyPagination);
    }
}
