package br.com.experian.anticipation.domain.client;

import br.com.experian.anticipation.domain.constant.OnboardingStatus;

public interface OnboardingClient {

    OnboardingStatus getStatus(String supplierDocument);

}