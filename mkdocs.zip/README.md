# Application name

![tribe](https://img.shields.io/badge/tribe-My_Tribe-yellow)
![squad](https://img.shields.io/badge/squad-My_squad-orange)
![version](https://img.shields.io/badge/version-0.0.1-blue)
[![Java Version](https://img.shields.io/badge/java-21-green)](https://openjdk.java.net/projects/jdk/21)
[![Spring Boot Version](https://img.shields.io/badge/spring-3.1.11-green)](https://spring.io/projects/spring-boot)
![Application type](https://img.shields.io/badge/Application_type-Rest_Api-purple)

---

# 1 Solution Briefing (What is this?)
<!-- TODO: Descreva aqui um breve texto sobre sua aplição ou produto -->

## 1.1 Stakeholders
<!-- TODO: Quem são as partes interessadas (product owners, gerentes) envolvidos no desenvolvimento do produto -->

Quem       | Papel                 | Descrição  
:--------: | :-------------------: | :--------------------:
Fulano     | Engenheiro de dados   | PO

## 1.2 Customer Data (VIP/Not-VIP)
<!-- TODO - Quem são os clientes que o utilizam? São VIP? Quais? -->

## 1.3 SLA/SLOs
<!-- TODO - - Qual é o SLA e SLO acordados com o cliente e stakeholders? Qual é o percentual de disponibilidade do serviço acordado com Cliente e Serasa? -->
Ex:

SLAs/SLOs Acordados | Tempo de Resposta (Xseconds) | Timeout (Xseconds) 
:-----------------: | :--------------------------: | :--------------------:
api/cliente         | 5s                           | 60s

## 1.4 Plataform (Cloud, Open, Mainframe)
<!-- TODO - Que tipo de plataforma o produto/sistemaestá sendo executado?-->

- [ ] Cloud
- [x] Open
- [x] Mainframe

## 1.5 Access Media
<!-- TODO - Qual é o meio de acesso que o(s) cliente(s) consome(m) esse produto? Via website, via api, via string, via webservice, via app -->

- [ ] Site
- [X] Rest Api
- [ ] WebService
- [ ] Socket
- [ ] Websphere MQ
- [ ] Host a Host

## 1.6 Business Stream
<!-- TODO - Como é fluxo de negócio que esse produto é utilizado? Que tipo de impacto tem para o negócio, durante uma falha desse produto? O que o cliente não consegue consumir? -->
Ex: Para consumir o produto,o cliente deverá acessar o Menu de Produtos, e através do “Menu Certificado Digital” ele poderealizar a compra de seu certificado.

## 1.7 Capacity
<!-- TODO - Revisitar as aplicações e infraestrutura desse produto, para garantir que há recurso suficiente para a demanda esperada. Qual é a demanda máxima que esse produto pode receber? Para aplicações em Cloud vale reavaliar se há opção de auto scalling. -->

## 1.8 Environment (UAT & PROD)
<!-- TODO - Há ambiente de UAT, DEV, PROD? Quais são os componentes de cada um? -->

# 2 Monitoring
<!-- TODO - Trazer as informações de app e arquitetura para inserirmos nos sistemas, dentro de cada premissa abaixo, exceto 2.6: -->

## 2.1 Availability
<!-- TODO - Monitorar a disponibilidade dos serviços e infra do produto. -->

## 2.2 Performance
<!-- TODO - Monitorar a performance dos serviços do produto. -->

## 2.3 Business View
<!-- TODO - Monitorar o fluxo de negócio do produto. -->

## 2.4 Syntethic
<!-- TODO - Simular através de ferramentas a percepção/jornada dos usuáriosdurante a utilização do produto. -->

## 2.6 Golden Signals
<!-- TODO - Principais informações para contribuir com a análise das métricas acima de disponibilidade, performance etc. (Direcionar a análise do time N1) -->

## 3 App Details

## 3.1 Solution Design
<!-- TODO - Arquitetura completa da solução (podendo conter no desenho componentes administrados por outras BU’s). É de extrema importância nos trazer app ids, nomes detalhados das aplicações). -->

<br /> <!-- architecture-as-code -->
    <div align="center">
        <img src="architecture-as-code/head.png" alt="Architecture as Code" align="center"/>
    </div>
<br /> <!-- architecture-as-code -->

## 3.2 System Users
<!-- TODO - Usuários sistêmicos utilizados na arquitetura, user de DB, AWS ID Accountetc. -->

Nome       | Descrição
:--------: | :--------------------------:
usr_eu     | Responsável por ser eu

## 3.3 Return Code and Actions
<!-- TODO -  Códigos de Resposta das aplicações (principalmente se houver códigos customizados para regra de negócio). -->

Return Code   | Descrição 
:-----------: | :--------------------------:
200           | Tudo lindo no parquinho

*Ou*

<!-- TODO - Documente o endpoint do swagger da api e evite ter que criar a tabela -->

Api           | Descrição 
:-----------: | :--------------------------:
experian-xpto | [Swagger Endpoint](URL_DO_ENDPOINT_SWAGGER_APP)

## 3.4 ITSM (Sustain Process)
<!-- TODO - Processo de sustentação (com horário de atuação e escala de plantão no Confluence). -->

# 4 Escalation Matrix

## 4.1 Escalation Matrix
<!-- TODO - Matriz de escalonamento caso o processo de sustentação não funcione, quem são os respectivos superiores responsáveis para acionamento durante uma ocorrência. -->

Quem        | Contato           | E-mail  
:---------: | :---------------: | :--------------------: 
Fulano      | +55 11 99999-9999 | fulano@br.experian.com

## Handover & Observability Definition

[Learn More](https://pages.experian.com/pages/viewpage.action?pageId=1081613344)

> Observações - *Se você não tiver algum campo escreva não se aplica*