package br.com.experian.anticipation.domain.enums;

public enum OnboardingStatus {

    STARTED("Iniciado"),
    REVIEW("Em revisão"),
    PENDING("Pendente"),
    APPROVED("Aprovado"),
    REJECTED("Rejeitado");


    private final String description;

    OnboardingStatus(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
}
