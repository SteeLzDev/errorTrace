package br.com.experian.anticipation.domain.service;

import br.com.experian.anticipation.domain.dto.response.OnboardingStatusResponseDto;

import java.util.Optional;

public interface OnboardingService {

    Optional<OnboardingStatusResponseDto>getOnboardingStatus(String supplierDocument);





}
