package br.com.experian.anticipation.infrastructure.integration.feign.client.antecipa;

import br.com.experian.anticipation.domain.dto.response.ReceivablesResponseDto;
import br.com.experian.anticipation.domain.model.ReceivablesModel;
import br.com.experian.anticipation.domain.port.ReceivablesPort;
import br.com.experian.anticipation.domain.service.ReceivablesService;
import br.com.experian.observability.annotation.LogMethod;
import lombok.extern.log4j.Log4j2;

import java.util.Optional;

@Log4j2
public class ReceivablesServiceImpl implements ReceivablesService {

    private final ReceivablesPort receivablesPort;

    public ReceivablesServiceImpl(ReceivablesPort receivablesPort) {
        this.receivablesPort = receivablesPort;
    }

    @Override
    @LogMethod
    public Optional<ReceivablesResponseDto> getReceivables(String supplierDocument, Integer limit, Integer offset) {
        log.info("Getting receivables for supplier document: {} with limit: {} and offset: {} ",
                supplierDocument, limit, offset);

        Optional<ReceivablesModel> receivablesModel = receivablesPort.getReceivables(supplierDocument, limit, offset);

        if (receivablesModel.isEmpty()) {
            log.info("No Receivables found for supplier document: {}", supplierDocument);
            return Optional.empty();
        }

        log.info("Successfully retrieved receivables for supplier document: {}", supplierDocument);

        return Optional.of(new ReceivablesResponseDto(receivablesModel.get()));
    }

}
