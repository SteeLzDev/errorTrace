package br.com.experian.anticipation.infrastructure.integration.feign.client.antecipa;


import br.com.experian.anticipation.domain.dto.response.OnboardingStatusResponseDto;
import br.com.experian.anticipation.domain.enums.OnboardingStatus;
import br.com.experian.anticipation.domain.port.OnboardingPort;
import br.com.experian.anticipation.domain.service.OnboardingService;
import br.com.experian.observability.annotation.LogMethod;
import lombok.extern.log4j.Log4j2;


import java.util.Optional;

@Log4j2
public class OnboardingServiceImpl implements OnboardingService {


    private final OnboardingPort onboardingPort;

    public OnboardingServiceImpl(OnboardingPort onboardingPort) {
        this.onboardingPort = onboardingPort;
    }

    @Override
    @LogMethod()
    public Optional<OnboardingStatusResponseDto> getOnboardingStatus(String supplierDocument) {

        OnboardingStatus apiStatus = onboardingPort.getOnboardingStatus(supplierDocument);

        if (apiStatus == null) {
            log.info("API return 204 (no content) for document: {}", supplierDocument);
            return Optional.empty();
        }

        return Optional.of(new OnboardingStatusResponseDto(apiStatus));


    }
}
