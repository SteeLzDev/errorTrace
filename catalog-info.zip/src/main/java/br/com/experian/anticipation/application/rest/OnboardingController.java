package br.com.experian.anticipation.application.rest;

import br.com.experian.anticipation.domain.dto.response.OnboardingStatusResponseDto;
import br.com.experian.anticipation.domain.enums.OnboardingStatus;
import br.com.experian.anticipation.domain.service.OnboardingService;
import br.com.experian.observability.annotation.LogMethod;
import br.com.experian.swagger.anticipation.api.OnboardingApi;
import br.com.experian.swagger.anticipation.model.OnboardingResponseTO;
import br.com.experian.swagger.anticipation.model.OnboardingStatusTO;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
public class OnboardingController extends BaseController implements OnboardingApi {


    private final OnboardingService onboardingService;
    private final HttpServletRequest request;


    public OnboardingController(OnboardingService onboardingService, HttpServletRequest request) {
        this.onboardingService = onboardingService;
        this.request = request;
    }

    @Override
    @PreAuthorize(HAS_RULES)
    @LogMethod(LogMethod.LogType.FULL)
    public ResponseEntity<OnboardingResponseTO> retrieveStatus () {
        final String supplierDocument = extractSupplierDocument();

        Optional<OnboardingStatusResponseDto> opt = onboardingService.getOnboardingStatus(supplierDocument);

        if (opt.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        OnboardingStatus status = opt.get().getStatus();
        OnboardingResponseTO body = new OnboardingResponseTO().status(OnboardingStatusTO.fromValue(status.name()));
        return ResponseEntity.ok(body);

    }
    @Override
    @PreAuthorize(HAS_RULES)
    @LogMethod(LogMethod.LogType.FULL)
    public ResponseEntity<Void> accept () {
        return ResponseEntity.noContent().build();
    }


    private String extractSupplierDocument() {
        String header = request.getHeader("X-Supplier-Document");
        if (header != null && !header.isBlank())
            return header.trim();

        throw new IllegalArgumentException("Supplier document is required (header X-SupplierDocument)");
    }
}
