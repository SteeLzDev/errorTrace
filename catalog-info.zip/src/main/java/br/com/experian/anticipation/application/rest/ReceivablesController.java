package br.com.experian.anticipation.application.rest;

import br.com.experian.anticipation.application.adapter.ReceivablesMapper;
import br.com.experian.anticipation.domain.dto.response.ReceivablesResponseDto;
import br.com.experian.anticipation.domain.model.ReceivablesModel;
import br.com.experian.anticipation.domain.service.ReceivablesService;
import br.com.experian.observability.annotation.LogMethod;
import br.com.experian.swagger.anticipation.api.ReceivablesApi;
import br.com.experian.swagger.anticipation.model.PaginationTO;
import br.com.experian.swagger.anticipation.model.ReceivableResponseTO;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.Collections;
import java.util.Optional;
import java.util.stream.Collectors;


@RestController
public class ReceivablesController extends  BaseController implements ReceivablesApi {

    private final ReceivablesService receivablesService;
    private final HttpServletRequest request;

    public ReceivablesController(ReceivablesService receivablesService, HttpServletRequest request) {
        this.receivablesService = receivablesService;
        this.request = request;
    }

    @Override
    @PreAuthorize(HAS_RULES)
    @LogMethod(LogMethod.LogType.FULL)
    public ResponseEntity<ReceivableResponseTO> findAvailables(LocalDate date, Integer limit, Integer offset) {
        final String supplierDocument = extractSupplierDocument();

        final int pageLimit = limit != null ? limit : 10;
        final int pageOffset = offset != null ? offset : 0;

        Optional<ReceivablesResponseDto> receivablesOptional = receivablesService.getReceivables(supplierDocument, pageLimit, pageOffset);
                if(receivablesOptional.isEmpty()) {
                    return ResponseEntity.ok(createEmptyResponse());
                }
                ReceivablesModel receivablesModel = receivablesOptional.get().getReceivables();

                ReceivableResponseTO response = ReceivablesMapper.toReceivableResponse(receivablesModel);
                return ResponseEntity.ok(response);
        }


    private String extractSupplierDocument() {
        String header = request.getHeader("X-Supplier-Document");
        if (header != null && !header.isBlank()) {
            return header.trim();
        }
        throw new IllegalArgumentException("Supplier document is required (header X-Supplier-Document)");
    }

    private ReceivableResponseTO createEmptyResponse() {
        ReceivableResponseTO response = new ReceivableResponseTO();
        response.setContent(Collections.emptyList());

        PaginationTO page = new PaginationTO();
        page.setSize(10);
        page.setTotalElements(0);
        page.setTotalPages(0);
        page.setNumber(1);
        response.setPage(page);

        return response;
    }
}
