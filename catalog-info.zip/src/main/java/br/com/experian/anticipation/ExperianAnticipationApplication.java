package br.com.experian.anticipation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"br.com.experian"})
@EnableFeignClients(basePackages = {"br.com.experian"})
public class ExperianAnticipationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExperianAnticipationApplication.class, args);
	}
}