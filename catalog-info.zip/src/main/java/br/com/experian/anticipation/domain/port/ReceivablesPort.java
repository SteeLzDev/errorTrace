package br.com.experian.anticipation.domain.port;

import br.com.experian.anticipation.domain.model.ReceivablesModel;

import java.util.Optional;

public interface ReceivablesPort {


    Optional<ReceivablesModel> getReceivables (String supplierDocument, Integer limit, Integer offset);
}
