package br.com.experian.anticipation.application.rest;

import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("/serasaempreendedor/receivables-anticipation/v1")
public abstract class BaseController {

    protected static final String HAS_RULES =
                    "hasRole('USER') AND " +
                    "hasRole('PERSON') AND " +
                    "hasRole('BUSINESS') AND " +
                    "hasRole('AUTH-BASIC') AND " +
                    "hasRole('CLI-1STPARTY') AND " +
                    "hasRole('CLI-AUTH-IDENTIFIED')";

}

