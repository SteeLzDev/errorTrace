package br.com.experian.anticipation.infrastructure.repository.adapter;

import br.com.experian.swagger.antecipa.model.AntecipaSupplierRegistrationDto;
import br.com.experian.anticipation.domain.enums.OnboardingStatus;
import br.com.experian.anticipation.domain.exception.FailedDependecyException;
import br.com.experian.anticipation.domain.port.OnboardingPort;
import br.com.experian.anticipation.domain.port.AuthenticationPort;
import br.com.experian.anticipation.infrastructure.integration.feign.client.antecipa.AntecipaClient;
import feign.FeignException;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Log4j2
@Component
public class OnboardingAdapter implements OnboardingPort {

    private static final String FAILED_DEPENDENCY_MESSAGE = "Failure in communication with the onboarding service.";

    private final AntecipaClient antecipaClient;
    private final AuthenticationPort authenticationPort;
    private final String defaultCapitalSourceDocument;



    public OnboardingAdapter(AntecipaClient antecipaClient, AuthenticationPort authenticationPort,
                             @Value("${api.antecipa.default-capital-source}") String defaultCapitalSourceDocument) {
        this.antecipaClient = antecipaClient;
        this.authenticationPort = authenticationPort;
        this.defaultCapitalSourceDocument = defaultCapitalSourceDocument;
    }

    @Override
    @Retry(name = "AntecipaClient")
    public OnboardingStatus getOnboardingStatus(String supplierDocument) {
        try {
            log.info("Consulting onboarding status in the API for document: {}", supplierDocument);

            //Obter token válido
            String bearerToken = "Bearer " + authenticationPort.getValidToken();
            log.debug("Token obtained for authentication");

            AntecipaSupplierRegistrationDto supplierRegistration = antecipaClient.getSupplierRegistration(
                    bearerToken,
                    defaultCapitalSourceDocument,
                    supplierDocument
            );

            if(supplierRegistration == null) {
                log.info("API returned null there is no record for document:{} ", supplierDocument);
                return null;
            }

            String statusString = supplierRegistration.getStatus();
            Integer statusId = supplierRegistration.getStatusId();

            OnboardingStatus mappedStatus = mapApiStatusToEnum(statusString, statusId);

            log.info("Status obtained from the API: '{}' (ID: {}) -> Mapped to: {} for document: {}",
            statusString,
            statusId,
            mappedStatus,
            supplierDocument);

            return mappedStatus;

        } catch (FeignException e) {
            log.error("Error querying onboarding status for API. Status: {}, Body: {}",
                    e.status(), e.contentUTF8(), e);

            if(e.status() == 401) {
                log.info("Invalid token, trying to renew...");
                authenticationPort.refreshToken();
                throw new FailedDependecyException("Invalid authentication token", e);
            }

            if (e.status() == 404 || e.status() == 204) {
                log.info("Supplier not found in the API - there is no onboarding for document: {}", supplierDocument);

                return null;
            }
            throw new FailedDependecyException(FAILED_DEPENDENCY_MESSAGE, e);
        }
    }

    private OnboardingStatus mapApiStatusToEnum(String status, Integer statusId) {
        log.debug("Mapped API status with ID: '{}' with ID: {}", status, statusId);

        //priorizar mapeamento por statusId
        if (statusId != null) {
            switch (statusId) {
                case 1:
                    return OnboardingStatus.APPROVED; //Active
                case 2:
                    return OnboardingStatus.PENDING; //Pending
                case 3:
                    return OnboardingStatus.REJECTED; //Inactive
                case 4:
                    return OnboardingStatus.STARTED; //InAnalysis
                case 5:
                    return OnboardingStatus.REVIEW; //InReview
                default:
                    log.warn("Unknown ID Status: {}, trying map by string", statusId);
            }
        }

            log.warn("Unable to map status: '{}' (ID: {}). Using PENDING as default.", status, statusId);
            return OnboardingStatus.PENDING;
        }
    }
