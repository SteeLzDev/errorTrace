package br.com.experian.anticipation.application.adapter;


import br.com.experian.anticipation.domain.enums.PaymentType;
import br.com.experian.anticipation.domain.model.*;
import br.com.experian.swagger.anticipation.model.*;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ReceivablesMapper {

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public static ReceivableResponseTO toReceivableResponse(ReceivablesModel receivables) {
        if (receivables == null) {
            return null;
        }
        List<ReceivableDataTO> content = receivables.getGroups().stream()
                .flatMap(group -> group.getReceivables().stream())
                .map(ReceivablesMapper::mapToReceivableData)
                .collect(Collectors.toList());

        PaginationTO pagination = mapToPagination(receivables.getPage());

        return new ReceivableResponseTO()
                .content(content)
                .page(pagination);
    }

    private static ReceivableDataTO mapToReceivableData(ReceivableModel model) {
        return new ReceivableDataTO()
                .id(model.getId())
                .paymentDate(model.getPaymentDate() != null ? model.getPaymentDate().format(DATE_FORMATTER) : null)
                .nationalRegistrationId(model.getNationalRegistrationId())
                .accreditingInstitutionName(model.getAccreditingInstitutionName())
                .paymentType(mapToPaymentTypeTO(model.getPaymentType()))
                .installment(mapToInstallmentData(model.getInstallment()))
                .discount(model.getDiscount())
                .amountToReceive(model.getAmountToReceive());
    }

    private static PaymentTypeTO mapToPaymentTypeTO(PaymentType paymentType) {
        if (paymentType == null) {
            return null;
        }
        switch (paymentType) {
            case CREDIT_SINGLE:
                return PaymentTypeTO.CREDIT_SINGLE;
            case CREDIT_INSTALLMENT:
                return PaymentTypeTO.CREDIT_INSTALLMENT;
            default:
                throw new IllegalArgumentException("Unknown  PaymentType: " + paymentType);
        }
    }

    private static InstallmentDataTO mapToInstallmentData(InstallmentModel model) {
        if (model == null) {
            return null;
        }
        return new InstallmentDataTO()
                .count(model.getCount())
                .number(model.getNumber())
                .amount(model.getAmount());
    }

    private static PaginationTO mapToPagination(PaginationModel model) {
        return new PaginationTO()
                .size(model.getSize())
                .totalElements(model.getTotalElements().intValue())
                .totalPages(model.getTotalPages())
                .number(model.getNumber());
    }


}
