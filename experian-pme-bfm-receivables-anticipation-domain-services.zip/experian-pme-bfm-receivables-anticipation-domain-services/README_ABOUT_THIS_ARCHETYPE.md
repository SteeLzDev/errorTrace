# Java Rest Archetype
## Intro

Bem-vindo à documentação do nosso archetype padrão Java REST Spring Boot! 
Se você está aqui, é porque provavelmente está em busca de uma maneira fácil e rápida de iniciar um projeto Java com RESTful 
APIs usando Spring Boot. E adivinhe? Você veio ao lugar certo!

Nosso Archetype é como aquela receita infalível de bolo da sua avó: prático, eficiente e já testado mil vezes. Criamos 
este projeto padrão para poupar seu tempo, garantindo que você possa focar no que realmente importa - desenvolver soluções 
incríveis e inovadoras.

Aqui você vai encontrar todas as informações necessárias para configurar e usar nosso Archetype.

Além de toda a estrutura básica, aqui você também encontrará pequenos exemplos de como utilizar facilidades no seu dia a 
dia. Para isso, incluímos uma mini aplicação de demonstração que é totalmente funcional. Essa aplicação já vem com alguns 
endpoints prontos, utilizando bibliotecas internas que vão facilitar sua vida. Com ela, você conhecerá algumas das soluções
que já temos internamente e verá como aplicá-las de forma prática.

Nossa intenção é que esta mini aplicação funcione como um guia inicial, ajudando você a continuar o trabalho a partir de
uma base sólida e bem estruturada. Assim, você poderá explorar e adaptar as funcionalidades conforme suas necessidades, 
sem ter que começar do zero.

Então, pegue seu café, acomode-se na cadeira e vamos começar essa jornada juntos. Estamos animados para ver o que você 
vai construir!

### Buzz Aldrin API 

A nossa mini aplicação integrada ao Archetype é uma API é inspirada no astronauta Buzz Aldrin e na missão Apollo 11. 
Esta API fornece três endpoints principais que permitem interações divertidas e educativas.

### Endpoints
#### 1. Launch

##### GET `/buzz-aldrin/v1/launch`

Simula o lançamento da Apollo 11 com uma pequena pausa aleatória para imitar o tempo de lançamento.

- **Authorization:**
    - Requires roles: `ROLE_CLI-AUTH-IDENTIFIED`, `ROLE_CLI-1STPARTY`, `ROLE_CLI-AUTH-BASIC`

- **Responses:**
    - `200 OK`: Retorna uma mensagem de sucesso do lançamento.
      ```json
      {
        "value": "Buzz Adlrin falando ... O foguete está pronto ;D"
      }
      ```

#### 2. Who

##### GET `/buzz-aldrin/v1/who`

Pergunta quem está pilotando a Apollo-11

- **Authorization:**
    - Requires roles: `ROLE_CLI-AUTH-IDENTIFIED`, `ROLE_CLI-1STPARTY`, `ROLE_CLI-AUTH-BASIC`

- **Responses:**
    - `200 OK`: Retorna informações sobre Buzz Aldrin.
      ```json
      {
        "value": "Buzz Aldrin falando... O foguete está pronto ;D"
      }
      ```

#### 3. About

##### GET `/buzz-aldrin/v1/about`

Fornece informações sobre quem é o piloto da Apollo-11.

- **Authorization:**
    - Requires roles: `ROLE_CLI-AUTH-IDENTIFIED`, `ROLE_CLI-1STPARTY`, `ROLE_CLI-AUTH-BASIC`

- **Responses:**
    - `200 OK`: Retorna detalhes sobre a missão Apollo 11.
      ```json
      {
        "value": "Buzz Aldrin (nascido Edwin Eugene Aldrin Jr.; Glen Ridge, 20 de janeiro de 1930) é um engenheiro..."
      }
      ```

### Como a aplicação está distribuída?

Nosso Archetype segue uma arquitetura simples, organizada em camadas para manter o código limpo e modular. Abaixo, descrevemos
cada uma das camadas e pacotes presentes no projeto:

- **Controller:** Aqui ficam os controladores REST, responsáveis por receber as requisições HTTP, processá-las e devolver
as respostas adequadas. Cada controlador é dedicado a um recurso específico da API.

- **Service:** Esta camada contém as interfaces de serviços, onde definimos os contratos das operações que a aplicação 
pode realizar. Isso ajuda a manter o código desacoplado e facilita a substituição de implementações quando necessário.
Esta camada contém a lógica de negócios da aplicação, garantindo que todas as regras sejam aplicadas corretamente antes 
de interagir com a camada de persistência.

- **Repository:** Utilizamos repositórios para interagir com a base de dados. Aqui, definimos as interfaces que estendem 
o `JpaRepository` do Spring Data JPA, o que nos permite realizar operações CRUD e consultas de forma simplificada.

- **Models:** Esta camada contém as classes de modelo, que representam as entidades do domínio da aplicação. Estas classes
são mapeadas para tabelas no banco de dados e são usadas em todas as outras camadas para transferir dados.

- **DTOs (Data Transfer Objects):** Contém as classes que são usadas para transferir dados entre as camadas da aplicação. 
Os DTOs ajudam a encapsular os dados e a evitar a exposição direta das entidades de modelo, proporcionando uma camada 
adicional de segurança e controle.

- **Config:** Pacote destinado às classes de configuração da aplicação. Aqui configuramos aspectos como segurança, CORS, 
e qualquer outro componente que precise de configuração específica.

- **Clients:** Contém as classes que se comunicam com serviços externos. Utilizamos clientes REST para fazer chamadas a 
outras APIs, garantindo que a aplicação possa interagir com serviços de terceiros de forma organizada e eficiente.

Esta estrutura em camadas é um ótimo ponto de partida, fornecendo o mínimo de organização necessária para um projeto 
bem-estruturado. No entanto, incentivamos você a explorar e adotar outras arquiteturas, como Clean Architecture, 
Ports and Adapters (também conhecida como Hexagonal Architecture), conforme sua experiência e necessidade. Essas 
arquiteturas avançadas oferecem ainda mais flexibilidade e separação de responsabilidades, tornando sua aplicação mais 
robusta e fácil de manter a longo prazo.

Acreditamos que a organização inicial fornecida por este archetype lhe dará a base sólida necessária para construir e 
expandir a sua aplicação. Então, sinta-se à vontade para personalizar e aprimorar a estrutura do projeto conforme as suas 
preferências e requisitos específicos.

## IAM (Identity Access Management)

Bem, se chegou até aqui, precisamos falar sobre o IAM, o servidor de identidade, mantido pelo time de Digital PasS, 
que já vem totalmente integrado ao Archetype.

O IAM (Identity and Access Management) é uma API que fornece uma solução abrangente de segurança para usuários internos 
e externos em todo o ecossistema da empresa. Ele gerencia a autenticação e autorização de usuários e sistemas, garantindo
acesso seguro aos recursos necessários. Utilizando o protocolo OAuth2, o IAM atua como um Authorization Server, emitindo
tokens de acesso e seguindo práticas de segurança com mínimos privilégios. Sua arquitetura baseada em microsserviços permite 
escalabilidade para atender milhares de usuários com alto nível de segurança.

```
Na criação da sua aplicação, você teve a sua conta criada e recebeu as credenciais (clientId e clientSecret). 
Com elas você será capaz de se autenticar, acessar os endpoints protegidos e muito mais.
```

Leia mais sobre o IAM no [guia de introdução](https://pages.experian.local/pages/viewpage.action?spaceKey=DIPA&title=IAM).

### Biblioteca

Este Archetype já vem carregado com uma biblioteca interna `experian-spring-security-configuration`, que encapsula a 
`spring-security` e promove alguns benefícios pra usuários do IAM, como uma autoidentificação da aplicação já no start-up
da mesma, conseguindo um token de requisito mínimo.

No Pom.xml você verá o import

```xml
<dependency>
    <groupId>br.com.experian</groupId>
    <artifactId>experian-spring-security-configuration</artifactId>
</dependency>
```

Também temos a versão reativa da mesma (Caso pretenda usar WebFlux)

```xml
<dependency>
    <groupId>br.com.experian</groupId>
    <artifactId>experian-spring-reactive-security-configuration</artifactId>
</dependency>
```

### Configuração

No application-default.properties e application-deploy.properties você verá as seguintes variáveis

```
# EXPERIAN SECURITY CONFIG
api.iam.uri=${IAM_URL:}
api.iam.client.id=${IAM_CLIENT_ID:}
api.iam.client.secret=${IAM_CLIENT_SECRET:}
```

Preencha com as credenciais que ganhou na criação da sua aplicação e ao inciar sua aplicação você verá um log com a 
seguinte mensagem, em caso de sucesso:

```INFO [APPLICATIONNAME,,,] 10472 --- [           main] b.c.e.s.s.u.JwtUtil                      : message="Token key loaded from IAM service successfully."```

Sua aplicação acabou de se identificar no IAM!

- para ambientes **não produtivos** use a uri: https://uat-api.serasaexperian.com.br/security/iam/v1
- para ambientes **produtivos** use a uri: https://api.serasaexperian.com.br/security/iam/v1

### Como conseguir um token?

Você deve ter observado que Alguns endpoints da nossa API estão protegidos pelo `@PreAuthorize`, que é uma anotação do 
Spring Security utilizada para definir restrições de acesso com base nas roles do usuário.

```java
@GetMapping(value = "/launch", produces = APPLICATION_JSON_VALUE)
@PreAuthorize("hasRole('ROLE_CLI-AUTH-IDENTIFIED') and hasRole('ROLE_CLI-1STPARTY') and hasRole('ROLE_CLI-AUTH-BASIC')")
public ResponseEntity<BuzzResponse> launch() throws InterruptedException {
// Implementação do endpoint...
}
```

Para acessar esses endpoints, o usuário precisa de um token válido contendo as roles específicas exigidas pelo @PreAuthorize.

No exemplo acima, o endpoint /launch exige que o usuário possua as seguintes roles: **ROLE_CLI-AUTH-IDENTIFIED**, 
**ROLE_CLI-1STPARTY** e **ROLE_CLI-AUTH-BASIC**.

Roles Necessárias para Acesso
- **ROLE_CLI-AUTH-IDENTIFIED**: Esta role representa usuários identificados. Identificado aqui significa que foi reconhecido seu login
(ou clientId pra ser mais técnico) mas não foi avaliada sua senha.
- **ROLE_CLI-AUTH-BASIC**: Esta role representa usuários autenticados, com login e senha, com autenticação básica. Representa
um nível de confiança maior que a anterior. É uma role mais "forte".
- **ROLE_CLI-1STPARTY**: Esta role é atribuída a usuários internos da empresa.

Entenda mais [sobre o Roled-Based-Access-Control (RBAC) e as hierarquias das Roles aqui](https://pages.experian.local/pages/viewpage.action?pageId=473087672)

Assim, o IAM disponibiliza alguns endpoints, como o `/identify` e o `/login`, que retornar Tokens JWT que permitem que 
acessamos os endpoints abaixo. No nosso caso, o login é necessário. Precisamos de uma `ROLE_CLI-AUTH-BASIC`

##### POST `https://uat-api.serasaexperian.com.br/security/iam/v1/client-identities/login`

Autentica os clientes na plataforma IAM (Identity and Access Management) da Serasa Experian.

- **Basic Auth:**
    - Usar autenticação básica (Basic Auth) com as credenciais do cliente (`clientId` e `clientSecret`).

- **Responses:**
    - `201 OK`: Retorna um objeto JSON com os seguintes campos:
    ```json
    {
      "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
      "tokenType": "Bearer",
      "expiresIn": 3600,
      "scopes": ["read", "write"]
    }
    ```

Existem muito mais possibilidades com o IAM, autenticar usuários, clients, MFA, Single-sign-On, Federation, integração ao 
OKTA...
Mas o básico para sua aplicação estar protegida já foi feito!

### Liberar endpoints

Pode ser que seja por vezes necessário ter endpoints que não devam ser protegidos pelo spring security. 
Para adicionar essas possibilidades basta configurar a variável endpoints.allowed no application.properties

```
endpoints.allowed=${ENDPOINTS_ALLOWED:/favicon.*,/actuator/**}
```

## Demais highliths

A partir daqui, traremos algumas facilidades que o Archetype já traz incluso.

### Digital-Starter-Parent

O archetype já vem com o `digital-strater-parent`. Um projeto mantido pelo time de Digital PasS, que visa manter versões
mais atuais das mais variadas bibliotecas internas e de terceiros que usamos no dia-a-dia. Essa iniciativa visa, diminuir
os SLAs provocados por libs que contém vulnerabilidades e por consequência um POM.xml muito mais limpo e fácil de ser
mantido. Lembre de sempre manter a versão mais atualizada possível.

no pom.xml:

```xml
<!-- Rode o comando mvn versions:update-parent para atualizar o parent para versão mais recente -->
<!-- Ou busque a versão diretamente no repositório -->
<parent>
    <groupId>br.com.experian</groupId>
    <artifactId>experian-digital-starter-parent</artifactId>
    <version>3.0.49</version>
    <relativePath/> <!-- lookup parent from repository -->
</parent>
```

veja mais sobre o [projeto digital-starter-parent aqui](https://code.experian.local/projects/SEEXECFO/repos/experian-digital-starter-parent/browse)

### Feign Client

No mundo de microsserviços, realizar integrações é quase inevitável. Contando com isso, o Archetype já vem com a lib 
`experian-feign-client-configuration` que como o próprio nome diz, já configura o necessário para usar o feign como motor
de integração. Isso vai desde habilitação para retry, timeout ao Error Decoder, que faz um de-para das exceções do feign
para as exceções "Serasa" (Veja mais abaixo em Exceptions e Exception Handler).

no pom.xml:

```xml
<dependency>
    <groupId>br.com.experian</groupId>
    <artifactId>experian-feign-configuration</artifactId>
</dependency>
```
veja mais sobre o [projeto experian-feign-client aqui](https://code.experian.local/projects/SEEXECFO/repos/experian-feign-configuration/browse)

Em nosso archetype usamos o feign para realizar uma integração à api do wikipedia para pegar informações sobre Buzz-Aldrin.

Veja o [BuzzAboutClient.java](src/main/java/br/com/experian/buzz/domain/client/BuzzAboutClient.java)

```java
@CircuitBreaker(name = "BuzzAboutClient")
@FeignClient(name="BuzzAboutClient", url="${api.wikipedia.uri}", configuration = FeignClientConfig.class)
public interface BuzzAboutClient {

    @GetMapping(value = "/w/api.php", produces = "application/json")
    WikipediaResponse search(@RequestParam(value = "action") String action,
//...

```

### Circuit Breaker

Em uma arquitetura de microsserviços, as aplicações são compostas por muitos serviços pequenos e independentes que se 
comunicam entre si. Essa interdependência pode levar a problemas de falha em cascata, onde a falha de um serviço pode 
impactar vários outros.

Os circuit breakers são uma técnica essencial para aumentar a resiliência e a robustez de uma aplicação distribuída. 
Eles atuam como interruptores que monitoram as chamadas entre serviços e previnem a propagação de falhas.

Precisamos de ao menos três dependências para o funcionamento correto, e todas estão contidas dentro das bibliotecas que 
já estão presentes no pom.xml:
`resilience4j-spring-boot3, spring-boot-starter-aop e spring-boot-starter-actuator`.

Protegemos a nossa integração em [BuzzAboutClient.java](src/main/java/br/com/experian/buzz/domain/client/BuzzAboutClient.java) e 
disponibilizamos as configurações de tunning nos arquivos [application-default.properties](src/main/resources/application-default.properties) 
e [application-deploy.properties](src/main/resources/application-deploy.properties)

Veja mais sobre o [projeto resilience4j e circuit breakers aqui](https://resilience4j.readme.io/docs/circuitbreaker)

```java
@CircuitBreaker(name = "BuzzAboutClient")
@FeignClient(name="BuzzAboutClient", url="${api.wikipedia.uri}", configuration = FeignClientConfig.class)
public interface BuzzAboutClient {

    @GetMapping(value = "/w/api.php", produces = "application/json")
    WikipediaResponse search(@RequestParam(value = "action") String action,
//...

```

### Actuator, health, metrics e circuit breaker

O Spring Boot Actuator fornece endpoints para monitorar e gerenciar a aplicação, facilitando a deteção de problemas e diagnósticos.

O Archetype já vem com a dependência `spring-boot-starter-actuator` contida em uma das libs
e com a exposição dos endpoints de `actuator/health, actuator/metrics, actuator/circuitbreakers`

Isso é controlado no [application.properties](src/main/resources/application.properties)

```
# EXPOSE ACTUATOR ENDPOINTS
management.endpoints.web.exposure.include=health,info,metrics,prometheus,circuitbreakers
```

- Os endpoints de health check verificam o estado da aplicação e seus componentes, permitindo monitorar a disponibilidade e integridade do sistema.
- Os endpoints de métricas fornecem dados sobre o desempenho e uso de recursos da aplicação, ajudando a identificar e resolver gargalos de desempenho.
- A integração com o Actuator permite monitorar o estado dos circuit breakers em tempo real.

### Feature Flag (SEF)

O Serasa Experian Flags (SEF) é a ferramenta de Feature Flags (FF) da Serasa Brasil, permitindo que os times tenham maior
facilidade, agilidade e menos burocracia para disponibilizar features em produção.

As FF podem assumir dois estados: on e off; a depender de seu estado, a FF retorna um valor diferente para sua aplicação,
podendo alterar seu comportamento sem que seja necessário um novo deploy, poupando tempo e permitindo dessa forma mais 
celeridade em disponibilizar recursos em produção!

Algo deu errado com a nova implantação? Sem problemas! Desligue sua FF que habilita o recurso e o problema estará resolvido: 
sem war rooms, sem salas de crise, sem acionamentos prolongados.

Nosso Archetype já vem com as configurações para a utilização das FF, disponibilizado no 
[SerasaFeatureFlagConfiguration](src/main/java/br/com/experian/buzz/infrastructure/config/SerasaFeatureFlagConfiguration.java), e também
com duas FF criadas, utilizadas no [BuzzServiceImpl](src/main/java/br/com/experian/buzz/domain/service/BuzzServiceImpl.java):
`FF_21950_LAUNCH` e `FF_21950_WHO` 

```java
private static final String FF_VARIAVEL_NAME = "FF_21950_LAUNCH";
private static final String FF_BOOLEAN_NAME = "FF_21950_WHO";

@Override
public String launch() {
        var target = getTarget("buzz-aldrin-launch", "buzz-aldrin-launch");

        var stringVariation = serasaFeatureFlagClient.stringVariation(FF_VARIAVEL_NAME, target,
        "Estamos preparando o lançamento do foguete ;D");

        if (isBlank(stringVariation) || ERROR.equals(stringVariation))
        throw new UnprocessableEntityException(singleError("01"));

        return stringVariation;
        }
        //...
}
```

por fim, no pom.xml

```xml
<dependency>
    <groupId>io.harness</groupId>
    <artifactId>ff-java-server-sdk</artifactId>
    <version>1.3.0</version>
</dependency>
```

Veja mais sobre [o projeto das Serasa Experian Flags, como configurar e constuir novas FF, aqui](https://pages.experian.local/display/EDPB/SEF+-+Serasa+Experian+Flags).

### Exceptions e Exception handling

No mudno Java é comum controlar os fluxos da aplicação com exceções. Nosso Archetype conta com uma biblioteca que nos 
ajuda a lidar justamente com isso. A `experian-exception-handler`, centraliza uma série de exceções, comuns à aplicações
REST, exceções de client e de server, e também disponibiliza uma @ControllerAdvice que intercepta o retorno Controller em 
caso de erro e as trata através de uma `Exception Handling` global, tratando-as e devolvendo uma resposta formatada e 
amigável ao usuário.

no pom.xml:

```xml
<dependency>
    <groupId>br.com.experian</groupId>
    <artifactId>experian-exception-handler</artifactId>
</dependency>
```

Você pode constar o uso de um lançamento de uma `UnprocessableEntityException` no [BuzzServiceImpl](src/main/java/br/com/experian/buzz/domain/service/BuzzServiceImpl.java).

```java
@Override
public String launch() {
        var target = getTarget("buzz-aldrin-launch", "buzz-aldrin-launch");

        var stringVariation = serasaFeatureFlagClient.stringVariation(FF_VARIAVEL_NAME, target,
        "Estamos preparando o lançamento do foguete ;D");

        if (isBlank(stringVariation) || ERROR.equals(stringVariation))
        throw new UnprocessableEntityException(singleError("01"));

        return stringVariation;
        }
        //...
}
```

Ao passar pela exception handling, a mensagem será tratada e mensagem que será retornada ao usuário seguirá com o 
```Status code 422``` e será formatada como no json abaixo:

```json
[
  {
    "code": "01",
    "message":"Invalid launch" 
  }
]
```

A biblioteca consta com uma lista extensa de exceptions possíveis:

```
- Client exceptions:
BadRequestException (400)
UnauthorizedException (401)
ForbiddenException (403)
NotFoundException (404)
ConflictException (409)
PreconditionException (412)
UnprocessableEntityException (422)
TooManyRequestsException (429)

- Server exceptions:
InternalServerErrorException (500)
NotImplementedException (501)
BadGatewayException (502)
ServiceUnavailableException (503)
GatewayTimeoutException (504)
```

Há muito mais pra ser explorado no [projeto da exception handling, aqui](https://code.experian.local/projects/DSBR/repos/experian-rest-exception-handler/browse)

### Arquivos de mensagens

Nosso Archetype já disponibiliza um arquivo de mensagens: [messages_en.properties](src/main/resources/messages_en.properties),
que promove a centralização de strings e mensagens de controle de fluxo da aplicação.

Centralizando todas as mensagens em um único arquivo, a manutenção torna-se mais simples e eficiente, pois alterações nas 
mensagens podem ser feitas sem a necessidade de modificar o código-fonte. Isso também garante consistência, pois as mesmas 
mensagens são reutilizadas em diferentes partes da aplicação, evitando duplicação e discrepâncias. Além disso, facilita a 
internacionalização, permitindo a criação de arquivos de mensagens específicos para diferentes idiomas e promovendo uma 
experiência de usuário localizada.

A biblioteca de `exception handling` traz a uma abstração, que facilita a invocação das mensagens respousadas no arquivo de messagens
como você pode ver no lançamento da `UnprocessableEntityException` no [BuzzServiceImpl](src/main/java/br/com/experian/buzz/domain/service/BuzzServiceImpl.java)

o método `singleError(String codeMessage)` é o responsável pela invocação da mensagem desejada.

```java
@Override
public String launch() {
        var target = getTarget("buzz-aldrin-launch", "buzz-aldrin-launch");

        var stringVariation = serasaFeatureFlagClient.stringVariation(FF_VARIAVEL_NAME, target,
        "Estamos preparando o lançamento do foguete ;D");

        if (isBlank(stringVariation) || ERROR.equals(stringVariation))
        throw new UnprocessableEntityException(singleError("01"));

        return stringVariation;
        }
        //...
}
```
### Explore as novas features do Java (Java Records)

Nosso Archetype já está no `Java 21`! Você já tentou usar alguma das novas features?

Aqui, trazemos pra você os Java Records. O uso de Java Records traz benefícios significativos para a linguagem, 
especialmente em termos de concisão e imutabilidade. Records permitem a criação de classes de dados de forma muito mais 
sucinta, `eliminando a necessidade de escrever manualmente métodos boilerplate como getters, equals, hashCode, e toString.` 
Isso resulta em um código mais limpo e legível, focando nos dados que a classe encapsula, ao invés de na sua estrutura.

Além disso, records são imutáveis por design, promovendo práticas de programação mais seguras e facilitando o 
desenvolvimento de aplicações concorrentes. A imutabilidade ajuda a evitar efeitos colaterais indesejados, tornando o 
código mais previsível e fácil de depurar. Em resumo, Java Records oferecem uma maneira eficiente e segura de definir 
classes de dados, melhorando a clareza e a robustez do código

Records são excelentes para DTOs, então DTOs com classe? Nunca mais!

Veja no projeto os DTOs [BuzzResponse](src/main/java/br/com/experian/buzz/domain/model/BuzzResponse.java) e 
[WikipediaResponse](src/main/java/br/com/experian/buzz/domain/model/WikipediaResponse.java).

```java
public record BuzzResponse(String value)
        implements Serializable {
}
```

### Threads

O spring-boot é uma ferramenta maravilhosa, e nós no dia a dia, por vezes, acabamos nos deixando levar pela praticidade 
e deixamos escapar alguns pontos que poderiam nos trazer bons benefícios. A facilidade de subir uma aplicação, sem a 
necessidade de configurar um servidor de aplicação web e com poucos minutos já expor uma api, traz uma tremenda vantagem
em conseguir focar no problema a ser resolvido, mas para aplicações de grande porte, podemos estar a desperdiçar recursos, 
ou oportunidades. 

Já pensou se em sua aplicação poderiam ter mais threads respondendo em paralelo?

No nosso artigo sobre o [tunning de threads de uma aplicação spring-boot](https://pages.experian.local/pages/viewpage.action?pageId=1124319150)
discutimos a respeito disso. Dê uma lida mais tarde!

Pensando nisso, a aplicação já expõe, no [application.properties](src/main/resources/application.properties) a variável 
do tomcat que é responsável por essa definição.

```
server.tomcat.threads.max=${SERVER_TOMCAT_THREADS_MAX:200}
```

### Resiliência

Se gostou do assunto anterior, dê uma olhada na [metodologia de resiliência](https://pages.experian.local/pages/viewpage.action?pageId=1149012598)
que a squad `The last of us` preparou, a qual contém excelentes insigths sobre como aumentar a resiliência da sua aplicação.

### Properties Files

Configuramos o Archetype para trabalhar com um perfil de deploy [application-deploy.properties](src/main/resources/application-deploy.properties)
e um perfil default (não produtivo) [application-default.properties](src/main/resources/application-default.properties). 
Estes compartilham as mesmas informações, com a diferença que o o arquivo de deploy espera em sua maioria valores provenientes
de variáveis de ambiente.

Como adição, temos também o [application.properties](src/main/resources/application.properties) base, cujas propriedades
e configurações serão sempre executadas, independentemente do perfil indicado ao executar a aplicação.

Nele, temos algumas definições, cujas explicações seguem abaixo:

##### SPRING CONFIG

- `spring.application.name=@project.name@`: Define o nome da aplicação. O valor `@project.name@` é substituído pelo nome 
do projeto configurado no arquivo de build (por exemplo, Maven ou Gradle).

- `spring.main.allow-bean-definition-overriding=true`: Permite que definições de beans sejam substituídas. Útil em cenários
de testes ou quando se deseja sobrescrever configurações de beans padrão.

- `spring.cloud.compatibility-verifier.enabled=false`: Desabilita o verificador de compatibilidade do Spring Cloud, que 
checa a compatibilidade entre versões de componentes do Spring Cloud.

##### EXPERIAN SECURITY CONFIG

- `allowed.origins=${ALLOWED_ORIGINS:*}`: Configura os origens permitidos para CORS (Cross-Origin Resource Sharing). O 
valor `${ALLOWED_ORIGINS:*}` permite todas as origens, mas pode ser substituído por uma variável de ambiente específica.

- `endpoints.allowed=${ENDPOINTS_ALLOWED:/actuator/**}`: Define os endpoints que são permitidos, com o valor padrão sendo
`/actuator/**`. Pode ser substituído por uma variável de ambiente.

##### SERVER CONFIG

- `server.tomcat.mbeanregistry.enabled=true`: Habilita o registro de MBeans do Tomcat, permitindo o monitoramento e a 
gestão do servidor Tomcat via JMX.

- `server.tomcat.threads.max=${SERVER_TOMCAT_THREADS_MAX:200}`: Define o número máximo de threads para o pool de threads 
do Tomcat. O valor padrão é `200`, mas pode ser configurado através da variável de ambiente `SERVER_TOMCAT_THREADS_MAX`.

##### EXPOSE ACTUATOR ENDPOINTS

- `management.endpoints.web.exposure.include=health,info,metrics,prometheus,circuitbreakers`: Especifica quais endpoints
do Actuator devem ser expostos via web. Neste caso, estão incluídos os endpoints de saúde, informações, métricas, 
Prometheus e circuit breakers.

- `management.endpoint.health.show-details=ALWAYS`: Configura para que os detalhes completos dos endpoints de saúde 
(`/actuator/health`) sejam sempre mostrados.

- `management.health.circuitbreakers.enabled=true`: Habilita a inclusão do estado dos circuit breakers no endpoint de 
saúde (`/actuator/health`).

- `management.tracing.enabled=${SPRING_ZIPKIN_ENABLED:true}`: Habilita o tracing (rastreamento) distribuído, com o valor
padrão sendo `true`, mas pode ser configurado através da variável de ambiente `SPRING_ZIPKIN_ENABLED`.

##### CONFIGURAÇÃO DO RESILIENCE4J

- `resilience4j.circuitbreaker.configs.default.registerHealthIndicator=true`: Configura o Resilience4j para registrar os
indicadores de saúde dos circuit breakers, permitindo que seu estado seja monitorado via endpoints de saúde do Actuator.

Estas configurações proporcionam uma base robusta para a aplicação, permitindo uma fácil customização através de variáveis
de ambiente, melhor monitoramento, e gestão de recursos e segurança.


### Testes Unitários

O Archetype conta com uma suíte de testes que pode te guiar a superar as barreiras enfretadas ao escrever testes 
para a sua aplicação de fato. Fique a vontade para explorar o test package e levar as estratégias para sesu casos de uso.

### Docker File

O Archetype conta com um DockerFile configurado pronto para produção. Nele definimos o profile que será executado, a porta,
o logging level, alocações iniciais e máximas de heap da JVM, alguns pontos para ajudar na inicialização da aplicação 
entre outras definições, como pode ver abaixo:

##### Configurações de Variáveis de Ambiente

- `ENV SPRING_LOGGING_LEVEL INFO`: Define o nível de logging do Spring como INFO.
- `ENV SPRING_PROFILE deploy`: Define o perfil ativo do Spring como `deploy`.
- `ENV PORT 8080`: Define a porta em que a aplicação irá rodar como `8080`.
- `ENV JVM_XMS 512m`: Define o tamanho inicial da memória heap da JVM como `512m`.
- `ENV JVM_XMX 850m`: Define o tamanho máximo da memória heap da JVM como `850m`.
- `ENV TIMEZONE Brazil/East`: Define o fuso horário do contêiner como `Brazil/East`.

##### Adição do JAR da Aplicação

- `ADD target/*.jar /app/app.jar`: Adiciona o arquivo JAR da aplicação, que é o resultado da construção (`build`), para 
o diretório `/app` no contêiner e o renomeia para `app.jar`.

##### Definição do EntryPoint

O comando `ENTRYPOINT` especifica o comando que será executado quando o contêiner iniciar. Este comando configura a JVM 
com diversas opções para otimização e define propriedades específicas da aplicação Spring Boot.

- `-Xms${JVM_XMS}`: Define o tamanho inicial da memória heap da JVM com base na variável de ambiente `JVM_XMS`.
- `-Xmx${JVM_XMX}`: Define o tamanho máximo da memória heap da JVM com base na variável de ambiente `JVM_XMX`.
- `-noverify`: Desabilita a verificação de classes para otimizar a inicialização.
- `-XX:TieredStopAtLevel=1`: Configura a JVM para usar apenas compilação de nível 1, acelerando a inicialização da aplicação.
- `-Dfile.encoding=UTF-8`: Define a codificação de arquivos como UTF-8.
- `-Dlogging.level.root=${SPRING_LOGGING_LEVEL}`: Define o nível de logging raiz com base na variável de ambiente `SPRING_LOGGING_LEVEL`.
- `-Dspring.jmx.enabled=false`: Desabilita o JMX do Spring.
- `-Dspring.profiles.active=${SPRING_PROFILE}`: Ativa o perfil do Spring configurado pela variável de ambiente `SPRING_PROFILE`.
- `-Dspring.config.additional-location=classpath:/observability.properties`: Adiciona uma localização adicional para o 
arquivo de configuração `observability.properties` no classpath.
- `-jar /app/app.jar`: Especifica o arquivo JAR da aplicação que será executado.
- `--server.port=${PORT}`: Define a porta do servidor com base na variável de ambiente `PORT`.

##### Exposição da Porta

- `EXPOSE ${PORT}`: Expõe a porta definida pela variável de ambiente `PORT` (`8080` por padrão) para que a aplicação possa ser acessada externamente.

### Changelog

Dê uma olhada no [changelog](CHANGELOG.md) e mantenha as modificações de sua api nele.

### Contributors

Dê uma olhada no [contributors](CONTRIBUTORS.md) e dê visibilidade aos devs que trouxeram essa api ao mundo. 

### 10, 9, 8, 7, 6, 5, 4, 3, 2, 1.......LAUNCH!!!!!!!

Se você chegou até aqui, já pôde conhecer diversas facilidades que o Archetype oferece. Isso foi apenas uma introdução 
ao que temos disponível. Fique a vontade para explorar, criar e contribuir com os projetos internos.

Agora é hora de colocar a mão na massa e começar a codar!
