-- Schema para H2 Database
CREATE TABLE IF NOT EXISTS onboarding_status (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    supplier_document VARCHAR(14) NOT NULL UNIQUE,
    status VARCHAR(20) NOT NULL,
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_onboarding_supplier_document ON onboarding_status(supplier_document);