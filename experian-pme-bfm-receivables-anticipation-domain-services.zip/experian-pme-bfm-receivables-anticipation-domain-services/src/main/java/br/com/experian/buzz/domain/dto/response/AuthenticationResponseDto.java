package br.com.experian.buzz.domain.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.LocalDateTime;

public class AuthenticationResponseDto {

    @JsonProperty("access_token")
    private String accessToken;

    @JsonProperty("token_type")
    private String tokenType;

    @JsonProperty("expires_in")
    private Integer expiresIn;

    @JsonProperty("scope")
    private String scope;

    //Calculado para controle interno de expiração
    private LocalDateTime expiresAt;

    public  AuthenticationResponseDto(){

    }

    public AuthenticationResponseDto(String accessToken, String tokenType, Integer expiresIn) {
        this.accessToken = accessToken;
        this.tokenType = tokenType;
        this.expiresIn = expiresIn;
        this.expiresAt = LocalDateTime.now().plusSeconds(expiresIn != null ? expiresIn : 3600);
    }

    public boolean isExpired() {
        return expiresAt != null && LocalDateTime.now().isAfter(expiresAt);
    }

    public boolean isExpiringSoon() {
        return expiresAt != null && LocalDateTime.now().plusMinutes(5).isAfter(expiresAt);
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String acsessToken) {
        this.accessToken = accessToken;
    }

    public String getTokenType() {
        return tokenType;
    }

    public Integer getExpiresIn() {
        return expiresIn;
    }

    public void setExpiresIn(Integer expiresIn) {
        this.expiresIn = expiresIn;
        this.expiresAt = LocalDateTime.now().plusSeconds(expiresIn != null ? expiresIn : 3600);
    }

    public String getScope() {
        return scope;
    }

    public void setScope(String scope) {
        this.scope = scope;
    }

    public LocalDateTime getExpiresAt() {
        return expiresAt;
    }

    public void setExpiresAt(LocalDateTime expiresAt) {
        this.expiresAt = expiresAt;
    }

    @Override
    public String toString() {
        return "AuthenticationResponseDto{" +
                "accessToken='" + (accessToken != null ? "***PRESENTE***" : "null") + '\'' +
                "tokenType'" + tokenType + '\'' +
                ", expiresIn=" + expiresIn +
                ", scope='" + scope + '\'' +
                ", expiresAt='" + expiresAt + '\'' +
                '}';
    }
}
