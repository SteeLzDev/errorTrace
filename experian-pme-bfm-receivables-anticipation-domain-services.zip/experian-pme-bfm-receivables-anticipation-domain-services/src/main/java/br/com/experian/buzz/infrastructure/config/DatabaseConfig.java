package br.com.experian.buzz.infrastructure.config;


import br.com.experian.buzz.domain.enums.OnboardingStatus;
import br.com.experian.buzz.infrastructure.repository.document.OnboardingDocument;
import br.com.experian.buzz.infrastructure.repository.OnboardingMongoRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DatabaseConfig {

    @Bean
    public CommandLineRunner initMongoDatabase(OnboardingMongoRepository mongoRepository) {
        return args -> {
            try {
                long count = mongoRepository.count();
                if (count > 0) {
                    System.out.println("Collection possui " + count + " documentos!");
                    return;
                }
                System.out.println("Inserindo dados iniciais no Banco");

                OnboardingDocument doc1 = new OnboardingDocument("12345678000195", OnboardingStatus.STARTED);
                OnboardingDocument doc2 = new OnboardingDocument("98765432000123", OnboardingStatus.PENDING);
                OnboardingDocument doc3 = new OnboardingDocument("11111111000111", OnboardingStatus.APPROVED);
                OnboardingDocument doc4 = new OnboardingDocument("22222222000222", OnboardingStatus.REJECTED);

                mongoRepository.save(doc1);
                mongoRepository.save(doc2);
                mongoRepository.save(doc3);
                mongoRepository.save(doc4);

                System.out.println("Dados iniciais inseridos com sucesso!");

                } catch (Exception ex) {
                    System.err.println("Erro ao inicializar banco: " + ex.getMessage());
                }

            };

    }


}
