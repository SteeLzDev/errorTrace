package br.com.experian.buzz.infrastructure.config;

import feign.Client;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.security.cert.X509Certificate;

@Configuration
@Profile({"default", "dev", "test", "test", "ssl-disabled"})
public class FeignSSLConfig {

    @Bean
    public Client feignClient() {

        //TrustManager aceita todos os certificados
        try {

            TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(X509Certificate[] chain, String authType) {
                        }

                        @Override
                        public void checkServerTrusted(X509Certificate[] chain, String authType) {
                        }

                        @Override
                        public X509Certificate[] getAcceptedIssuers() {
                            return new X509Certificate[0];
                        }
                    }
            };

            //Configurar SSLContext
            SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());

            return new Client.Default(
                    sslContext.getSocketFactory(),
                    (hostname, session) -> true
            );
        } catch (Exception e) {
            throw new RuntimeException("Erro ao configurar cliente Feign sem SSL", e);
        }
    }


}
