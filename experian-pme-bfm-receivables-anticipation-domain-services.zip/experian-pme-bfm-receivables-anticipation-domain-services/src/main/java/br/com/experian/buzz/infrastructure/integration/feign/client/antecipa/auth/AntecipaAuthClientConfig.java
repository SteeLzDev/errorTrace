package br.com.experian.buzz.infrastructure.integration.feign.client.antecipa.auth;

import feign.Logger;
import feign.Request;
import feign.Retryer;
import feign.codec.ErrorDecoder;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.TimeUnit;

@Configuration
public class AntecipaAuthClientConfig {

    private static final org.slf4j.Logger log = LoggerFactory.getLogger(AntecipaAuthClientConfig.class);


    @Bean
    public Request.Options authRequestOptions() {
        log.info("Configurando timeouts para AntecipaAuthClient:");
        log.info("- Connect timeout: 10 segundos");
        log.info("- Read time out: 30 segundos ");
        return new Request.Options(
                30, TimeUnit.SECONDS,
                60, TimeUnit.SECONDS,
                true
        );
    }

    @Bean
    public Retryer antecipaAuthRetryer() {
        log.info("Configurando retry para AntecipaAuthClient:");
        log.info("    - Tentativas max: 3");
        log.info("    - Periodo max: 3 segundos");
            return new Retryer.Default(1000, 3000, 3);
        }

    @Bean
    public  Logger.Level authFeignLoggerLevel(){
        log.info("Configurando logging para AntecipaAuthClient: FULL (desenvolvimento)");
        return Logger.Level.FULL;
    }

    @Bean
    public ErrorDecoder authErrorDecoder() {
        log.info("Configurando decodificador de erros para AntecipaAuthClient");
        return new ErrorDecoder.Default();
    }


    }