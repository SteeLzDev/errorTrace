package br.com.experian.buzz.infrastructure.integration.feign.client.antecipa.auth;

import br.com.experian.buzz.domain.dto.response.AuthenticationResponseDto;
import feign.Response;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;

?
@FeignClient(name = "AntecipaAuthClient", url = "${api.antecipa.auth.uri}", configuration = AntecipaAuthClient.class)
public interface AntecipaAuthClient {


    @PostMapping(value = "/auth/token")
    @CircuitBreaker(name = "AntecipaAuthClient")
    @Retry(name = "AntecipaAuthClient")
    AuthenticationResponseDto auth(@RequestHeader("Authorization") String basicAuth);

    @PostMapping("/authentication/signin")
    @CircuitBreaker(name = "AntecipaAuthClient")
    @Retry(name = "AntecipaAuthClient")
    Response signin(@RequestHeader("Authorization") String basicAuth);

    @PostMapping("/authentication/signin")
    AuthenticationResponseDto signinDto(@RequestHeader("Authorization") String authorization);
}
