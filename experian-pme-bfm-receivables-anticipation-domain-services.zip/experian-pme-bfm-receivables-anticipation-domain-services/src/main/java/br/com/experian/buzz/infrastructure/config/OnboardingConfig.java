package br.com.experian.buzz.infrastructure.config;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = {
        "br.com.experian.buzz.infrastructure.adapter",
        "br.com.experian.buzz.infrastructure.service",
        "br.com.experian.buzz.application.rest"
})
@EntityScan(basePackages = "br.com.experian.buzz.infrastructure.entity")
public class OnboardingConfig {
}
