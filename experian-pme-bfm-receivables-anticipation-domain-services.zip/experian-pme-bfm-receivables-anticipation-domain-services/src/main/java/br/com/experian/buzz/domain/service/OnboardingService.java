package br.com.experian.buzz.domain.service;

import br.com.experian.buzz.domain.dto.response.OnboardingStatusResponseDto;

import java.util.Optional;

public interface OnboardingService {

    Optional<OnboardingStatusResponseDto>getOnboardingStatus(String supplierDocument);





}
