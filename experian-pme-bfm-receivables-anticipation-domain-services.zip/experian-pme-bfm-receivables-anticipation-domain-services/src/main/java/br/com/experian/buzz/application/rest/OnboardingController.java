package br.com.experian.buzz.application.rest;


import br.com.experian.buzz.domain.dto.response.OnboardingStatusResponseDto;
import br.com.experian.buzz.domain.service.OnboardingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/v1/onboarding")
@CrossOrigin(origins = "*")
public class OnboardingController {

    private static final Logger log = LoggerFactory.getLogger(OnboardingController.class);

    private final OnboardingService onboardingService;

    public OnboardingController(OnboardingService onboardingService) {
        this.onboardingService = onboardingService;
    }

    @GetMapping("/{supplierDocument}")
    public ResponseEntity<OnboardingStatusResponseDto> getOnboardingStatus (@PathVariable String supplierDocument) {

        log.info("Recebida requisição para consultar status de onboarding do documento: {}", supplierDocument);

        try {
            Optional<OnboardingStatusResponseDto> optionalResponse = onboardingService.getOnboardingStatus(supplierDocument);

            if (optionalResponse.isPresent()) {
                OnboardingStatusResponseDto response = optionalResponse.get();
                log.info("Status de onboarding encontrado para o documento: {} - Status: {}", supplierDocument, response.getStatus());
                return ResponseEntity.ok(response);
            } else {
                log.info("Nenhum status de onboarding encontrado para documento: {}", supplierDocument);
                return ResponseEntity.noContent().build();
            }
        } catch (Exception e) {
            log.error("Erro ao consultar status de onboarding para documento: {}", supplierDocument, e);
            return ResponseEntity.internalServerError().build();
        }

    }
    //Atualiza Status de onboarding de um fornecedor
    @PutMapping("/{supplierDocument}")
    public ResponseEntity<OnboardingStatusResponseDto> updateOnboardingStatus (
            @PathVariable String supplierDocument, @RequestBody OnboardingStatusResponseDto request) {
        try {
            log.info("Status de onboarding atualizado para documento: {}", supplierDocument);
            return ResponseEntity.ok(request);
        } catch (Exception e) {
            log.error("Erro ao atualizar status de onboarding para documento: {}", supplierDocument, e);
            return ResponseEntity.internalServerError().build();
        }

    }

    @GetMapping("/health")
    public ResponseEntity<String> health() {
        log.debug("Health check solicitado");
        return ResponseEntity.ok("Onboarding Controller is healthy");
    }



}
