package br.com.experian.anticipation.domain.dto.response;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReceivablesGroupedResponseDto {

    private List<GroupDto> groups;
    private PaginationDto page;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class GroupDto {
        private LocalDate paymentDate;
        private Integer count;
        private BigDecimal totalAmountToReceive;
        private List<ReceivableItemDto> items;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ReceivableItemDto {
        private String id;
        private LocalDate paymentDate;
        private String nationalRegistrationId;
        private String accreditingInstitutionName;
        private String paymentType;
        private InstallmentDto installment;
        private BigDecimal discount;
        private BigDecimal amountToReceive;
    }
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class InstallmentDto {
        private Integer count;
        private Integer number;
        private BigDecimal amount;
        private String paymentType;
        private BigDecimal amountToReceive;
    }
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class PaginationDto {
        private Integer size;
        private Integer totalElements;
        private Integer totalPages;
        private Integer number;
    }

}
