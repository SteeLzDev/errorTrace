package br.com.experian.anticipation.domain.port;


import br.com.experian.anticipation.domain.enums.OnboardingStatus;

public interface OnboardingPort {

    OnboardingStatus getOnboardingStatus(String supplierDocument);

}
