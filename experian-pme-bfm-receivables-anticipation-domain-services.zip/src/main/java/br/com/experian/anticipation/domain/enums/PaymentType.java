package br.com.experian.anticipation.domain.enums;

public enum PaymentType {

    CREDIT_SINGLE ,
    CREDIT_INSTALLMENT;
}
