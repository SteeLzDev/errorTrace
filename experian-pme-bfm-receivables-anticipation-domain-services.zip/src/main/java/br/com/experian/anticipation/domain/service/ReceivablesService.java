package br.com.experian.anticipation.domain.service;

import br.com.experian.anticipation.domain.dto.response.ReceivablesResponseDto;

import java.util.Optional;

public interface ReceivablesService {


    Optional<ReceivablesResponseDto> getReceivables(String supplierDocument, Integer limit, Integer offset);
}
