package br.com.experian.anticipation.application.adapter;


import br.com.experian.anticipation.domain.dto.response.ReceivablesGroupedResponseDto;
import br.com.experian.anticipation.domain.enums.PaymentType;
import br.com.experian.anticipation.domain.model.*;
import br.com.experian.swagger.anticipation.model.*;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ReceivablesMapper {

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public static ReceivableGroupedResponseTO toReceivableResponse(ReceivablesModel receivables) {
        if (receivables == null) {
            return null;
        }
        List<ReceivableDataTO> content = receivables.getGroups().stream()
                .flatMap(group -> group.getReceivables().stream())
                .map(ReceivablesMapper::mapToReceivableData)
                .collect(Collectors.toList());

        PaginationTO pagination = mapToPagination(receivables.getPage());

        return new ReceivableGroupedResponseTO()
                .page(pagination);
    }

    public static ReceivablesGroupedResponseDto toGroupedResponse(ReceivablesModel receivables) {
        if (receivables == null) {
            return null;
        }
        List<ReceivablesGroupedResponseDto.GroupDto> groups = receivables.getGroups().stream()
                .map(group -> ReceivablesGroupedResponseDto.GroupDto.builder()
                        .paymentDate(group.getDate())
                        .count(group.getCount())
                        .totalAmountToReceive(BigDecimal.valueOf(group.getTotalAmountToReceive()))
                        .items(group.getReceivables().stream()
                                .map(ReceivablesMapper::mapToReceivableItem)
                                .collect(Collectors.toList()))
                        .build())
                        .collect(Collectors.toList());

                ReceivablesGroupedResponseDto.PaginationDto pagination = ReceivablesGroupedResponseDto.PaginationDto.builder()
                        .size(receivables.getPage().getSize())
                        .totalElements(receivables.getPage().getTotalElements().intValue())
                        .totalPages(receivables.getPage().getTotalPages())
                        .number(receivables.getPage().getNumber())
                        .build();

                return ReceivablesGroupedResponseDto.builder()
                        .groups(groups)
                        .page(pagination)
                        .build();
    }

    public static ReceivableGroupedResponseTO toGroupedResponseTO(ReceivablesModel receivables) {
        if (receivables == null) {
            return null;
        }
        List<ReceivableGroupTO> content = receivables.getGroups().stream()
                .map(group -> new ReceivableGroupTO()
                .paymentDate(group.getDate().format(DATE_FORMATTER))
                .count(group.getCount())
                .totalAmountToReceive(BigDecimal.valueOf(group.getTotalAmountToReceive()))
                .items(group.getReceivables().stream()
                        .map(ReceivablesMapper::mapToReceivableDataTO)
                .collect(Collectors.toList())))
                .collect(Collectors.toList());

        PaginationTO pagination = mapToPagination(receivables.getPage());

        return new ReceivableGroupedResponseTO()
                .groups(content)
                .page(pagination);
    }

    private static ReceivableDataTO mapToReceivableData(ReceivableModel model) {
        return new ReceivableDataTO()
                .id(model.getId())
                .paymentDate(model.getPaymentDate() != null ? model.getPaymentDate().format(DATE_FORMATTER) : null)
                .nationalRegistrationId(model.getNationalRegistrationId())
                .accreditingInstitutionName(model.getAccreditingInstitutionName())
                .paymentType(mapToPaymentTypeTO(model.getPaymentType()))
                .installment(mapToInstallmentDataTO(model.getInstallment()))
                .discount(model.getDiscount())
                .amountToReceive(model.getAmountToReceive());
    }


    private static ReceivablesGroupedResponseDto.ReceivableItemDto mapToReceivableItem(ReceivableModel model) {
        return ReceivablesGroupedResponseDto.ReceivableItemDto.builder()
                .id(model.getId())
                .paymentDate(model.getPaymentDate())
                .nationalRegistrationId(model.getNationalRegistrationId())
                .accreditingInstitutionName(model.getAccreditingInstitutionName())
                .paymentType(model.getPaymentType() != null ? model.getPaymentType().name() : null)
                .installment(model.getInstallment() != null ?
                        ReceivablesGroupedResponseDto.InstallmentDto.builder()
                                .count(model.getInstallment().getCount())
                                .number(model.getInstallment().getNumber())
                                .amount(model.getInstallment().getAmount())
                                .build() : null)
                .discount(model.getDiscount())
                .amountToReceive(model.getAmountToReceive())
                .build();
    }

    private static ReceivableDataTO mapToReceivableDataTO(ReceivableModel model) {
        return new ReceivableDataTO()
                .id(model.getId())
                .paymentDate(model.getPaymentDate() != null ? model.getPaymentDate().format(DATE_FORMATTER) : null)
                .nationalRegistrationId(model.getAccreditingInstitutionName())
                .paymentType(mapToPaymentTypeTO(model.getPaymentType()))
                .installment(mapToInstallmentDataTO(model.getInstallment()))
                .discount(model.getAmountToReceive());
    }

    private static PaymentTypeTO mapToPaymentTypeTO(PaymentType paymentType) {
        if (paymentType == null) {
            return null;
        }
        switch (paymentType) {
            case CREDIT_SINGLE:
                return PaymentTypeTO.CREDIT_SINGLE;
            case CREDIT_INSTALLMENT:
                return PaymentTypeTO.CREDIT_INSTALLMENT;
            default:
                throw new IllegalArgumentException("Unknown  PaymentType: " + paymentType);
        }
    }

    private static InstallmentDataTO mapToInstallmentDataTO(InstallmentModel model) {
        if (model == null) {
            return null;
        }
        return new InstallmentDataTO()
                .count(model.getCount())
                .number(model.getNumber())
                .amount(model.getAmount())
                .paymentType(mapToPaymentTypeTO(model.getPaymentType()))
                .discount(model.getDiscount());

    }

    private static PaginationTO mapToPagination(PaginationModel model) {
        return new PaginationTO()
                .size(model.getSize())
                .totalElements(model.getTotalElements().intValue())
                .totalPages(model.getTotalPages())
                .number(model.getNumber());
    }


}
