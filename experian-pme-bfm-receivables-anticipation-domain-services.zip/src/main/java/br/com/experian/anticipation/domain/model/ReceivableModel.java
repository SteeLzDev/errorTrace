package br.com.experian.anticipation.domain.model;

import br.com.experian.anticipation.domain.enums.PaymentType;
import br.com.experian.swagger.anticipation.model.PaymentTypeTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReceivableModel {

    private String id;
    private LocalDate paymentDate;
    private String nationalRegistrationId;
    private String accreditingInstitutionName;
    private PaymentTypeTO paymentTypeTO;
    private InstallmentModel installment;
    private BigDecimal discount;
    private BigDecimal amountToReceive;
    private PaymentType paymentType;






}
