package br.com.experian.anticipation.domain.client;

public interface AccountClient {

    String findNationalRegistrationId(String businessId);
}