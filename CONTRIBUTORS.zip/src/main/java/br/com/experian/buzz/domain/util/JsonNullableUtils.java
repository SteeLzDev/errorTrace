package br.com.experian.buzz.domain.util;

import org.openapitools.jackson.nullable.JsonNullable;

public final class JsonNullableUtils {

    private JsonNullableUtils() {

    }

    public static String getString (JsonNullable<String> jsonNullable) {
        if (jsonNullable == null || !jsonNullable.isPresent()) {
            return null;
        }
        return jsonNullable.get();
    }

    public static String getString(JsonNullable<String> jsonNullable, String defaultValue) {
        if (jsonNullable == null || !jsonNullable.isPresent()) {
            return defaultValue;
        }
        return jsonNullable.get();
    }

    public static Integer getInteger(JsonNullable<Integer> jsonNullable) {
        if (jsonNullable == null || !jsonNullable.isPresent()) {
            return null;
        }
        return jsonNullable.get();
    }

    public static Integer getString(JsonNullable<Integer> jsonNullable, Integer defaultValue) {
        if (jsonNullable == null || !jsonNullable.isPresent()) {
            return defaultValue;
        }
        return jsonNullable.get();
    }

    public static boolean isPresent (JsonNullable<?> jsonNullable) {
        return jsonNullable != null && jsonNullable.isPresent();
    }

    public static boolean isEmpty(JsonNullable<?> jsonNullable) {
        return jsonNullable == null || !jsonNullable.isPresent();
    }


}
