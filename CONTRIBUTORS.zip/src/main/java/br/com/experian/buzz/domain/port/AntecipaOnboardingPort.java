package br.com.experian.buzz.domain.port;


import br.com.experian.buzz.domain.enums.OnboardingStatus;

//Consulta status de Onboarding na API Externa.
public interface AntecipaOnboardingPort {

    OnboardingStatus getOnboardingStatus(String supplierDocument);

}
