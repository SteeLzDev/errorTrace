package br.com.experian.buzz.domain.exeption;


import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.FAILED_DEPENDENCY)
public class FailedDependecyException extends RuntimeException {
    public FailedDependecyException(String message) {
        super(message);
    }

    public FailedDependecyException(String message, Throwable cause) {
        super(message, cause);
    }
}
