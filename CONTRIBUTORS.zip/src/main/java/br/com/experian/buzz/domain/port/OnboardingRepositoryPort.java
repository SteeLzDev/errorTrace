package br.com.experian.buzz.domain.port;

import br.com.experian.buzz.domain.model.OnboardingStatusModel;

import java.util.Optional;


//Operações de Persistência de onboarding.
public interface OnboardingRepositoryPort {


    Optional<OnboardingStatusModel> findBySupplierDocument(String supplierDocument);
    OnboardingStatusModel save (OnboardingStatusModel onboardingStatus);
}
