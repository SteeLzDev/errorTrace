package br.com.experian.buzz.infrastructure.repository.adapter;

import br.com.experian.antecipa.model.SupplierRegistrationDto;
import br.com.experian.buzz.domain.enums.OnboardingStatus;
import br.com.experian.buzz.domain.exeption.FailedDependecyException;
import br.com.experian.buzz.domain.port.AntecipaOnboardingPort;
import br.com.experian.buzz.domain.port.AuthenticationPort;
import br.com.experian.buzz.domain.util.JsonNullableUtils;
import br.com.experian.buzz.infrastructure.integration.feign.client.antecipa.AntecipaClient;
import feign.FeignException;
import io.github.resilience4j.retry.annotation.Retry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class AntecipaOnboardingAdapter implements AntecipaOnboardingPort {

    private static final Logger log  = LoggerFactory.getLogger(AntecipaOnboardingAdapter.class);
    private static final String FAILED_DEPENDENCY_MESSAGE = "Falha na comunicação com o serviço de onboarding.";

    private final AntecipaClient antecipaClient;
    private final AuthenticationPort authenticationPort;
    private final String defaultCapitalSourceDocument;



    public AntecipaOnboardingAdapter(AntecipaClient antecipaClient, AuthenticationPort authenticationPort,
                                     @Value("$api.antecipa.default-capital-source:58408679000132") String defaultCapitalSourceDocument) {
        this.antecipaClient = antecipaClient;
        this.authenticationPort = authenticationPort;
        this.defaultCapitalSourceDocument = defaultCapitalSourceDocument;
    }

    @Override
    @Retry(name = "AntecipaClient")
    public OnboardingStatus getOnboardingStatus(String supplierDocument) {
        try {
            log.info("Consultando status de onboarding na API Antecipa para documento: {}", supplierDocument);

            //Obter token válido
            String bearerToken = "Bearer " + authenticationPort.getValidToken();
            log.debug("Token obtido para autenticação");

            SupplierRegistrationDto supplierRegistration = antecipaClient.getSupplierRegistration(
                    bearerToken,
                    defaultCapitalSourceDocument,
                    supplierDocument
            );

            if(supplierRegistration == null) {
                log.info("API Retornou null - não há registro para documento:{} ", supplierDocument);
                return null;
            }

            String statusString = JsonNullableUtils.getString(supplierRegistration.getStatus());
            Integer statusId = supplierRegistration.getStatusId();

            OnboardingStatus mappedStatus = mapApiStatusToEnum(statusString, statusId);

            log.info("Status obtido da API: '{}' (ID: {}) -> Mapeado para: {} para documento: {}",
            statusString,
            statusId,
            mappedStatus,
            supplierDocument);

            return mappedStatus;

        } catch (FeignException e) {
            log.error("Erro ao consultar status de onboarding na API Antecipa. Status: {}, Body: {}",
                    e.status(), e.contentUTF8(), e);

            if(e.status() == 401) {
                log.info("Token inválido, tentando renovar...");
                authenticationPort.refreshToken();
                throw new FailedDependecyException("Token de autenticação inválido", e);
            }

            if (e.status() == 404 || e.status() == 204) {
                log.info("Fornecedor não encontrado na API - não há onboarding para documento: {}", supplierDocument);

                return null;
            }
            throw new FailedDependecyException(FAILED_DEPENDENCY_MESSAGE, e);
        }
    }

    private OnboardingStatus mapApiStatusToEnum(String status, Integer statusId) {
        log.debug("Mapeando status da API: '{}' com ID: {}", status, statusId);

        //priorizar mapeamento por statusId
        if (statusId != null) {
            switch (statusId) {
                case 1:
                    return OnboardingStatus.APPROVED; //Active
                case 2:
                    return OnboardingStatus.PENDING; //Pending
                case 3:
                    return OnboardingStatus.REJECTED; //Inactive
                case 4:
                    return OnboardingStatus.STARTED; //InAnalysis
                case 5:
                    return OnboardingStatus.REVIEW; //InReview
                default:
                    log.warn("StatusId Desconhecido: {}, tentando mapear por string", statusId);
            }
        }

            //Fallback: mapeando por string (case-insensitive)
            if (status != null) {
                String normalizedStatus = status.toLowerCase().trim();
                switch (normalizedStatus) {
                    case "active":
                        return OnboardingStatus.APPROVED;
                    case "pending":
                        return OnboardingStatus.PENDING;
                    case "inactive":
                        return OnboardingStatus.REJECTED;
                    case "inanalysis":
                    case "in_analysis":
                    case "in analysis":
                        return OnboardingStatus.STARTED;
                    case "inreview":
                        return OnboardingStatus.REVIEW;
                    default:
                        log.warn("Status string desconhecido: '{}'. Usando PENDING como padrão.", status);
                }
            }
            //Padrão, se não conseguir mapear, assumir PENDRING
            log.warn("Não foi possível mapear status: '{}' (ID: {}). Usando PENDING como padrão.", status, statusId);
            return OnboardingStatus.PENDING;

        }
    }
