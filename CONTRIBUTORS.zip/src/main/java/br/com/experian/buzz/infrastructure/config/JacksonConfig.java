package br.com.experian.buzz.infrastructure.config;


import com.fasterxml.jackson.databind.Module;
import org.openapitools.jackson.nullable.JsonNullableModule;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

//Configuração do Jackson para serialização e desserialização de objetos JSON
@Configuration
public class JacksonConfig {

    @Bean
    public Module jsonNullableModule() {
        //Registra o módulo JsonNullable para lidar com valores nulos de forma mais flexível
        return new JsonNullableModule();
    }



}
