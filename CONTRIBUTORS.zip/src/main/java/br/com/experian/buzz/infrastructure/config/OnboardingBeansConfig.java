package br.com.experian.buzz.infrastructure.config;

import br.com.experian.buzz.domain.port.AntecipaOnboardingPort;
import br.com.experian.buzz.domain.port.AuthenticationPort;
import br.com.experian.buzz.domain.port.OnboardingRepositoryPort;
import br.com.experian.buzz.domain.service.OnboardingService;
import br.com.experian.buzz.infrastructure.repository.adapter.AntecipaOnboardingAdapter;
import br.com.experian.buzz.infrastructure.repository.adapter.OnboardingRepositoryAdapter;
import br.com.experian.buzz.infrastructure.integration.feign.client.antecipa.AntecipaClient;
import br.com.experian.buzz.infrastructure.repository.OnboardingMongoRepository;
import br.com.experian.buzz.infrastructure.repository.impl.OnboardingServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.mongodb.core.MongoTemplate;

@Configuration
public class OnboardingBeansConfig {


    private static final Logger log = LoggerFactory.getLogger(OnboardingBeansConfig.class);

    @Bean
    @Primary
    public OnboardingRepositoryPort onboardingRepositoryPort (OnboardingMongoRepository mongoRepository, MongoTemplate mongoTemplate){
        log.info("Criando OnboardingRepositoryPort para Mongo DB");
        return new OnboardingRepositoryAdapter(mongoRepository, mongoTemplate);
    }

    @Bean
    @Primary
    public AntecipaOnboardingPort antecipaOnboardingPort(AntecipaClient antecipaClient, AuthenticationPort authenticationPort,
                                                         @Value("${api.antecipa.default-capital-source:17250006000110}") String defaultCapitalSourceDocument){
        log.info("Criando AntecipaOnboardingPort");
        log.info("Configurando para usar API Antecipa com CapitalSource padrão: {}", defaultCapitalSourceDocument);
        return new AntecipaOnboardingAdapter(antecipaClient,authenticationPort, defaultCapitalSourceDocument);
    }

    @Bean
    @Primary
    public OnboardingService onboardingService(
            OnboardingRepositoryPort onboardingRepositoryPort,
            AntecipaOnboardingPort antecipaOnboardingPort){
        log.info("Criando OnboardingService com integração API Antecipa");

        return new OnboardingServiceImpl(onboardingRepositoryPort, antecipaOnboardingPort);
    }

}
