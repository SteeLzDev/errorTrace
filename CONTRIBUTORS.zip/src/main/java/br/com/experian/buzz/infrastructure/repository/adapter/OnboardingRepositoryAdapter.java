package br.com.experian.buzz.infrastructure.repository.adapter;

import br.com.experian.buzz.domain.model.OnboardingStatusModel;
import br.com.experian.buzz.domain.port.OnboardingRepositoryPort;
import br.com.experian.buzz.infrastructure.repository.document.OnboardingDocument;
import br.com.experian.buzz.infrastructure.repository.OnboardingMongoRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import java.util.Optional;


//Implementa o port OnboardingRepositoryPort, converte entre o modelo de domínio e a entidade
public class OnboardingRepositoryAdapter implements OnboardingRepositoryPort {

    private static final Logger log = LoggerFactory.getLogger(OnboardingRepositoryAdapter.class);
    private final OnboardingMongoRepository mongoRepository;
    private final MongoTemplate mongoTemplate;

    public OnboardingRepositoryAdapter(OnboardingMongoRepository mongoRepository, MongoTemplate mongoTemplate) {
        this.mongoRepository = mongoRepository;
        this.mongoTemplate = mongoTemplate;
    }

    @Override
    public Optional<OnboardingStatusModel> findBySupplierDocument(String supplierDocument) {
        log.debug("Buscando onboarding no Banco para o documento: {}", supplierDocument);
         return mongoRepository.findBySupplierDocument(supplierDocument)
                 .map(this::documentToModel);
    }

    @Override
    public OnboardingStatusModel save (OnboardingStatusModel onboardingStatus) {
        log.debug("Salvando onboarding no Banco para o documento: {}", onboardingStatus.getSupplierDocument());
        Optional<OnboardingDocument> existingDocument = mongoRepository
                .findBySupplierDocument(onboardingStatus.getSupplierDocument());
        if (existingDocument.isPresent()) {
            return updateExistingDocument(existingDocument.get(), onboardingStatus);
        } else {
            return createNewDocument(onboardingStatus);
        }
    }

    private OnboardingStatusModel updateExistingDocument(OnboardingDocument existingDoc, OnboardingStatusModel model) {
        log.debug("Atualizando documento existente _id: {} para supplier_document: {}",
                existingDoc.getId(), model.getSupplierDocument());

        Query query = new Query(Criteria.where("supplier_document").is(model.getSupplierDocument()));
        Update update = new Update()
                .set("status", model.getStatus())
                .set("updated_at", model.getUpdatedAt());

        mongoTemplate.updateFirst(query, update, OnboardingDocument.class);

        Optional<OnboardingDocument> updatedDoc = mongoRepository.findBySupplierDocument(model.getSupplierDocument());
        if (updatedDoc.isPresent()) {
            log.debug("Documento atualizado com sucesso");
            return documentToModel(updatedDoc.get());
        }
        log.warn("Não foi possível buscar o documento atualizado, retornando modelo");
        return model;
    }

    private OnboardingStatusModel createNewDocument (OnboardingStatusModel model) {
        log.debug("Criando novo documento para supplier_document: {}", model.getSupplierDocument());

        OnboardingDocument document = modelToDocument(model);
        document.setId(null);

        OnboardingDocument savedDocument = mongoRepository.save(document);
        log.debug("Novo documento criado com _id: {}", savedDocument.getId());
        return documentToModel(savedDocument);
    }

    private OnboardingStatusModel documentToModel(OnboardingDocument document) {
        Long id = document.getId() != null ? (long) document.getId().hashCode() : null;
        return new OnboardingStatusModel(
                id,
                document.getSupplierDocument(),
                document.getStatus(),
                document.getCreatedAt(),
                document.getUpdatedAt()
        );
    }

    private OnboardingDocument modelToDocument(OnboardingStatusModel model) {
        OnboardingDocument document = new OnboardingDocument();

        document.setSupplierDocument(model.getSupplierDocument());
        document.setStatus(model.getStatus());
        document.setCreatedAt(model.getCreatedAt());
        document.setUpdatedAt(model.getUpdatedAt());
        return document;
    }





}
