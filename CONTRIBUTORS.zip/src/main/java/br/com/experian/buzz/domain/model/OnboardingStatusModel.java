package br.com.experian.buzz.domain.model;

import br.com.experian.buzz.domain.enums.OnboardingStatus;

import java.time.LocalDateTime;

public class OnboardingStatusModel {

    private Long id;
    private String supplierDocument;
    private OnboardingStatus status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public OnboardingStatusModel(){

    }

    public OnboardingStatusModel(String supplierDocument, OnboardingStatus status) {
        this.supplierDocument = supplierDocument;
        this.status = status;
        LocalDateTime now = LocalDateTime.now();
        this.createdAt = now;
        this.updatedAt = now;
    }

    public OnboardingStatusModel(Long id, String supplierDocument, OnboardingStatus status, LocalDateTime createdAt, LocalDateTime updatedAt) {
        this.id = id;
        this.supplierDocument = supplierDocument;
        this.status = status;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public void updateStatus(OnboardingStatus newStatus) {
        if (newStatus != null && !newStatus.equals(this.status)) {
            this.status = newStatus;
            this.updatedAt = LocalDateTime.now();
        }

    }

    public boolean hasStatus(){
        return this.status != null;
    }

    public boolean isStatusDifferent(OnboardingStatus otherStatus){
        return !this.status.equals(otherStatus);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSupplierDocument() {
        return supplierDocument;
    }

    public void setSupplierDocument(String supplierDocument) {
        this.supplierDocument = supplierDocument;
    }

    public OnboardingStatus getStatus() {
        return status;
    }

    public void setStatus(OnboardingStatus status) {
        this.status = status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public boolean equals (Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OnboardingStatusModel that = (OnboardingStatusModel) o;
        return supplierDocument != null ? supplierDocument.equals(that.supplierDocument)
                : that.supplierDocument == null;
    }

    @Override
    public int hashCode() {
        return supplierDocument != null ? supplierDocument.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "OnboardingStatusModel{" +
        "id=" +  id +
        ", supplierDocument='" + supplierDocument + '\'' +
        ", status=" + status +
        ", createdAt=" + createdAt +
        ", updatedAt=" + updatedAt +
        '}';
    }
}
