package br.com.experian.buzz.infrastructure.repository;

import br.com.experian.buzz.infrastructure.repository.document.OnboardingDocument;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface OnboardingMongoRepository extends MongoRepository<OnboardingDocument, String> {

    Optional<OnboardingDocument>findBySupplierDocument(String supplierDocument);
}
