package br.com.experian.buzz.infrastructure.integration.feign.client.antecipa;

import br.com.experian.antecipa.model.*;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "AntecipaClient", url ="${api.antecipa.base.uri}")
public interface AntecipaClient {

    //Consulta registro do fornecedor por CapitalSource
    @GetMapping("/Originators/CapitalSources/{CapitalSourceDocument}/Suppliers/{SupplierDocument}")
    @CircuitBreaker(name = "AntecipaClient")
    @Retry(name = "AntecipaClient")
    SupplierRegistrationDto getSupplierRegistration(
            @RequestHeader("Authorization") String bearerToken,
            @PathVariable("CapitalSourceDocument") String capitalSourceDocument,
            @PathVariable("SupplierDocument") String supplierDocument);

    //Adiciona novo fornecedor
    @PostMapping("/Originators/CapitalSources/{CapitalSourceDocument}/Suppliers")
    @CircuitBreaker(name = "AntecipaClient")
    @Retry(name = "AntecipaClient")
    BasicResultDto addSupplier(
            @RequestHeader("Authorization") String bearerToken,
            @PathVariable("CapitalSourceDocument") String capitalSourceDocument,
            @RequestBody SupplierAddCommandViewModel supplierAddCommand);

    //Listar Recebíveis de cartão com filtros
    @GetMapping("/Originators/CardReceivables/{SupplierDocument}")
    @CircuitBreaker(name = "AntecipaClient")
    @Retry(name = "AntecipaClient")
    CardReceivableListDtoPagedCollectionItems getCardReceivables(
            @RequestHeader("Authorization") String bearerToken,
            @PathVariable("SupplierDocument") String supplierDocument,
            @RequestParam(value = "StatusId", required = false) String statusId,
            @RequestParam(value = "AccreditingInstitutionDocument", required = false) String accreditingInstitutionDocument,
            @RequestParam(value = "CapitalSourceDocument", required = false) String capitalSourceDocument,
            @RequestParam(value = "StartDueDate", required = false) String startDueDate,
            @RequestParam(value = "EndDueDate", required = false) String endDueDate,
            @RequestParam(value = "OrderedBy", required = false) String orderedBy,
            @RequestParam(value = "PageId", required = false) String pageId,
            @RequestParam(value = "PageSize", required = false) Integer pageSize);


    //Busca recebível específico por ID
    @GetMapping("/Originators/CardReceivables/{SupplierDocument}/{Id}")
    @CircuitBreaker(name = "AntecipaClient")
    @Retry(name = "AntecipaClient")
    CardReceivableDto getCardReceivableById(
            @RequestHeader("Authorization") String bearerToken,
            @PathVariable("SupplierDocument") String supplierDocument,
            @PathVariable("Id") String id);

    //Simula antecipação de recebíveis
    @PostMapping("/Originators/CardReceivables/Anticipations/Simulate/{SupplierDocument}")
    @CircuitBreaker(name = "AntecipaClient")
    @Retry(name = "AntecipaClient")
    SimulationAnticipationCardReceivableDto simulate(
            @RequestHeader("Authorization") String bearerToken,
            @PathVariable("SupplierDocument") String supplierDocument,
            @RequestBody SimulateAnticipationCommandViewModel simulateAnticipationCommand);

    //Executa antecipação de recebíveis
    @PostMapping("/Originators/CardReceivables/Anticipations/Execute/{SupplierDocument}/{CapitalSourceDocument/{OfferId}")
    @CircuitBreaker(name = "AntecipaClient")
    @Retry(name = "AntecipaClient")
    void execute(
            @RequestHeader("Authorization") String bearerToken,
            @PathVariable("SupplierDocument") String supplierDocument,
            @PathVariable("CapitalSourceDocument") String capitalSourceDocument,
            @PathVariable("OfferId") String offerId);


    //Lista Antecipações com filtro
    @PostMapping("/Originators/CardReceivables/Anticipations/{SupplierDocument}")
    @CircuitBreaker(name = "AntecipaClient")
    @Retry(name = "AntecipaClient")
    AnticipationCardReceivableListDtoPagedCollectionItems getAnticipations(
            @RequestHeader("Authorization") String bearerToken,
            @PathVariable("SupplierDocument") String supplierDocument,
            @RequestParam(value = "CapitalSourceDocument", required = false) String capitalSourceDocument,
            @RequestParam(value = "AnticipationDate", required = false) String anticipationDate,
            @RequestParam(value = "StatusId", required = false) String statusId,
            @RequestParam(value = "PageId", required = false) String pageId,
            @RequestParam(value = "PageSize", required = false) Integer pageSize);

    //Busca antecipação específica por ID
    @GetMapping("/Originators/CardReceivables/Anticipations/{SupplierDocument}/{Id}")
    @CircuitBreaker(name = "AntecipaClient")
    @Retry(name = "AntecipaClient")
    AnticipationCardReceivableDto getAnticipationById(
            @RequestHeader("Authorization") String bearerToken,
            @PathVariable("SupplierDocument") String supplierDocument,
            @PathVariable("Id") String id);

}
