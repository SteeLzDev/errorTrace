package br.com.experian.buzz.infrastructure.repository.impl;

import br.com.experian.antecipa.model.*;
import br.com.experian.buzz.domain.exeption.FailedDependecyException;
import br.com.experian.buzz.domain.port.AuthenticationPort;
import br.com.experian.buzz.domain.service.AntecipaService;
import br.com.experian.buzz.infrastructure.integration.feign.client.antecipa.AntecipaClient;

import feign.FeignException;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AntecipaServiceImpl implements AntecipaService {

    private AntecipaClient antecipaClient;
    private final AuthenticationPort authenticationPort;
    private static final String FAILED_DEPENDENCY_MESSAGE = "Falha na comunicação com o serviço de antecipação. Por favor, tente novamente mais tarde.";
    private static final Logger log = LoggerFactory.getLogger(AntecipaServiceImpl.class);

    @Override
    @Retry(name = "AntecipaClient")
    public SimulationAnticipationCardReceivableDto simulate(String supplierDocument, SimulateAnticipationCommandViewModel command) {
        try {
            log.info("Iniciando simulação de antecipação para o documento: {}", supplierDocument);

            String bearerToken = "Bearer " + authenticationPort.getValidToken();

            SimulationAnticipationCardReceivableDto result = antecipaClient.simulate(bearerToken, supplierDocument, command);

            log.info("Simulação concluída com sucesso para documento: {}", supplierDocument);
            return result;

        } catch (FeignException e) {
            log.error("Erro ao  simular antecipação. Status: {}, Body: {}", e.status(), e.contentUTF8(), e);
            throw new FailedDependecyException(FAILED_DEPENDENCY_MESSAGE, e);
        }
    }

    @Override
    @Retry(name = "AntecipaClient")
    public void execute(String supplierDocument, String capitalSourceDocument, String offerId) {
        try {
            log.info("Iniciando a execução da antecipação para o documento : {}, CapitalSource: {}, Oferta: {}", supplierDocument, capitalSourceDocument, offerId);

            String bearerToken = "Bearer " + authenticationPort.getValidToken();

            antecipaClient.execute(bearerToken, supplierDocument, capitalSourceDocument, offerId);
            log.info("Antecipação executada com sucesso - Documento: {}, Oferta: {}", supplierDocument, offerId);

        } catch (FeignException e) {
            log.error("Erro ao chamar ao executar antecipação. Status: {}, Body: {}", e.status(), e.contentUTF8(), e);
            throw new FailedDependecyException(FAILED_DEPENDENCY_MESSAGE, e);
        }

    }

    @Override
    @Retry(name = "AntecipaClient")
    public AnticipationCardReceivableListDtoPagedCollectionItems getAnticipations(String supplierDocument, String capitalSourceDocument, String anticipationDate,
                                                                                  String statusId, String pageId, Integer pageSize) {
        try {
            log.info("Buscando antecipações para o documento: {}", supplierDocument);
            log.debug("Filtros - CapitalSource: {}, Data: {}, Status: {}, Página: {}, Tamanho: {}", capitalSourceDocument, anticipationDate, statusId, pageId, pageSize);

            String bearerToken = "Bearer " + authenticationPort.getValidToken();

             AnticipationCardReceivableListDtoPagedCollectionItems result = antecipaClient.getAnticipations(
                     bearerToken, supplierDocument, capitalSourceDocument, anticipationDate, statusId, pageId, pageSize);

             log.info("Antecipações encontradas para documento: {}", supplierDocument);
             return result;

        } catch (FeignException e) {
            log.error("Erro ao buscar antecipações. Status: {}, Body: {}", e.status(), e.contentUTF8(), e);
            throw new FailedDependecyException(FAILED_DEPENDENCY_MESSAGE, e);
        }

    }

    @Override
    @Retry(name = "AntecipaClient")
    public AnticipationCardReceivableDto getAnticipationById(String supplierDocument, String id) {
        try {
            log.info("Buscando antecipacões por ID {} para o documento: {}", id, supplierDocument);

            String bearerToken = "Bearer " + authenticationPort.getValidToken();

            AnticipationCardReceivableDto result = antecipaClient.getAnticipationById(bearerToken, supplierDocument, id);
            log.info("Antecipação encontrada - ID: {}, Documento: {}", id, supplierDocument);
            return result;

        } catch (FeignException e) {
            log.error("Erro ao buscar antecipações por ID. Status: {}, Body: {}", e.status(), e.contentUTF8(), e);
            throw new FailedDependecyException(FAILED_DEPENDENCY_MESSAGE, e);
        }

    }

    @Override
    @Retry(name = "AntecipaClient")
    public SupplierRegistrationDto getSupplier(String capitalSourceDocument, String supplierDocument) {
        try {
            log.info("Buscando Fornecedor - CapitalSource: {}, Documento: {}",capitalSourceDocument, supplierDocument);

            String bearerToken = "Bearer " + authenticationPort.getValidToken();

            SupplierRegistrationDto result =  antecipaClient.getSupplierRegistration(bearerToken, capitalSourceDocument, supplierDocument);
            log.info("Fornecedor encontrado Documento: {}", supplierDocument);
            return result;

        } catch (FeignException e) {
            log.error("Erro ao buscar fornecedor. Status: {}, Body: {}", e.status(), e.contentUTF8(), e);
            throw new FailedDependecyException(FAILED_DEPENDENCY_MESSAGE, e);
        }

    }

    @Override
    @Retry(name = "AntecipaClient")
    public BasicResultDto addSupplier(String capitalSourceDocument, SupplierAddCommandViewModel command) {
        try {
            log.info("Adicionando novo fornecedor -  CapitalSource: {}, Documento: {}", capitalSourceDocument, command.getDocument());

            String bearerToken = "Bearer " + authenticationPort.getValidToken();

            BasicResultDto result = antecipaClient.addSupplier(bearerToken, capitalSourceDocument, command);

            log.info("Fornecedor adicionado com sucesso - Documento: {}, ID: {}", command.getDocument(), result.getId());
            return result;

        } catch (FeignException e) {
            log.error("Erro ao adicionar fornecedor. Status: {}, Body: {}", e.status(), e.contentUTF8(), e);
            throw new FailedDependecyException(FAILED_DEPENDENCY_MESSAGE, e);
        }
    }

    @Override
    @Retry(name = "AntecipaClient")
    public CardReceivableListDtoPagedCollectionItems getCardReceivables(
            String supplierDocument, String statusId, String accreditingInstitutionDocument, String capitalSourceDocument,
            String startDueDate, String endDueDate, String orderedBy, String pageId, Integer pageSize) {
        try {
            log.info("Buscando recebíveis de cartão para documento : {}", supplierDocument);

            String bearerToken = "Bearer " + authenticationPort.getValidToken();
            log.debug("Filtros - Status: {}, Credenciadora: {}, CapitalSource: {}, Período {} a {}", statusId, accreditingInstitutionDocument,
                    capitalSourceDocument, startDueDate, endDueDate);
            CardReceivableListDtoPagedCollectionItems result = antecipaClient.getCardReceivables(bearerToken, supplierDocument, statusId,
                    accreditingInstitutionDocument, capitalSourceDocument, startDueDate, endDueDate, orderedBy, pageId, pageSize);

            log.info("Recebíveis encontrados para documento: {}", supplierDocument);
            return result;

        } catch (FeignException e) {
            log.error("Erro ao buscar  recebíveis de cartão. Status: {}, Body: {}", e.status(), e.contentUTF8(), e);
            throw new FailedDependecyException(FAILED_DEPENDENCY_MESSAGE, e);
        }
    }

    @Override
    @Retry(name = "AntecipaClient")
    public CardReceivableDto getCardReceivableById (String supplierDocument, String id) {
        try {
            log.info("Buscando recebível por ID {} para o ducumento: {}", id, supplierDocument);

            String bearerToken = "Bearer " + authenticationPort.getValidToken();

            CardReceivableDto result = antecipaClient.getCardReceivableById(bearerToken, supplierDocument, id);
            log.info("Recebível encontrado - ID {}, Documento: {} ", id, supplierDocument);
            return result;

        }catch (FeignException e) {
            log.error("Erro ao buscar recebível por ID. Status: {}, Body {}", e.status(), e.contentUTF8(), e);
            throw new FailedDependecyException(FAILED_DEPENDENCY_MESSAGE, e);
        }
    }


}
