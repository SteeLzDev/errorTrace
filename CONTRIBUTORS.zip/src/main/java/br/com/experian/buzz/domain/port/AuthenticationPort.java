package br.com.experian.buzz.domain.port;

import br.com.experian.buzz.domain.dto.response.AuthenticationResponseDto;

public interface AuthenticationPort {


    String getValidToken();


    String refreshToken();

    boolean isTokenValid();


}
