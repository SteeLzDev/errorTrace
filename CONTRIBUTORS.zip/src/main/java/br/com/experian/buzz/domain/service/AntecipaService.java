package br.com.experian.buzz.domain.service;


import br.com.experian.antecipa.model.*;

//Interface (Porta) define o contrato para as operações do Antecipa dentro do domínio da aplicação
public interface AntecipaService {

    SimulationAnticipationCardReceivableDto simulate (String supplierDocument, SimulateAnticipationCommandViewModel command);

    void execute (String supplierDocument, String capitalSourceDocument, String offerId);

    AnticipationCardReceivableListDtoPagedCollectionItems getAnticipations (String supplierDocument,
                                                                            String capitalSourceDocument,
                                                                            String anticipationDate,
                                                                            String statusId, String pageId,
                                                                            Integer pageSize);

    AnticipationCardReceivableDto getAnticipationById(String supplierDocument, String id);

    SupplierRegistrationDto getSupplier(String capitalSourceDocument, String supplierDocument);

    BasicResultDto addSupplier (String capitalSourceDocument, SupplierAddCommandViewModel command);

    CardReceivableListDtoPagedCollectionItems getCardReceivables(
            String supplierDocument,
            String statusId,
            String accreditingInstitutionDocument,
            String capitalSourceDocument,
            String startDueDate,
            String endDueDate,
            String orderedBy,
            String pageId,
            Integer pageSize);

    CardReceivableDto getCardReceivableById(String supplierDocument, String id);


}
