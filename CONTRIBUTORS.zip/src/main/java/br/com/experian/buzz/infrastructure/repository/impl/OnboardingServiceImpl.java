package br.com.experian.buzz.infrastructure.repository.impl;


import br.com.experian.buzz.domain.dto.response.OnboardingStatusResponseDto;
import br.com.experian.buzz.domain.enums.OnboardingStatus;
import br.com.experian.buzz.domain.model.OnboardingStatusModel;
import br.com.experian.buzz.domain.port.AntecipaOnboardingPort;
import br.com.experian.buzz.domain.port.OnboardingRepositoryPort;
import br.com.experian.buzz.domain.service.OnboardingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

public class OnboardingServiceImpl implements OnboardingService {

    private static final Logger log = LoggerFactory.getLogger(OnboardingServiceImpl.class);

    private OnboardingRepositoryPort onboardingRepositoryPort;
    private AntecipaOnboardingPort antecipaOnboardingPort;

    public OnboardingServiceImpl(OnboardingRepositoryPort onboardingRepositoryPort, AntecipaOnboardingPort antecipaOnboardingPort) {
        this.onboardingRepositoryPort = onboardingRepositoryPort;
        this.antecipaOnboardingPort = antecipaOnboardingPort;
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<OnboardingStatusResponseDto> getOnboardingStatus(String supplierDocument) {
        log.info("Consultando status de onboarding para documento: {}", supplierDocument);

        //1. Consultar se já existe status no banco de dados
        Optional<OnboardingStatusModel> existingOnboarding = onboardingRepositoryPort.findBySupplierDocument(supplierDocument);

        //2. Consultar Status na Antecipa (CERC)
        OnboardingStatus currentStatus = antecipaOnboardingPort.getOnboardingStatus(supplierDocument);

        //Se a API Retornar Null significa que não há onboarding (204 No Content)
        if (currentStatus == null) {
            log.info("API Antecipa retornou null - não há onboarding para documento: {}", supplierDocument);

            if (existingOnboarding.isPresent()) {
                log.info("Registro local existe mas API indica que há onboarding ativo para documento: {}", supplierDocument);
            }
            return Optional.empty();
        }
        log.info("Status atual da API Antecipa: {} para documento: {}", currentStatus, supplierDocument);

        //3. Atualizar o status no banco dependendo da resposta
        OnboardingStatusModel onboardingModel;

        if(existingOnboarding.isPresent()){
            OnboardingStatusModel existing = existingOnboarding.get();
            if (existing.isStatusDifferent(currentStatus)) {
                log.info("Atualizando status de {} para {} para documento: {}", existing.getStatus(), currentStatus, supplierDocument);
                existing.updateStatus(currentStatus);
                onboardingModel = onboardingRepositoryPort.save(existing);
            } else {
                log.info("Status já está atualizado: {} para documento {}", existing.getStatus(), supplierDocument);
                onboardingModel = existing;
            }

        } else {
            log.info("Criando novo registro de onboarding com status: {} para documento: {}", currentStatus, supplierDocument);
            onboardingModel = new OnboardingStatusModel(supplierDocument, currentStatus);
            onboardingModel = onboardingRepositoryPort.save(onboardingModel);
        }

        //4. Retornar resposta
        OnboardingStatusResponseDto response = new OnboardingStatusResponseDto(onboardingModel.getStatus());

        log.info("Status de onboarding retornado: {} para documento: {}", onboardingModel.getStatus(), supplierDocument);
        return Optional.of(response);

    }




}
