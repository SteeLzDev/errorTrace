package br.com.experian.buzz.infrastructure.config;

import br.com.experian.buzz.domain.port.AntecipaOnboardingPort;
import br.com.experian.buzz.domain.port.OnboardingRepositoryPort;
import br.com.experian.buzz.domain.service.OnboardingService;
import br.com.experian.buzz.infrastructure.repository.adapter.OnboardingRepositoryAdapter;
import br.com.experian.buzz.infrastructure.repository.OnboardingMongoRepository;
import br.com.experian.buzz.infrastructure.repository.impl.OnboardingServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.mongodb.core.MongoTemplate;

@Configuration
@ConditionalOnProperty(name = "database.type", havingValue = "mongodb")
public class OnboardingMongoConfig {

    private static final Logger log = LoggerFactory.getLogger(OnboardingMongoConfig.class);


    @Bean
    @Primary
    public OnboardingRepositoryPort onboardingRepositoryPort(OnboardingMongoRepository mongoRepository, MongoTemplate mongoTemplate) {
        log.info("Criando OnboardingRepositoryPort para Mongo DB");
        return new OnboardingRepositoryAdapter(mongoRepository, mongoTemplate);
    }

    @Bean
    @Primary
    public OnboardingService onboardingService(
            OnboardingRepositoryPort onboardingRepositoryPort,
            AntecipaOnboardingPort antecipaOnboardingPort) {
        log.info("Criando OnboardingService com Mongo DB");
        return new OnboardingServiceImpl(onboardingRepositoryPort, antecipaOnboardingPort);
    }



}
