package br.com.experian.buzz.infrastructure.integration.feign.client.antecipa.auth;

import feign.Logger;
import feign.Request;
import feign.Retryer;
import feign.codec.ErrorDecoder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.TimeUnit;

@Configuration
public class AntecipaAuthClientConfig {

    @Bean
    public Logger.Level authFeignLoggerLevel(){
        return Logger.Level.BASIC;
    }

    @Bean
    public ErrorDecoder authErrorDecoder() {
        return new ErrorDecoder.Default();
    }

    @Bean
    public Request.Options authRequestOptions(){
        return new Request.Options(5, TimeUnit.SECONDS, 10, TimeUnit.SECONDS, true);
    }

    @Bean
    public Retryer authRetryer(){
        return new Retryer.Default(100, TimeUnit.SECONDS.toMillis(1), 2);
    }


    }