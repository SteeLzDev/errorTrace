//package br.com.experian.buzz.infrastructure.integration.feign.client.antecipa;
//
//
//import br.com.experian.antecipa.model.SimulateAnticipationCommandViewModel;
//import br.com.experian.antecipa.model.SimulationAnticipationDto;
//import com.github.tomakehurst.wiremock.WireMockServer;
//import feign.Feign;
//import feign.codec.Decoder;
//import feign.codec.Encoder;
//import org.junit.After;
//import org.junit.Before;
//import org.junit.Test;
//
//import org.junit.runner.RunWith;
//import org.openapitools.jackson.nullable.JsonNullable;
//import org.springframework.beans.factory.ObjectFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.cloud.openfeign.support.ResponseEntityDecoder;
//import org.springframework.cloud.openfeign.support.SpringDecoder;
//import org.springframework.cloud.openfeign.support.SpringEncoder;
//import org.springframework.cloud.openfeign.support.SpringMvcContract;
//import org.springframework.http.MediaType;
//import org.springframework.test.context.junit4.SpringRunner;
//
//import java.util.Collections;
//import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.options;
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//import static com.github.tomakehurst.wiremock.client.WireMock.*;
//
//
////Init o contexto do Spring Boot, mas sem um servidor web real para a aplicação
//@RunWith(SpringRunner.class)
//@SpringBootTest
//public class AntecipaClientIntegrationTest {
//
//    @Autowired
//    private ObjectFactory<HttpMessageConverters> messageConverters;
//
//
//    private WireMockServer wireMockServer;
//    private AntecipaClient antecipaClient;
//
//    @Before
//   public void setup() {
//        wireMockServer = new WireMockServer(options().dynamicPort());
//        wireMockServer.start();
//        configureFor("localhost", wireMockServer.port());
//        Encoder encoder = new SpringEncoder(this.messageConverters);
//        Decoder decoder = new ResponseEntityDecoder(new SpringDecoder(this.messageConverters));
//        //Constrói o cliente Feign usando os beans injetados do Spring
//        antecipaClient = Feign.builder()
//                .contract(new SpringMvcContract())
//                .encoder(encoder)
//                .decoder(decoder)
//                .target(AntecipaClient.class, wireMockServer.baseUrl());
//    }
//
//    @After
//    public void tearDown() {
//        wireMockServer.stop();
//    }
//
//    @Test
//    public void shouldSimulateAndDeserializeResponseCorrectly() {
//        //Preparação do Servidor Mock
//        String supplierDocument = "12345678000195";
//        String responseBody = "{\"id\": \"sim-xyz\", \"assetsCount\" : 1, \"requestedAmount\": 100.50}";
//        stubFor(post(urlEqualTo("/Originators/Anticipation/" + supplierDocument + "/Simulate"))
//                .willReturn(aResponse()
//                        .withStatus(200)
//                        .withHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
//                        .withBody(responseBody)));
//        //Preparar Request que o cliente irá mandar
//        SimulateAnticipationCommandViewModel command = new SimulateAnticipationCommandViewModel();
//       command.setSupplierDocument(JsonNullable.of(supplierDocument));
//       command.setAssetsIds(JsonNullable.of(Collections.singletonList("asset-123")));
//
//
//        //Chamar Cliente Feign
//        SimulationAnticipationDto response = antecipaClient.simulate(supplierDocument, command);
//
//        //Verificação
//        assertNotNull(response);
//        assertEquals("sim-xyz", response.getId().get());
//        assertEquals(1, response.getAssetsCount());
//        assertEquals(100.50, response.getRequestedAmount());
//
//    }
//
//
//
//
//
//}
