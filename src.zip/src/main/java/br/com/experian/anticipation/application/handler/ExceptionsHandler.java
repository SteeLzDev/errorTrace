package br.com.experian.anticipation.application.handler;

import br.com.experian.anticipation.domain.exception.AbstractException;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

@Log4j2
@RestController
@ControllerAdvice
public class ExceptionsHandler {

    @ExceptionHandler(AbstractException.class)
    public ResponseEntity<ErrorMessage> handleAbstractException(AbstractException ex) {
        log.error(ex);
        return new ResponseEntity<>(new ErrorMessage(ex.getCode(), ex.getMessage()), ex.getHttpStatus());
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public List<ErrorMessage> handleMethodArgumentNotValidException(MethodArgumentNotValidException ex) {
        return ex.getBindingResult()
                .getAllErrors()
                .stream()
                .map(e -> ErrorMessage.builder()
                        .field(((FieldError) e).getField())
                        .message(e.getDefaultMessage())
                        .build())
                .collect(Collectors.toList());
    }

    @Getter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ErrorMessage {
        private Integer code;
        private String field;
        private String message;

        public ErrorMessage(String code, String message) {
            this.code = Integer.parseInt(code);
            this.message = message;
        }
    }
}