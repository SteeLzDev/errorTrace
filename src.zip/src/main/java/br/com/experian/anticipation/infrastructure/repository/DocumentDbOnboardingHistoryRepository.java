package br.com.experian.anticipation.infrastructure.repository;

import br.com.experian.anticipation.infrastructure.repository.document.OnboardingHistoryDocument;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DocumentDbOnboardingHistoryRepository extends MongoRepository<OnboardingHistoryDocument, String> {
}