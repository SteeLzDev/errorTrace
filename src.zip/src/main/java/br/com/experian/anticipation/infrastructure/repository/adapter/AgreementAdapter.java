package br.com.experian.anticipation.infrastructure.repository.adapter;

import br.com.experian.anticipation.domain.model.Agreement;
import br.com.experian.anticipation.infrastructure.repository.document.AgreementDocument;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class AgreementAdapter {

    public static Agreement build(AgreementDocument agreement) {
        return Agreement.builder()
                .id(agreement.getId())
                .userId(agreement.getUserId())
                .businessId(agreement.getBusinessId())
                .nationalRegistrationId(agreement.getNationalRegistrationId())
                .status(agreement.getStatus())
                .version(agreement.getVersion())
                .url(agreement.getUrl())
                .acceptedAt(agreement.getAcceptedAt())
                .revokedAt(agreement.getRevokedAt())
                .updatedAt(agreement.getUpdatedAt())
                .build();
    }
}