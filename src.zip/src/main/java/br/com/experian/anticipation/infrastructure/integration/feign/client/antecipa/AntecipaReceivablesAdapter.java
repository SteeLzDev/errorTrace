package br.com.experian.anticipation.infrastructure.integration.feign.client.antecipa;


import br.com.experian.anticipation.domain.constant.PaymentType;
import br.com.experian.anticipation.domain.dto.*;
import br.com.experian.anticipation.domain.model.ReceivablesPage;
import br.com.experian.anticipation.domain.port.AuthenticationPort;
import br.com.experian.anticipation.domain.port.ReceivablesPort;
import br.com.experian.anticipation.infrastructure.integration.feign.constant.Resilience4jConstant;
import br.com.experian.swagger.antecipa.model.AntecipaCardReceivableListDto;
import br.com.experian.swagger.antecipa.model.AntecipaCardReceivableListDtoPagedCollectionItems;
import br.com.experian.swagger.anticipation.model.PaymentTypeTO;
import feign.FeignException;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Log4j2
@Component
public class AntecipaReceivablesAdapter implements ReceivablesPort  {

    private static final String FAILED_DEPENDENCY_MESSAGE = "Failure in communication with the receivables service.";

    private final AntecipaClient antecipaClient;
    private final AuthenticationPort authenticationPort;

    public AntecipaReceivablesAdapter(AntecipaClient antecipaClient, AuthenticationPort authenticationPort) {
        this.antecipaClient = antecipaClient;
        this.authenticationPort = authenticationPort;
    }

    @Override
    @Retry(name = Resilience4jConstant.ANTECIPA_CERC)
    public Optional<ReceivablesPageDto> getReceivables(String supplierDocument, Integer limit, Integer offset) {
        try {
            log.info("Consulting receivables in the API for document: {} with limit: {} and offset: {}", supplierDocument, limit, offset);

            String bearerToken = "Bearer " + authenticationPort.getValidToken();

            String pageId = calculatePageId(offset, limit);

            AntecipaCardReceivableListDtoPagedCollectionItems response = antecipaClient.getCardReceivables(
                    bearerToken,
                    supplierDocument,
                    "1",
                    null,
                    null,
                    null,
                    null,
                    null,
                    pageId,
                    limit
            );
            if (response == null || response.getItems() == null || response.getItems().get().isEmpty()) {
                log.info("API returned no receivables for document: {}", supplierDocument);
                return Optional.empty();
            }

            ReceivablesPageDto receivablesPageDto = mapToReceivablesModel(response, limit, offset);

            log.info("Successfully retrieved {} receivables for document: {}", receivablesPageDto.getGroups().stream()
                    .mapToInt(ReceivablesGroupDto::getCount).sum(), supplierDocument);

            return Optional.of(receivablesPageDto);
        } catch (FeignException e) {
            log.error("Error querying receivables for document: {} - Status: {}, Message: {}", supplierDocument, e.status(), e.getMessage(), e);
            return Optional.empty();
        }
    }

    private String calculatePageId(Integer offset, Integer limit) {
        if (offset == null || limit == null || offset == 0) {
            return null;
        }
        return String.valueOf((offset / limit) + 1);
    }

    private ReceivablesPageDto mapToReceivablesModel(AntecipaCardReceivableListDtoPagedCollectionItems response, Integer limit, Integer offset) {

        List<AntecipaCardReceivableListDto> items = response.getItems().isPresent() ?
                response.getItems().get() : List.of();

       Map<LocalDate, List<ReceivablesPage>> receivablesByDate = items.stream()
               .map(this::mapToReceivableModel)
               .filter(receivable -> receivable.getPaymentDate() != null)
               .collect(Collectors.groupingBy(ReceivablesPage::getPaymentDate));
       log.info("Grouped receivables into {} different payment dates", receivablesByDate.size());

       List<ReceivablesGroupDto> groups = receivablesByDate.entrySet().stream()
               .sorted(Map.Entry.comparingByKey())
               .map(entry -> {
                   LocalDate date = entry.getKey();
                   List<ReceivablesPage> receivablesForDate = entry.getValue();
                   log.debug("Date: {} has {} receivables", date, receivablesForDate.size());
                   Double totalAmountToReceive = receivablesForDate.stream()
                           .mapToDouble(r -> r.getAmountToReceive() != null ? r.getAmountToReceive().doubleValue() : 0.0).sum();

                   return ReceivablesGroupDto.builder()
                           .date(date)
                           .receivables(receivablesForDate)
                           .count(receivablesForDate.size())
                           .totalAmountToReceive(totalAmountToReceive)
                           .build();
               })
               .collect(Collectors.toList());


        int currentPage = offset != null && limit != null ? (offset / limit) + 1 : 1;
        long totalElements = groups.stream().mapToInt(ReceivablesGroupDto::getCount).sum();
        int totalPages = limit != null ? (int) Math.ceil((double) totalElements / limit) : 1;

        PageDto pagination = PageDto.builder()
                .size(limit != null ? limit : (int) totalElements)
                .totalElements(totalElements)
                .totalPages(totalPages)
                .number(currentPage)
                .build();
        return ReceivablesPageDto.builder()
                .groups(groups)
                .page(pagination)
                .build();
    }

    private ReceivablesPage mapToReceivableModel(AntecipaCardReceivableListDto item) {
        PaymentTypeTO paymentTypeTO = mapPaymentType(item);
        return ReceivablesPage.builder()
                .id(item.getId() != null && item.getId().isPresent() ? item.getId().get() : null)
                .paymentDate(convertDueDateToLocalDate(item.getDueDate()))
                .nationalRegistrationId(extractNationalRegistrationId(item))
                .accreditingInstitutionName(extractAccreditingInstitutionName(item))
                .paymentTypeTO(paymentTypeTO)
                .paymentType(mapToPaymentTypeEnum(paymentTypeTO))
                .installment(mapInstallment(item))
                .discount(calculateDiscount(item))
                .amountToReceive(calculateAmountToReceive(item))
                .build();
    }

    private LocalDate convertPaymentDateToLocalDate(AntecipaCardReceivableListDto item) {
        if (item.getPaymentDate() == null || !item.getPaymentDate().isPresent()){
            return null;
        }
        try {
            String paymentDateStr = String.valueOf(item.getPaymentDate().get());
            if (paymentDateStr == null || paymentDateStr.isEmpty()) {
                return null;
            }
            return LocalDate.parse(paymentDateStr);
        } catch (Exception e) {
            log.warn("Erro parsing payment date: {}", item.getPaymentDate().orElse(null), e);
            return null;
        }
    }

    private LocalDate convertDueDateToLocalDate(LocalDateTime dueDate) {
        if (dueDate == null) {
            return null;
        }
        try {
            LocalDate converted = dueDate.toLocalDate();
            return converted;

        } catch (Exception e) {
            log.warn("Error parsing payment date: {}", dueDate, e);
            return null;
        }
    }

    private String extractNationalRegistrationId(AntecipaCardReceivableListDto item) {
        if (item.getSupplier() != null && item.getSupplier().getDocument() != null &&
        item.getSupplier().getDocument().isPresent()) {
            return item.getSupplier().getDocument().get();
        }
        return null;
    }

    private String extractAccreditingInstitutionName(AntecipaCardReceivableListDto item) {

        if (item.getAccreditingInstitution() != null &&
        item.getAccreditingInstitution().getName() != null &&
        item.getAccreditingInstitution().getName().isPresent()) {
            return item.getAccreditingInstitution().getName().get();
        }
        return null;

    }

    private PaymentTypeTO mapPaymentType(AntecipaCardReceivableListDto item) {
        return PaymentTypeTO.CREDIT_SINGLE;
    }

    private InstallmentDto mapInstallment (AntecipaCardReceivableListDto item) {
        return InstallmentDto.builder()
                .count(1)
                .number(1)
                .amount(item.getValue() != null ? BigDecimal.valueOf(item.getValue()) : BigDecimal.ZERO)
                .build();
    }

    private BigDecimal calculateDiscount(AntecipaCardReceivableListDto item) {
        if (item.getAnticipationSimulation() != null && item.getAnticipationSimulation().getDiscount() != null) {
            return BigDecimal.valueOf(item.getAnticipationSimulation().getDiscount());
        }
        return BigDecimal.ZERO;
    }

    private BigDecimal calculateAmountToReceive(AntecipaCardReceivableListDto item) {
        BigDecimal originalValue = item.getValue() != null ? BigDecimal.valueOf(item.getValue()) : BigDecimal.ZERO;
        BigDecimal discount = calculateDiscount(item);
        return originalValue.subtract(discount);
    }

    private PaymentType mapToPaymentTypeEnum(PaymentTypeTO paymentTypeTO) {
        if (paymentTypeTO == null){
            return null;
        }
        switch (paymentTypeTO) {
            case CREDIT_SINGLE:
                return PaymentType.CREDIT_SINGLE;
            case CREDIT_INSTALLMENT:
                return PaymentType.CREDIT_INSTALLMENT;
            default:
                return null;
        }
    }

}
