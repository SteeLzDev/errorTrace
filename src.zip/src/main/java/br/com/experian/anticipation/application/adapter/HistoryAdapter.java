package br.com.experian.anticipation.application.adapter;

import br.com.experian.swagger.anticipation.model.HistoryResponseTO;
import br.com.experian.swagger.anticipation.model.PaginationTO;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class HistoryAdapter {

    public static PaginationTO createPagination(Integer pageSize, Integer totalElements, Integer currentPage) {
        int size = pageSize != null ? pageSize : 1;
        int total = totalElements != null ? totalElements : 0;
        int page = currentPage != null ? currentPage : 1;
        int totalPages = size > 0 ? (int) Math.ceil((double) total / size) : 0;


        return new PaginationTO()
                .size(size)
                .totalElements(total)
                .totalPages(totalPages)
                .number(page);
    }

    public static void addPaginationToResponse(HistoryResponseTO response,
                                               Integer pageSize,
                                               Integer totalElements,
                                               Integer currentPage) {
        if (response == null) {
            return;
        }
        PaginationTO pagination = createPagination(pageSize, totalElements, currentPage);
        response.setPage(pagination);

    }


}
