package br.com.experian.anticipation.domain.dto;


import lombok.*;


@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ReceivableResponseDto {

    private ReceivablesPageDto receivables;


}
