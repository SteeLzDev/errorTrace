package br.com.experian.anticipation.domain.repository;

import br.com.experian.anticipation.domain.model.AnticipationHistory;

public interface AnticipationHistoryRepository {

    void save(AnticipationHistory anticipationHistory);
}
