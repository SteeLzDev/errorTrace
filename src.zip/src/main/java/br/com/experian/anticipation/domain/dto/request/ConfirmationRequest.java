package br.com.experian.anticipation.domain.dto.request;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class ConfirmationRequest {
    private String id;
    private String userId;
    private String nationalRegistrationId;
}