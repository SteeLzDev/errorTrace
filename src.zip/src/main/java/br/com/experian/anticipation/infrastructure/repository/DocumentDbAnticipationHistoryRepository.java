package br.com.experian.anticipation.infrastructure.repository;

import br.com.experian.anticipation.infrastructure.repository.document.AnticipationHistoryDocument;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DocumentDbAnticipationHistoryRepository extends MongoRepository<AnticipationHistoryDocument, String> {
}