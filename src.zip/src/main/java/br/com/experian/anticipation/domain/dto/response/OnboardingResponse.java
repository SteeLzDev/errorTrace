package br.com.experian.anticipation.domain.dto.response;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class OnboardingResponse {
    private String requestId;
    private String capitalSourceDocument;
    private String capitalSourceLogoUrl;
    private String capitalSourceRedirectUrl;
}