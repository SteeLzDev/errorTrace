package br.com.experian.anticipation.infrastructure.integration.feign.client.antecipa.auth;

import feign.auth.BasicAuthRequestInterceptor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;

class AntecipaAuthConfig {

    @Value("${api.antecipa.auth.username}")
    private String username;
    @Value("${api.antecipa.auth.password}")
    private String password;

    @Bean
    public BasicAuthRequestInterceptor basicAuthRequestInterceptor() {
        return new BasicAuthRequestInterceptor(this.username, this.password);
    }
}