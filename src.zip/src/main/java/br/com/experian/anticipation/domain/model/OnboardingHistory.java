package br.com.experian.anticipation.domain.model;

import lombok.Builder;
import lombok.Getter;

import java.time.LocalDateTime;

@Builder
@Getter
public class OnboardingHistory {
    private String id;
    private String userId;
    private String businessId;
    private String nationalRegistrationId;
    private CapitalSource capitalSource;
    @Builder.Default
    private LocalDateTime createdAt = LocalDateTime.now();

    public void capitalSource(String capitalSourceDocument, String requestId) {
        this.capitalSource = new CapitalSource(capitalSourceDocument, requestId);
    }

    public record CapitalSource(String document, String requestId) { }
}