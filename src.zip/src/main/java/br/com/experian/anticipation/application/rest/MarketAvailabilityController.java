package br.com.experian.anticipation.application.rest;

import br.com.experian.anticipation.domain.service.MarketAvailabilityService;
import br.com.experian.observability.annotation.LogMethod;
import br.com.experian.swagger.anticipation.api.MarketApi;
import lombok.extern.log4j.Log4j2;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RestController;

@Log4j2
@RestController
public class MarketAvailabilityController extends BaseController implements MarketApi {


    private final MarketAvailabilityService marketAvailabilityService;


    public MarketAvailabilityController(MarketAvailabilityService marketAvailabilityService) {
        this.marketAvailabilityService = marketAvailabilityService;
    }

    @Override
    @PreAuthorize(HAS_RULES)
    @LogMethod(LogMethod.LogType.FULL)
    public ResponseEntity<Void> checkMarketAvailability(){
        log.info("Checking market availability");

        boolean  isAvailable = this.marketAvailabilityService.isMarketAvailable();

        if (isAvailable) {
            log.info("Market is available - returning 204 No Content");
            return ResponseEntity.noContent().build();
        }
        log.info("Market is not available - returning 410 Gone");
        return ResponseEntity.status(410).build();
    }
}
