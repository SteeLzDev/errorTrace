package br.com.experian.anticipation.infrastructure.integration.feign.client.account;

import br.com.experian.pme.security.feign.FeignUserAuthRequestConfig;
import br.com.experian.swagger.digital.account.model.DigitalUserAccountAdminTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name = "DigitalAccountClient", url = "${api.digital.account.uri}", configuration = FeignUserAuthRequestConfig.class)
interface DigitalAccountClient {

    @GetMapping(value = "/user-accounts/me", consumes = "application/json")
    DigitalUserAccountAdminTO findMyUserAccount();
}