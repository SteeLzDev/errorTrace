package br.com.experian.anticipation.infrastructure.integration.feign.client.account;

import br.com.experian.swagger.digital.account.model.DigitalBusinessAccountTO;
import br.com.experian.pme.security.feign.FeignUserAuthRequestConfig;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "DigitalAccountClient", url = "${api.digital.account.uri}", configuration = FeignUserAuthRequestConfig.class)
interface DigitalAccountClient {

    @GetMapping(value = "/my-business-accounts/{businessId}", consumes = "application/json")
    DigitalBusinessAccountTO findByBusinessId(@PathVariable String businessId);
}