package br.com.experian.anticipation.domain.dto;



import lombok.*;

import java.util.List;

@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReceivablesPageDto {

    private List<ReceivablesGroupDto> groups;
    private PageDto page;
    private String pageNextId;



}
