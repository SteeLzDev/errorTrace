package br.com.experian.anticipation.domain.constant;

import lombok.Getter;

@Getter
public enum OnboardingStatus {

    STARTED("Iniciado"),
    REVIEW("Em revisão"),
    PENDING("Pendente"),
    APPROVED("Aprovado"),
    REJECTED("Rejeitado");

    private final String description;

    OnboardingStatus(String description) {
        this.description = description;
    }
}