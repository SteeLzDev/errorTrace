package br.com.experian.anticipation.domain.model;

import lombok.Builder;
import lombok.Getter;

import java.time.LocalDateTime;
import java.util.List;

@Builder
@Getter
public class AnticipationHistory {
    private String id;
    private String userId;
    private String businessId;
    private String nationalRegistrationId;
    private List<Offer> acceptedOffers;
    @Builder.Default
    private LocalDateTime createdAt = LocalDateTime.now();

    @Builder
    @Getter
    public static class Offer {
        private String id;
        private String requestId;
    }
}