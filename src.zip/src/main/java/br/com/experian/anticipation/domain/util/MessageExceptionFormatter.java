package br.com.experian.anticipation.domain.util;

import br.com.experian.util.PropertiesUtil;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.text.MessageFormat;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class MessageExceptionFormatter {

    public static String getMessage(String code) {
        return PropertiesUtil.getErrorMessage(code);
    }

    public static String getMessage(String code, String message) {
        return MessageFormat.format(getMessage(code), message);
    }
}