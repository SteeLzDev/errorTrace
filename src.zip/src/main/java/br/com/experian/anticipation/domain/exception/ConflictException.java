package br.com.experian.anticipation.domain.exception;

import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public class ConflictException extends AbstractException {

    public ConflictException(String code) {
        super(code, HttpStatus.CONFLICT);
    }
}