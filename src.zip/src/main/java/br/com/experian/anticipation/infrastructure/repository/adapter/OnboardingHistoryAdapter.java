package br.com.experian.anticipation.infrastructure.repository.adapter;

import br.com.experian.anticipation.domain.model.OnboardingHistory;
import br.com.experian.anticipation.infrastructure.repository.document.OnboardingHistoryDocument;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class OnboardingHistoryAdapter {

    public static OnboardingHistoryDocument build(OnboardingHistory onboardingHistory) {
        return OnboardingHistoryDocument.builder()
                .id(onboardingHistory.getId())
                .userId(onboardingHistory.getUserId())
                .businessId(onboardingHistory.getBusinessId())
                .nationalRegistrationId(onboardingHistory.getNationalRegistrationId())
                .capitalSource(onboardingHistory.getCapitalSource())
                .createdAt(onboardingHistory.getCreatedAt())
                .build();
    }
}