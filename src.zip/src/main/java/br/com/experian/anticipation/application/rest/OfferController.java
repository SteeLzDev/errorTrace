package br.com.experian.anticipation.application.rest;

import br.com.experian.anticipation.domain.service.OfferService;
import br.com.experian.observability.annotation.LogMethod;
import br.com.experian.swagger.anticipation.api.ConfirmApi;
import br.com.experian.swagger.anticipation.model.OfferRequestTO;
import lombok.extern.log4j.Log4j2;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RestController;

@Log4j2
@RestController
public class OfferController extends BaseController implements ConfirmApi {

    private final OfferService offerService;

    public OfferController(OfferService offerService) {
        this.offerService = offerService;
    }

    @Override
    @PreAuthorize(HAS_RULES)
    @LogMethod(LogMethod.LogType.FULL)
    public ResponseEntity<Void> confirmOffer(OfferRequestTO request) {
        this.offerService.confirm(request.getReceivableOfferIds());

        return ResponseEntity.noContent().build();
    }
}