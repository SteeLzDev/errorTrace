package br.com.experian.anticipation.domain.dto.response;


import br.com.experian.anticipation.domain.model.ReceivablesModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ReceivablesResponseDto {

    private ReceivablesModel receivables;

    public ReceivablesResponseDto(ReceivablesModel receivables) {
        this.receivables = receivables;
    }

}
