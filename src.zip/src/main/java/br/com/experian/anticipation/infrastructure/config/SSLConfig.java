package br.com.experian.anticipation.infrastructure.config;


import jakarta.annotation.PostConstruct;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import java.security.cert.X509Certificate;

@Configuration
@Profile({"default", "dev", "test"})
public class SSLConfig {

    @PostConstruct
    public void disableSSLValidation(){
        try{
            //TrustManager que aceita todos os certificados
            TrustManager[] trustAllCerts  = new TrustManager[] {
                    new TrustManager() {
                        public X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }
                        public void checkClientTrusted(X509Certificate[] certs, String authType){
                        }
                        public void checkServerTrusted(X509Certificate[] certs, String authType){
                        }
                    }
            };

            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            HostnameVerifier allHostValid = ((hostname, session) -> true);
            HttpsURLConnection.setDefaultHostnameVerifier(allHostValid);

            System.out.println("SSL Desativado para desenvolvimento");

        } catch (Exception e) {
            System.out.println("Falha ao desabilitar o validador de SSL " + e.getMessage());
        }
    }




}
