package br.com.experian.anticipation.domain.dto.response;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class UserAccount {
    private String fullName;
    private String document;
    private String email;
    private String phoneNumber;
}