package br.com.experian.anticipation.domain.client;

import br.com.experian.anticipation.domain.dto.response.BusinessRegistration;

public interface RegistrationClient {

    BusinessRegistration findBusinessInfo(String nationalRegistrationId);
}