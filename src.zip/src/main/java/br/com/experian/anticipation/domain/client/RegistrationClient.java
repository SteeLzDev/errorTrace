package br.com.experian.anticipation.domain.client;

import br.com.experian.anticipation.domain.dto.response.BusinessRegistration;
import br.com.experian.anticipation.domain.dto.response.PartnerAndManagerRegistration;

import java.util.List;

public interface RegistrationClient {

    BusinessRegistration findBusinessInfo(String nationalRegistrationId);

    List<PartnerAndManagerRegistration> findPartnersAndManagers(String nationalRegistrationId);
}