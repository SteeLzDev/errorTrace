package br.com.experian.anticipation.infrastructure.integration.feign.adapter;

import br.com.experian.anticipation.domain.dto.response.BusinessRegistration;
import br.com.experian.swagger.antecipa.model.AntecipaAddCapitalSourceSupplierRegistrationCommandViewModel;
import br.com.experian.swagger.antecipa.model.AntecipaSupplierAddressViewModel;
import br.com.experian.swagger.antecipa.model.AntecipaSupplierPartnerViewModel;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Objects;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class AntecipaAdapter {

    public static AntecipaAddCapitalSourceSupplierRegistrationCommandViewModel build(BusinessRegistration businessRegistration){
        return new AntecipaAddCapitalSourceSupplierRegistrationCommandViewModel()
                .name(businessRegistration.getCompanyName())
                .corporateName(businessRegistration.getCompanyName())
                .document(businessRegistration.getNationalRegistrationId())
                .email(businessRegistration.getEmail())
                .phoneNumber(businessRegistration.getPhoneNumber())
                .address(getAddress(businessRegistration.getAddress()))
                .partners(getPartners(businessRegistration.getPartners()));
    }

    private static AntecipaSupplierAddressViewModel getAddress(BusinessRegistration.Address address) {
        return Objects.nonNull(address) ? new AntecipaSupplierAddressViewModel()
                .street(address.getStreet())
                .number(address.getNumber())
                .complement(address.getComplement())
                .neighborhood(address.getNeighborhood())
                .city(address.getCity())
                .state(address.getState())
                .zipCode(address.getZipCode())
                .country(address.getCountry()) : null;
    }

    private static List<AntecipaSupplierPartnerViewModel> getPartners(List<BusinessRegistration.Partner> partners) {
        return partners
                .stream()
                .map(p -> new AntecipaSupplierPartnerViewModel()
                        .name(p.getFullName())
                        .document(p.getDocument())
                        .email(p.getEmail())
                        .phoneNumber(p.getPhoneNumber()))
                .toList();
    }
}