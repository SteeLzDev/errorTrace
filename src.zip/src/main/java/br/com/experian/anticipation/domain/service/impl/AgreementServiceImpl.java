package br.com.experian.anticipation.domain.service.impl;

import br.com.experian.anticipation.domain.exception.ConflictException;
import br.com.experian.anticipation.domain.model.Agreement;
import br.com.experian.anticipation.domain.repository.AgreementRepository;
import br.com.experian.anticipation.domain.service.AgreementService;
import br.com.experian.pme.security.user.UserSecurityService;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AgreementServiceImpl implements AgreementService {

    private final UserSecurityService userSecurityService;
    private final AgreementRepository agreementRepository;

    public AgreementServiceImpl(UserSecurityService userSecurityService,
                                AgreementRepository agreementRepository) {
        this.userSecurityService = userSecurityService;
        this.agreementRepository = agreementRepository;
    }

    @Override
    public Agreement getByLoggedUser() {
        return Optional
                .of(this.userSecurityService)
                .flatMap(uss -> this.agreementRepository.findByUserIdAndBusinessId(uss.getUserId(), uss.getBusinessId()))
                .orElseThrow(() -> new ConflictException("3"));
    }
}