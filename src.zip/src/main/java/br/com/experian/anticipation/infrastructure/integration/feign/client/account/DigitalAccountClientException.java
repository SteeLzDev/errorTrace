package br.com.experian.anticipation.infrastructure.integration.feign.client.account;

import br.com.experian.anticipation.domain.exception.AbstractException;
import org.springframework.http.HttpStatus;

class DigitalAccountClientException extends AbstractException {

    public DigitalAccountClientException(String code, String message) {
        super(code, message, HttpStatus.FAILED_DEPENDENCY);
    }
}