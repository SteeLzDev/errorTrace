//package br.com.experian.anticipation.infrastructure.config;
//
//import com.fasterxml.jackson.databind.DeserializationFeature;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import feign.codec.Decoder;
//import org.openapitools.jackson.nullable.JsonNullableModule;
//import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
//import org.springframework.cloud.openfeign.support.ResponseEntityDecoder;
//import org.springframework.cloud.openfeign.support.SpringDecoder;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
//
//import java.util.List;
//
//@Configuration
//public class FeignConfig {
//
//
//    @Bean
//    public Decoder feignDecoder() {
//        ObjectMapper mapper = new ObjectMapper()
//        .registerModule(new JsonNullableModule())
//                .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
//
//        MappingJackson2HttpMessageConverter jackson = new MappingJackson2HttpMessageConverter(mapper);
//
//        HttpMessageConverters converters = new HttpMessageConverters(false, List.of(jackson));
//
//        return new ResponseEntityDecoder(new SpringDecoder(() -> converters));
//    }
//}
