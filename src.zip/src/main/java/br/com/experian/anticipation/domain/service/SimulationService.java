package br.com.experian.anticipation.domain.service;

import br.com.experian.swagger.anticipation.model.SimulationRequestTO;
import br.com.experian.swagger.anticipation.model.SimulationResponseTO;

import java.util.Optional;

public interface SimulationService {


    Optional<SimulationResponseTO> simulate(SimulationRequestTO request);


}
