//package br.com.experian.anticipation.infrastructure.config;
//
//import com.fasterxml.jackson.databind.Module;
//import org.openapitools.jackson.nullable.JsonNullableModule;
//import org.springframework.boot.autoconfigure.jackson.Jackson2ObjectMapperBuilderCustomizer;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration(proxyBeanMethods = false)
//public class JacksonConfig {
//
//        @Bean
//        public Module jsonNullableModule() {
//            return new JsonNullableModule();
//        }
//
//        @Bean
//        public Jackson2ObjectMapperBuilderCustomizer jacksonCustomizer() {
//            return builder -> {
//                builder.modulesToInstall(new com.fasterxml.jackson.datatype.jsr310.JavaTimeModule());
//                builder.featuresToDisable(com.fasterxml.jackson.databind.SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
//            };
//        }
//    }