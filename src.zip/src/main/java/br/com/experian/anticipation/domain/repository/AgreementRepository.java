package br.com.experian.anticipation.domain.repository;

import br.com.experian.anticipation.domain.model.Agreement;

import java.util.Optional;

public interface AgreementRepository {

    Optional<Agreement> getUserAgreement();
}
