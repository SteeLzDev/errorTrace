package br.com.experian.anticipation.infrastructure.repository.document;

import br.com.experian.anticipation.domain.model.AnticipationHistory;
import lombok.Builder;
import lombok.Getter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.List;

@Builder
@Getter
@Document(collection = "AnticipationHistory")
public class AnticipationHistoryDocument {
    @Id
    private String id;
    private String userId;
    private String businessId;
    private String nationalRegistrationId;
    private List<AnticipationHistory.Offer> acceptedOffers;
    private LocalDateTime createdAt;
}