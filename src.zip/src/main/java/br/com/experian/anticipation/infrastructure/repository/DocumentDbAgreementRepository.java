package br.com.experian.anticipation.infrastructure.repository;

import br.com.experian.anticipation.infrastructure.repository.document.AgreementDocument;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface DocumentDbAgreementRepository extends MongoRepository<AgreementDocument, String> {
    Optional<AgreementDocument> findFirstByUserIdAndBusinessIdOrderByAcceptedAtDesc(String userId, String businessId);
}