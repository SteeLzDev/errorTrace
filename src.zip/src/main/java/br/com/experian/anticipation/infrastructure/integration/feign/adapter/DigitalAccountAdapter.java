package br.com.experian.anticipation.infrastructure.integration.feign.adapter;

import br.com.experian.anticipation.domain.dto.response.UserAccount;
import br.com.experian.swagger.digital.account.model.DigitalUserAccountAdminTO;
import br.com.experian.swagger.digital.account.model.DigitalUserMainEmailTO;
import br.com.experian.swagger.digital.account.model.DigitalUserMainPhoneTO;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.util.Objects;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class DigitalAccountAdapter {

    private static final String MISSING_VALUE = "missing_value";

    public static UserAccount build(DigitalUserAccountAdminTO userAccountTO) {
        return UserAccount.builder()
                .fullName(userAccountTO.getFullName())
                .document(userAccountTO.getDocument().getDocumentId())
                .email(getEmail(userAccountTO.getEmail()))
                .phoneNumber(getPhoneNumber(userAccountTO.getMobile()))
                .build();
    }

    private static String getEmail(DigitalUserMainEmailTO emailTO) {
        if (Objects.nonNull(emailTO)) {
            return emailTO.getEmail();
        } else {
            return MISSING_VALUE;
        }
    }

    private static String getPhoneNumber(DigitalUserMainPhoneTO mobileTO) {
        if (Objects.nonNull(mobileTO)) {
            return String.format("%s%s", mobileTO.getAreaCode(), mobileTO.getPhoneNumber());
        } else {
            return MISSING_VALUE;
        }
    }
}