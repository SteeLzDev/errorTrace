package br.com.experian.anticipation.infrastructure.repository.impl;

import br.com.experian.anticipation.domain.model.Agreement;
import br.com.experian.anticipation.domain.repository.AgreementRepository;
import br.com.experian.anticipation.infrastructure.repository.DocumentDbAgreementRepository;
import br.com.experian.anticipation.infrastructure.repository.adapter.AgreementAdapter;
import br.com.experian.pme.security.user.UserSecurityService;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class AgreementRepositoryImpl implements AgreementRepository {

    private final UserSecurityService userSecurityService;
    private final DocumentDbAgreementRepository documentDbAgreementRepository;

    public AgreementRepositoryImpl(UserSecurityService userSecurityService,
                                   DocumentDbAgreementRepository documentDbAgreementRepository) {
        this.userSecurityService = userSecurityService;
        this.documentDbAgreementRepository = documentDbAgreementRepository;
    }

    @Override
    public Optional<Agreement> getUserAgreement() {
        return Optional
                .of(this.userSecurityService)
                .flatMap(uss -> this.documentDbAgreementRepository
                .findFirstByUserIdAndBusinessIdOrderByAcceptedAtDesc(uss.getUserId(), uss.getBusinessId())
                .map(AgreementAdapter::build));
    }
}