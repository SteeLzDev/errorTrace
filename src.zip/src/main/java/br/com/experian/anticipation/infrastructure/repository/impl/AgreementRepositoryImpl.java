package br.com.experian.anticipation.infrastructure.repository.impl;

import br.com.experian.anticipation.domain.model.Agreement;
import br.com.experian.anticipation.domain.repository.AgreementRepository;
import br.com.experian.anticipation.infrastructure.repository.DocumentDbAgreementRepository;
import br.com.experian.anticipation.infrastructure.repository.adapter.AgreementAdapter;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class AgreementRepositoryImpl implements AgreementRepository {

    private final DocumentDbAgreementRepository agreementRepository;

    public AgreementRepositoryImpl(DocumentDbAgreementRepository agreementRepository) {
        this.agreementRepository = agreementRepository;
    }

    @Override
    public Optional<Agreement> findByUserIdAndBusinessId(String userId, String businessId) {
        return this.agreementRepository
                .findFirstByUserIdAndBusinessIdOrderByAcceptedAtDesc(userId, businessId)
                .map(AgreementAdapter::build);
    }
}