package br.com.experian.anticipation.domain.port;

import br.com.experian.anticipation.domain.dto.ReceivablesPageDto;

import java.util.Optional;

public interface ReceivablesPort {


    Optional<ReceivablesPageDto> getReceivables (String supplierDocument, Integer limit, Integer offset);
}
