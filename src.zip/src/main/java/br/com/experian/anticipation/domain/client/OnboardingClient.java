package br.com.experian.anticipation.domain.client;

import br.com.experian.anticipation.domain.constant.OnboardingStatus;
import br.com.experian.anticipation.domain.dto.response.BusinessRegistration;
import br.com.experian.anticipation.domain.dto.response.OnboardingResponse;

public interface OnboardingClient {

    OnboardingStatus getStatus(String supplierDocument);

    OnboardingResponse create(BusinessRegistration businessRegistration);
}