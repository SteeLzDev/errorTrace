package br.com.experian.anticipation.domain.client;

import br.com.experian.anticipation.domain.constant.OnboardingStatus;
import br.com.experian.anticipation.domain.dto.request.OnboardingRequest;

public interface OnboardingClient {

    OnboardingStatus getStatus(String supplierDocument);

    String create(OnboardingRequest onboardingRequest);
}