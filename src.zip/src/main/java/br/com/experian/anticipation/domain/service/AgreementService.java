package br.com.experian.anticipation.domain.service;

import br.com.experian.anticipation.domain.model.Agreement;

public interface AgreementService {

    Agreement getByLoggedUser();
}