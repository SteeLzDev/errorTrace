package br.com.experian.anticipation.application.adapter;

import br.com.experian.anticipation.domain.constant.PaymentType;
import br.com.experian.anticipation.domain.dto.InstallmentDto;
import br.com.experian.anticipation.domain.dto.PageDto;
import br.com.experian.anticipation.domain.dto.ReceivablesPageDto;
import br.com.experian.anticipation.domain.model.ReceivablesPage;
import br.com.experian.swagger.anticipation.model.*;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ReceivablesAdapter {

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");


    public static ReceivableGroupedResponseTO toGroupedResponseTO(ReceivablesPageDto receivables) {
        if (receivables == null) {
            return null;
        }
        List<ReceivableGroupTO> content = receivables.getGroups().stream()
                .map(group -> new ReceivableGroupTO()
                .paymentDate(group.getDate().format(DATE_FORMATTER))
                .count(group.getCount())
                .totalAmountToReceive(BigDecimal.valueOf(group.getTotalAmountToReceive()))
                .items(group.getReceivables().stream()
                        .map(ReceivablesAdapter::mapToReceivableDataTO)
                .collect(Collectors.toList())))
                .collect(Collectors.toList());

        PaginationTO pagination = receivables.getPage() != null
                ? mapToPagination(receivables.getPage())
                : createDefaultPagination();

        return new ReceivableGroupedResponseTO()
                .content(content)
                .page(pagination);
    }

    private static ReceivableDataTO mapToReceivableDataTO(ReceivablesPage model) {
        return new ReceivableDataTO()
                .id(model.getId())
                .accreditingInstitutionName(model.getAccreditingInstitutionName())
                .accreditingInstitutionDocument(model.getAccreditingInstitutionDocument())
                .paymentType(mapToPaymentTypeTO(model.getPaymentType()))
                .installment(mapToInstallmentDataTO(model.getInstallment()))
                .discount(model.getDiscount())
                .amountToReceive(model.getAmountToReceive());
    }

    private static PaymentTypeTO mapToPaymentTypeTO(PaymentType paymentType) {
        if (paymentType == null) {
            return null;
        }
        switch (paymentType) {
            case CREDIT_SINGLE:
                return PaymentTypeTO.CREDIT_SINGLE;
            case CREDIT_INSTALLMENT:
                return PaymentTypeTO.CREDIT_INSTALLMENT;
            default:
                throw new IllegalArgumentException("Unknown  PaymentType: " + paymentType);
        }
    }

    private static InstallmentDataTO mapToInstallmentDataTO(InstallmentDto model) {
        if (model == null) {
            return null;
        }
        return new InstallmentDataTO()
                .count(model.getCount())
                .number(model.getNumber())
                .amount(model.getAmount());

    }

    private static PaginationTO mapToPagination(PageDto model) {
        return new PaginationTO()
                .size(model.getSize())
                .totalElements(model.getTotalElements().intValue())
                .totalPages(model.getTotalPages())
                .number(model.getNumber());
    }

    private static PaginationTO createDefaultPagination() {
        return new PaginationTO()
                .size(10)
                .totalElements(0)
                .totalPages(0)
                .number(1);
    }


}
