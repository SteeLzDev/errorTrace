package br.com.experian.anticipation.application.rest;

import br.com.experian.anticipation.application.adapter.ReceivablesAdapter;
import br.com.experian.anticipation.domain.dto.ReceivableResponseDto;
import br.com.experian.anticipation.domain.dto.ReceivablesPageDto;
import br.com.experian.anticipation.domain.service.ReceivablesService;
import br.com.experian.observability.annotation.LogMethod;
import br.com.experian.swagger.anticipation.api.ReceivablesApi;
import br.com.experian.swagger.anticipation.model.PaginationTO;
import br.com.experian.swagger.anticipation.model.ReceivableGroupedResponseTO;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.Collections;
import java.util.Optional;


@RestController
public class ReceivablesController extends BaseController implements ReceivablesApi {

    private final ReceivablesService receivablesService;

    public ReceivablesController(ReceivablesService receivablesService) {
        this.receivablesService = receivablesService;
    }

    @Override
    @PreAuthorize(HAS_RULES)
    @LogMethod(LogMethod.LogType.FULL)
    public ResponseEntity<ReceivableGroupedResponseTO> findAvailables(LocalDate date, Integer limit, Integer offset) {

        final int pageLimit = limit != null ? limit : 10;
        final int pageOffset = offset != null ? offset : 1;

        Optional<ReceivableResponseDto> receivablesOptional = receivablesService.getReceivables(pageLimit, pageOffset);
        if (receivablesOptional.isEmpty()) {
            return ResponseEntity.ok(createEmptyGroupedResponseTO());
        }
        ReceivablesPageDto receivablesPageDto = receivablesOptional.get().getReceivables();

        ReceivableGroupedResponseTO response = ReceivablesAdapter.toGroupedResponseTO(receivablesPageDto);
        return ResponseEntity.ok(response);
    }

    private ReceivableGroupedResponseTO createEmptyGroupedResponseTO() {
        PaginationTO emptyPagination = new PaginationTO()
                .size(10)
                .totalElements(0)
                .totalPages(0)
                .number(0);

        return new ReceivableGroupedResponseTO()
                .content(Collections.emptyList())
                .page(emptyPagination);
    }
}
