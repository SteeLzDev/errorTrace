package br.com.experian.anticipation.domain.service.impl;

import br.com.experian.anticipation.domain.client.AccountClient;
import br.com.experian.anticipation.domain.client.OnboardingClient;
import br.com.experian.anticipation.domain.client.RegistrationClient;
import br.com.experian.anticipation.domain.constant.OnboardingStatus;
import br.com.experian.anticipation.domain.dto.OnboardingStatusResponseDto;
import br.com.experian.anticipation.domain.dto.response.BusinessRegistration;
import br.com.experian.anticipation.domain.dto.response.OnboardingResponse;
import br.com.experian.anticipation.domain.dto.response.UserAccount;
import br.com.experian.anticipation.domain.model.Agreement;
import br.com.experian.anticipation.domain.model.OnboardingHistory;
import br.com.experian.anticipation.domain.repository.OnboardingHistoryRepository;
import br.com.experian.anticipation.domain.service.AgreementService;
import br.com.experian.anticipation.domain.service.OnboardingService;
import br.com.experian.observability.annotation.LogMethod;
import lombok.extern.log4j.Log4j2;

import java.util.Optional;

@Log4j2
public class OnboardingServiceImpl implements OnboardingService {

    private final OnboardingClient onboardingClient;
    private final AccountClient accountClient;
    private final RegistrationClient registrationClient;
    private final AgreementService agreementService;
    private final OnboardingHistoryRepository onboardingHistoryRepository;

    public OnboardingServiceImpl(OnboardingClient onboardingClient,
                                 AccountClient accountClient,
                                 RegistrationClient registrationClient,
                                 AgreementService agreementService,
                                 OnboardingHistoryRepository onboardingHistoryRepository) {
        this.onboardingClient = onboardingClient;
        this.accountClient = accountClient;
        this.registrationClient = registrationClient;
        this.agreementService = agreementService;
        this.onboardingHistoryRepository = onboardingHistoryRepository;
    }

    @Override
    @LogMethod
    public Optional<OnboardingStatusResponseDto> getStatus() {
        Agreement agreement = this.agreementService.getByLoggedUser();

        OnboardingStatus onboardingStatus = this.onboardingClient.getStatus(agreement.getNationalRegistrationId());

        if (onboardingStatus == null) {
            log.info("API return 204 (no content) for document: {}", agreement.getNationalRegistrationId());
            return Optional.empty();
        }

        return Optional.of(new OnboardingStatusResponseDto(onboardingStatus));
    }

    @Override
    @LogMethod
    public OnboardingResponse execute() {
        Agreement agreement = this.agreementService.getByLoggedUser();

        UserAccount userAccount = this.accountClient.getMyUserAccount();

        BusinessRegistration businessRegistration = this.registrationClient.findBusinessInfo(agreement.getNationalRegistrationId());
        businessRegistration.addPartner(userAccount);

        OnboardingResponse onboardingResponse = this.onboardingClient.create(businessRegistration);

        OnboardingHistory onboardingHistory = OnboardingHistory.builder()
                .userId(agreement.getUserId())
                .businessId(agreement.getBusinessId())
                .nationalRegistrationId(agreement.getNationalRegistrationId())
                .build();

        onboardingHistory.capitalSource(onboardingResponse.getCapitalSourceDocument(), onboardingResponse.getRequestId());

        this.onboardingHistoryRepository.save(onboardingHistory);

        return onboardingResponse;
    }
}