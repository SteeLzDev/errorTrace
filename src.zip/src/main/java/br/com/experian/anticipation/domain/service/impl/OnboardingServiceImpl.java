package br.com.experian.anticipation.domain.service.impl;

import br.com.experian.anticipation.domain.client.AccountClient;
import br.com.experian.anticipation.domain.client.OnboardingClient;
import br.com.experian.anticipation.domain.client.RegistrationClient;
import br.com.experian.anticipation.domain.constant.OnboardingStatus;
import br.com.experian.anticipation.domain.dto.OnboardingStatusResponseDto;
import br.com.experian.anticipation.domain.dto.request.OnboardingRequest;
import br.com.experian.anticipation.domain.dto.response.BusinessRegistration;
import br.com.experian.anticipation.domain.dto.response.UserAccount;
import br.com.experian.anticipation.domain.exception.ConflictException;
import br.com.experian.anticipation.domain.model.Agreement;
import br.com.experian.anticipation.domain.repository.AgreementRepository;
import br.com.experian.anticipation.domain.service.OnboardingService;
import br.com.experian.observability.annotation.LogMethod;
import lombok.extern.log4j.Log4j2;

import java.net.URI;
import java.util.Optional;

@Log4j2
public class OnboardingServiceImpl implements OnboardingService {

    private final String capitalSourceDocument;
    private final String capitalSourceRedirect;

    private final OnboardingClient onboardingClient;
    private final AccountClient accountClient;
    private final RegistrationClient registrationClient;
    private final AgreementRepository agreementRepository;

    public OnboardingServiceImpl(String capitalSourceDocument,
                                 String capitalSourceRedirect,
                                 OnboardingClient onboardingClient,
                                 AccountClient accountClient,
                                 RegistrationClient registrationClient,
                                 AgreementRepository agreementRepository) {
        this.onboardingClient = onboardingClient;
        this.accountClient = accountClient;
        this.registrationClient = registrationClient;
        this.agreementRepository = agreementRepository;
        this.capitalSourceDocument = capitalSourceDocument;
        this.capitalSourceRedirect = capitalSourceRedirect;
    }

    @Override
    @LogMethod
    public Optional<OnboardingStatusResponseDto> getStatus() {
        Agreement agreement = this.getUserAgreement();

        OnboardingStatus onboardingStatus = this.onboardingClient.getStatus(agreement.getNationalRegistrationId());

        if (onboardingStatus == null) {
            log.info("API return 204 (no content) for document: {}", agreement.getNationalRegistrationId());
            return Optional.empty();
        }

        return Optional.of(new OnboardingStatusResponseDto(onboardingStatus));
    }

    @Override
    @LogMethod
    public URI execute() {
        Agreement agreement = this.getUserAgreement();

        UserAccount userAccount = this.accountClient.getMyUserAccount();

        BusinessRegistration businessInfo = this.registrationClient.findBusinessInfo(agreement.getNationalRegistrationId());
        businessInfo.addPartner(userAccount);

        OnboardingRequest onboardingRequest = OnboardingRequest.builder()
                .capitalSourceDocument(this.capitalSourceDocument)
                .businessRegistration(businessInfo)
                .build();

        String requestId = this.onboardingClient.create(onboardingRequest);
        //TODO: implementar service que irá registrar o pedido de onboarding no banco de dados;

        return URI.create(this.capitalSourceRedirect);
    }

    private Agreement getUserAgreement() {
        return this.agreementRepository.getUserAgreement().orElseThrow(() -> new ConflictException("3"));
    }
}