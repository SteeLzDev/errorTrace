package br.com.experian.anticipation.domain.exception;

import br.com.experian.anticipation.domain.util.MessageExceptionFormatter;
import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public abstract class AbstractException extends RuntimeException {

    private final String code;
    private final HttpStatus httpStatus;

    protected AbstractException(String code, HttpStatus httpStatus) {
        super(MessageExceptionFormatter.getMessage(code));
        this.code = code;
        this.httpStatus = httpStatus;
    }

    protected AbstractException(String code, String message, HttpStatus httpStatus) {
        super(MessageExceptionFormatter.getMessage(code, message));
        this.code = code;
        this.httpStatus = httpStatus;
    }
}