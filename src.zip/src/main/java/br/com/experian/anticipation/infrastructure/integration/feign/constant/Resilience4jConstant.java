package br.com.experian.anticipation.infrastructure.integration.feign.constant;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class Resilience4jConstant {

    public static final String ANTECIPA_CERC = "antecipa_cerc";
    public static final String DIGITAL_ACCOUNT = "digital-account";
    public static final String EITS_REGISTRATION = "eits-registration";
}