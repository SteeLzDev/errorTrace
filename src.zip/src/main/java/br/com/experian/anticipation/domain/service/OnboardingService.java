package br.com.experian.anticipation.domain.service;

import br.com.experian.anticipation.domain.dto.OnboardingStatusResponseDto;

import java.net.URI;
import java.util.Optional;

public interface OnboardingService {

    Optional<OnboardingStatusResponseDto> getStatus();

    URI execute();
}