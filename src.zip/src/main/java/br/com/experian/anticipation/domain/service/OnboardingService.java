package br.com.experian.anticipation.domain.service;

import br.com.experian.anticipation.domain.dto.OnboardingStatusResponseDto;
import br.com.experian.anticipation.domain.dto.response.OnboardingExecutionResponse;
import java.util.Optional;

public interface OnboardingService {

    Optional<OnboardingStatusResponseDto> getStatus();

    OnboardingExecutionResponse execute();
}