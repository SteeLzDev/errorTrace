package br.com.experian.anticipation.domain.service;

import br.com.experian.anticipation.domain.dto.OnboardingStatusResponseDto;
import br.com.experian.anticipation.domain.dto.response.OnboardingResponse;

import java.util.Optional;

public interface OnboardingService {

    Optional<OnboardingStatusResponseDto> getStatus();

    OnboardingResponse execute();
}