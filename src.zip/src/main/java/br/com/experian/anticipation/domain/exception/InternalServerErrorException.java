package br.com.experian.anticipation.domain.exception;

import org.springframework.http.HttpStatus;

public class InternalServerErrorException extends AbstractException {

    public InternalServerErrorException(String code, String message) {
        super(code, message, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}