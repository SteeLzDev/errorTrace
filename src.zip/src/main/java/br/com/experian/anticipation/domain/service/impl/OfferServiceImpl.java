package br.com.experian.anticipation.domain.service.impl;

import br.com.experian.anticipation.domain.client.OfferClient;
import br.com.experian.anticipation.domain.dto.request.ConfirmationRequest;
import br.com.experian.anticipation.domain.model.Agreement;
import br.com.experian.anticipation.domain.model.AnticipationHistory;
import br.com.experian.anticipation.domain.repository.AnticipationHistoryRepository;
import br.com.experian.anticipation.domain.service.AgreementService;
import br.com.experian.anticipation.domain.service.OfferService;
import br.com.experian.observability.annotation.LogMethod;
import lombok.extern.log4j.Log4j2;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Log4j2
public class OfferServiceImpl implements OfferService {

    private final OfferClient offerClient;
    private final AgreementService agreementService;
    private final AnticipationHistoryRepository anticipationHistoryRepository;

    public OfferServiceImpl(OfferClient offerClient,
                            AgreementService agreementService,
                            AnticipationHistoryRepository anticipationHistoryRepository) {
        this.offerClient = offerClient;
        this.agreementService = agreementService;
        this.anticipationHistoryRepository = anticipationHistoryRepository;
    }

    @Override
    @LogMethod(LogMethod.LogType.FULL)
    public void confirm(Set<String> offerIds) {
        Agreement userAgreement = this.agreementService.getByLoggedUser();

        List<AnticipationHistory.Offer> acceptedOffers = new ArrayList<>();

        for (String offerId : offerIds) {
            try {
                ConfirmationRequest confirmationRequest = ConfirmationRequest.builder()
                        .id(offerId)
                        .userId(userAgreement.getUserId())
                        .nationalRegistrationId(userAgreement.getNationalRegistrationId())
                        .build();

                String requestId = this.offerClient.confirmOffer(confirmationRequest);

                acceptedOffers.add(AnticipationHistory.Offer.builder()
                        .id(offerId)
                        .requestId(requestId)
                        .build()
                );
            } catch (Exception ex) {
                if (acceptedOffers.isEmpty()) {
                    throw ex;
                } else {
                    log.error("Failed to approve offer with ID [{}]. Exception: {}", offerId, ex.getMessage(), ex);
                }
            }
        }

        AnticipationHistory anticipationHistory = AnticipationHistory.builder()
                .userId(userAgreement.getUserId())
                .businessId(userAgreement.getBusinessId())
                .nationalRegistrationId(userAgreement.getNationalRegistrationId())
                .acceptedOffers(acceptedOffers)
                .build();

        this.anticipationHistoryRepository.save(anticipationHistory);
    }
}