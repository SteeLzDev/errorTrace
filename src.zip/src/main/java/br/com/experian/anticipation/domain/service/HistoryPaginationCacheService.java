package br.com.experian.anticipation.domain.service;


import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Log4j2
@Service
public class HistoryPaginationCacheService {


    //Cache: supplierId: Limit -> (offset - pageNextId)
    private final Map<String, Map<Integer, String>> paginationCache =  new ConcurrentHashMap<>();

    //Gera a chave do cache baseada no supplierId e limit

    private String generateCacheKey(String supplierId, Integer limit) {
        return supplierId + ":" + limit;
    }

    //Armazena o pageNextId para um determinado offset

    public void storePageNextId (String supplierId, Integer limit, Integer currentOffset, String pageNextId) {
        String cacheKey = generateCacheKey(supplierId, limit);
        paginationCache.computeIfAbsent(cacheKey, k -> new ConcurrentHashMap<>())
                .put(currentOffset, pageNextId);
        log.debug("Stored pageNextId for supplierId={}, limit{}, offset{}", supplierId, limit, currentOffset);
    }

    //recupera o pageNextId oara um determinado offset
    //paga offset=2, retorna o pageNextId da pagina 1
    String getPageNextId (String supplierId, Integer limit, Integer offset) {
        String cacheKey = generateCacheKey(supplierId, limit);
        Map<Integer, String> offsetMap = paginationCache.get(cacheKey);

        if (offsetMap == null) {
            log.debug("No cache found for supplierId={}, limit={}", supplierId, limit);

            return null;
        }

        //para offset=2, precisamos do pageNextId da pagina 1
        String pageNextId = offsetMap.get(offset - 1);
        log.debug("Retrieve pageNextId for supplierId={}, limit={}, offset{}: {}", supplierId, limit, offset, pageNextId != null ? "found" : "not found" );
        return pageNextId;
    }

    //limpa o cache para um determinado supplierId e limit

    public void clearCache (String supplierId, Integer limit) {
        String cacheKey = generateCacheKey(supplierId, limit);
        paginationCache.remove(cacheKey);
        log.debug("Cleared cache for supplierId={}, limit={}", supplierId, limit);
    }

    //limpa todo o cache
    public void chearAllCache() {
        paginationCache.clear();;
        log.info("Cleared all pagination cache");
    }


}
