package br.com.experian.anticipation.infrastructure.integration.feign.client.registration;

import br.com.experian.anticipation.domain.client.RegistrationClient;
import br.com.experian.anticipation.domain.dto.response.BusinessRegistration;
import br.com.experian.anticipation.domain.dto.response.PartnerAndManagerRegistration;
import br.com.experian.anticipation.domain.exception.InternalServerErrorException;
import br.com.experian.anticipation.infrastructure.integration.feign.adapter.EITSRegistrationAdapter;
import br.com.experian.anticipation.infrastructure.integration.feign.constant.Resilience4jConstant;
import br.com.experian.observability.annotation.LogMethod;
import br.com.experian.swagger.etis.registration.model.ETISPartnersAndManagersTO;
import feign.FeignException;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Log4j2
@Service
class EITSRegistrationClientServiceImpl implements RegistrationClient {

    private final String apiKey;
    private final String complement;
    private final EITSBusinessRegistrationClient businessRegistrationClient;
    private final EITSPartnersRegistrationClient partnersRegistrationClient;

    EITSRegistrationClientServiceImpl(@Value("${api.eits.api-key}") String apiKey,
                                      @Value("${api.eits.complement}") String complement,
                                      EITSBusinessRegistrationClient businessRegistrationClient,
                                      EITSPartnersRegistrationClient partnersRegistrationClient) {
        this.apiKey = apiKey;
        this.complement = complement;
        this.businessRegistrationClient = businessRegistrationClient;
        this.partnersRegistrationClient = partnersRegistrationClient;
    }

    @Override
    @LogMethod(LogMethod.LogType.FULL)
    @Retry(name = Resilience4jConstant.EITS_REGISTRATION)
    public BusinessRegistration findBusinessInfo(String nationalRegistrationId) {
        try {
            return EITSRegistrationAdapter.toBusiness(
                    this.businessRegistrationClient.findBusinessRegistration(apiKey, nationalRegistrationId, complement)
            );
        } catch (FeignException ex) {
            throw new EITSRegistrationClientException("1", "EITS:findBusinessInfo");
        }
    }

    @Override
    @LogMethod(LogMethod.LogType.FULL)
    @Retry(name = Resilience4jConstant.EITS_REGISTRATION)
    public List<PartnerAndManagerRegistration> findPartnersAndManagers(String nationalRegistrationId) {
        try {
            int offset = 0; int limit = 100;

            CompletableFuture<ETISPartnersAndManagersTO> futurePartners =
                    CompletableFuture.supplyAsync(() -> this.partnersRegistrationClient.findPartners(offset, limit, apiKey, nationalRegistrationId));

            CompletableFuture<ETISPartnersAndManagersTO> futureManagers =
                    CompletableFuture.supplyAsync(() -> this.partnersRegistrationClient.findAdministrators(offset, limit, apiKey, nationalRegistrationId));

            CompletableFuture.allOf(futurePartners, futureManagers).get();

            List<PartnerAndManagerRegistration> partnersAndManagers = new ArrayList<>();
            partnersAndManagers.addAll(EITSRegistrationAdapter.toPartnerAndManagers(futurePartners.get()));
            partnersAndManagers.addAll(EITSRegistrationAdapter.toPartnerAndManagers(futureManagers.get()));

            return partnersAndManagers;
        } catch (ExecutionException ex) {
            String errorMessage = "EITS:findPartnersAndManagers";
            if (ex.getCause() instanceof FeignException) {
                throw new EITSRegistrationClientException("1", errorMessage);
            } else {
                throw new EITSRegistrationClientException("2", errorMessage);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new InternalServerErrorException("2", "The current thread was interrupted while waiting.");
        }
    }
}