package br.com.experian.anticipation.infrastructure.integration.feign.client.registration;

import br.com.experian.anticipation.domain.client.RegistrationClient;
import br.com.experian.anticipation.domain.dto.response.BusinessRegistration;
import br.com.experian.anticipation.infrastructure.integration.feign.adapter.EITSRegistrationAdapter;
import br.com.experian.anticipation.infrastructure.integration.feign.constant.Resilience4jConstant;
import br.com.experian.observability.annotation.LogMethod;
import feign.FeignException;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Log4j2
@Service
class EITSRegistrationClientServiceImpl implements RegistrationClient {

    private final String apiKey;
    private final String complement;
    private final EITSBusinessRegistrationClient businessRegistrationClient;

    EITSRegistrationClientServiceImpl(@Value("${api.eits.api-key}") String apiKey,
                                      @Value("${api.eits.complement}") String complement,
                                      EITSBusinessRegistrationClient businessRegistrationClient) {
        this.apiKey = apiKey;
        this.complement = complement;
        this.businessRegistrationClient = businessRegistrationClient;
    }

    @Override
    @LogMethod(LogMethod.LogType.FULL)
    @Retry(name = Resilience4jConstant.EITS_REGISTRATION)
    public BusinessRegistration findBusinessInfo(String nationalRegistrationId) {
        try {
            return EITSRegistrationAdapter.toBusiness(
                    this.businessRegistrationClient.findBusinessRegistration(apiKey, nationalRegistrationId, complement)
            );
        } catch (FeignException ex) {
            throw new EITSRegistrationClientException("1", "EITS:findBusinessInfo");
        }
    }
}