package br.com.experian.anticipation.infrastructure.repository.impl;

import br.com.experian.anticipation.domain.model.AnticipationHistory;
import br.com.experian.anticipation.domain.repository.AnticipationHistoryRepository;
import br.com.experian.anticipation.infrastructure.repository.DocumentDbAnticipationHistoryRepository;
import br.com.experian.anticipation.infrastructure.repository.adapter.AnticipationHistoryAdapter;
import org.springframework.stereotype.Component;

@Component
public class AnticipationHistoryRepositoryImpl implements AnticipationHistoryRepository {

    private final DocumentDbAnticipationHistoryRepository anticipationOfferRepository;

    public AnticipationHistoryRepositoryImpl(DocumentDbAnticipationHistoryRepository anticipationOfferRepository) {
        this.anticipationOfferRepository = anticipationOfferRepository;
    }

    @Override
    public void save(AnticipationHistory anticipationHistory) {
        this.anticipationOfferRepository.save(AnticipationHistoryAdapter.build(anticipationHistory));
    }
}