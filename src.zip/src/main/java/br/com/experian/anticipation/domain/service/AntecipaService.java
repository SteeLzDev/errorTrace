package br.com.experian.anticipation.domain.service;


import br.com.experian.swagger.antecipa.model.*;


public interface AntecipaService {

    AntecipaSimulationAnticipationCardReceivableDto simulate (String supplierDocument, AntecipaSimulateAnticipationCommandViewModel command);

    void execute (String supplierDocument, String capitalSourceDocument, String offerId);

    AntecipaAnticipationCardReceivableListDtoPagedCollectionItems getAnticipations (String supplierDocument,
                                                                                    String capitalSourceDocument,
                                                                                    String anticipationDate,
                                                                                    String statusId, String pageId,
                                                                                    Integer pageSize);

    AntecipaAnticipationCardReceivableDto getAnticipationById(String supplierDocument, String id);

    AntecipaSupplierRegistrationDto getSupplier(String capitalSourceDocument, String supplierDocument);

    AntecipaBasicResultDto addSupplier (String capitalSourceDocument, AntecipaSupplierAddCommandViewModel command);

    AntecipaCardReceivableListDtoPagedCollectionItems getCardReceivables(
            String supplierDocument,
            String statusId,
            String accreditingInstitutionDocument,
            String capitalSourceDocument,
            String startDueDate,
            String endDueDate,
            String orderedBy,
            String pageId,
            Integer pageSize);

    AntecipaCardReceivableDto getCardReceivableById(String supplierDocument, String id);


}
