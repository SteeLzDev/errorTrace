package br.com.experian.anticipation.domain.client;

import br.com.experian.anticipation.domain.dto.response.UserAccount;

public interface AccountClient {

    UserAccount getMyUserAccount();
}