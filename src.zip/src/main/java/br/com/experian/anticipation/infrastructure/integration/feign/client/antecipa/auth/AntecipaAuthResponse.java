package br.com.experian.anticipation.infrastructure.integration.feign.client.antecipa.auth;

record AntecipaAuthResponse(String accessToken, String tokenType, long expiresIn) {

    public String getBearerToken() {
        return this.tokenType.concat(" ").concat(this.accessToken);
    }
}