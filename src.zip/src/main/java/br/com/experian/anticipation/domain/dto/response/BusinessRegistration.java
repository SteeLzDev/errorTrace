package br.com.experian.anticipation.domain.dto.response;

import lombok.Builder;
import lombok.Getter;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Getter
@Builder
public class BusinessRegistration {
    private String companyName;
    private String companyAlias;
    private String nationalRegistrationId;
    private String email;
    private String phoneNumber;
    private Address address;
    private List<Partner> partners;

    @Getter
    @Builder
    public static class Address {
        private String street;
        private String number;
        private String complement;
        private String neighborhood;
        private String city;
        private String state;
        private String zipCode;
        private String country;
    }

    @Getter
    @Builder
    public static class Partner {
        private String fullName;
        private String document;
        private String email;
        private String phoneNumber;
    }

    public void addPartner(UserAccount userAccount) {
        if (Objects.isNull(this.partners)) {
            this.partners = new ArrayList<>();
        }

        this.partners.add(Partner.builder()
                .fullName(userAccount.getFullName())
                .document(userAccount.getDocument())
                .email(userAccount.getEmail())
                .phoneNumber(userAccount.getPhoneNumber())
                .build());
    }
}