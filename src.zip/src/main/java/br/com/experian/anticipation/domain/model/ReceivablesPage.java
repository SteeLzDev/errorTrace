package br.com.experian.anticipation.domain.model;


import br.com.experian.anticipation.domain.constant.PaymentType;
import br.com.experian.anticipation.domain.dto.InstallmentDto;
import br.com.experian.swagger.anticipation.model.PaymentTypeTO;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReceivablesPage {

    private String id;
    private LocalDate paymentDate;
    private String nationalRegistrationId;
    private String accreditingInstitutionName;
    private String accreditingInstitutionDocument;
    private PaymentTypeTO paymentTypeTO;
    private InstallmentDto installment;
    private BigDecimal discount;
    private BigDecimal amountToReceive;
    private PaymentType paymentType;
}
