package br.com.experian.anticipation.infrastructure.integration.feign.client.registration;

import br.com.experian.pme.security.feign.FeignClientAuthRequestConfig;
import br.com.experian.swagger.etis.registration.model.ETISBusinessRegistrationDataTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name = "BusinessRegistrationClient", url = "${api.eits.business-registration}", configuration = FeignClientAuthRequestConfig.class)
public interface EITSBusinessRegistrationClient {

    @GetMapping(value = "/registration-data/documents-pj", consumes = "application/json")
    ETISBusinessRegistrationDataTO findBusinessRegistration(@RequestHeader("X-API-KEY") String apikey,
                                                            @RequestHeader("num_document") String numDocument,
                                                            @RequestHeader("complement") String complement
    );
}