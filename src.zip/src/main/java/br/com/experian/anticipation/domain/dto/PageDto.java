package br.com.experian.anticipation.domain.dto;


import lombok.*;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PageDto {

    private Integer size;
    private Long totalElements;
    private Integer totalPages;
    private Integer number;
}
