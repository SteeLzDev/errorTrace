package br.com.experian.anticipation.infrastructure.integration.feign.client.antecipa.auth;

import br.com.experian.anticipation.domain.exception.FailedDependencyException;
import br.com.experian.anticipation.infrastructure.integration.feign.constant.Resilience4jConstant;
import feign.FeignException;
import io.github.resilience4j.retry.annotation.Retry;
import org.springframework.stereotype.Service;

@Service
class AntecipaAuthServiceImpl implements AntecipaAuthService {

    private final AntecipaAuthClient antecipaAuthClient;

    public AntecipaAuthServiceImpl(AntecipaAuthClient antecipaAuthClient) {
        this.antecipaAuthClient = antecipaAuthClient;
    }

    @Override
    @Retry(name = Resilience4jConstant.ANTECIPA_CERC)
    public String getToken() {
        try {
            return this.antecipaAuthClient.signin().getBearerToken();
        } catch (FeignException ex) {
            throw new FailedDependencyException("1", "ANTECIPA:auth", ex);
        }
    }
}
