package br.com.experian.anticipation.domain.constant;

public enum PaymentType {

    CREDIT_SINGLE ,
    CREDIT_INSTALLMENT;
}
