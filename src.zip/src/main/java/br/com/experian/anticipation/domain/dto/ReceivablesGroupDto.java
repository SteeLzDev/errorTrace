package br.com.experian.anticipation.domain.dto;


import br.com.experian.anticipation.domain.model.ReceivablesPage;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReceivablesGroupDto {

    private LocalDate date;
    private List<ReceivablesPage> receivables;
    private Integer count;
    private Double totalAmountToReceive;

}
