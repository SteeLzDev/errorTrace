package br.com.experian.anticipation.domain.dto;


import br.com.experian.anticipation.domain.model.ReceivablesPage;
import lombok.*;
import java.time.LocalDate;
import java.util.List;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReceivablesGroupDto {

    private LocalDate date;
    private List<ReceivablesPage> receivables;
    private Integer count;
    private Double totalAmountToReceive;

}
