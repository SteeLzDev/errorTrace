package br.com.experian.anticipation.infrastructure.integration.feign.client.registration;

import br.com.experian.pme.security.feign.FeignClientAuthRequestConfig;
import br.com.experian.swagger.etis.registration.model.ETISPartnersAndManagersTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "PartnerAdminClient", url = "${api.eits.partners-registration}", configuration = FeignClientAuthRequestConfig.class)
public interface EITSPartnersRegistrationClient {

    @GetMapping(value = "/business/partners", consumes = "application/json")
    ETISPartnersAndManagersTO findPartners(@RequestParam("offset") int offset,
                                           @RequestParam("limit") int limit,
                                           @RequestHeader("X-API-KEY") String apiKey,
                                           @RequestHeader("documentId") String documentId
    );

    @GetMapping(value = "/business/administrators", consumes = "application/json")
    ETISPartnersAndManagersTO findAdministrators(@RequestParam("offset") int offset,
                                                 @RequestParam("limit") int limit,
                                                 @RequestHeader("X-API-KEY") String apiKey,
                                                 @RequestHeader("documentId") String documentId
    );
}