package br.com.experian.anticipation.application.rest;

import br.com.experian.anticipation.domain.dto.OnboardingStatusResponseDto;
import br.com.experian.anticipation.domain.service.OnboardingService;
import br.com.experian.observability.annotation.LogMethod;
import br.com.experian.swagger.anticipation.api.OnboardingApi;
import br.com.experian.swagger.anticipation.model.OnboardingResponseTO;
import br.com.experian.swagger.anticipation.model.OnboardingStatusTO;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;
import java.util.Optional;

@RestController
public class OnboardingController extends BaseController implements OnboardingApi {

    private final OnboardingService onboardingService;

    public OnboardingController(OnboardingService onboardingService) {
        this.onboardingService = onboardingService;
    }

    @Override
    @PreAuthorize(HAS_RULES)
    @LogMethod(LogMethod.LogType.FULL)
    public ResponseEntity<OnboardingResponseTO> retrieveStatus () {
        Optional<OnboardingStatusResponseDto> opt = this.onboardingService.getStatus();

        if (opt.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        OnboardingStatusResponseDto status = opt.get();
        OnboardingResponseTO body = new OnboardingResponseTO().status(OnboardingStatusTO.valueOf(status.getStatus().name()));
        return ResponseEntity.ok(body);
    }

    @Override
    @PreAuthorize(HAS_RULES)
    @LogMethod(LogMethod.LogType.FULL)
    public ResponseEntity<Void> accept() {
        URI location = this.onboardingService.execute();
        return ResponseEntity.noContent()
                .header(HttpHeaders.LOCATION, location.toString())
                .build();
    }
}