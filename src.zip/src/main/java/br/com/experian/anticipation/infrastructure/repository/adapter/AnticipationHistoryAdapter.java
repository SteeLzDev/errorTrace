package br.com.experian.anticipation.infrastructure.repository.adapter;

import br.com.experian.anticipation.domain.model.AnticipationHistory;
import br.com.experian.anticipation.infrastructure.repository.document.AnticipationHistoryDocument;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class AnticipationHistoryAdapter {

    public static AnticipationHistoryDocument build(AnticipationHistory anticipationHistory) {
        return AnticipationHistoryDocument.builder()
                .id(anticipationHistory.getId())
                .userId(anticipationHistory.getUserId())
                .businessId(anticipationHistory.getBusinessId())
                .nationalRegistrationId(anticipationHistory.getNationalRegistrationId())
                .acceptedOffers(anticipationHistory.getAcceptedOffers())
                .createdAt(anticipationHistory.getCreatedAt())
                .build();
    }
}