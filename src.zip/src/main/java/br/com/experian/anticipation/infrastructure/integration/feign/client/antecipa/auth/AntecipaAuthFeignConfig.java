package br.com.experian.anticipation.infrastructure.integration.feign.client.antecipa.auth;

import feign.RequestInterceptor;
import feign.RequestTemplate;
import org.springframework.context.annotation.Bean;

public class AntecipaAuthFeignConfig {

    @Bean
    AntecipaAuthInterceptor authenticationInterceptor(AntecipaAuthService antecipaAuthService) {
        return new AntecipaAuthInterceptor(antecipaAuthService);
    }

    record AntecipaAuthInterceptor(AntecipaAuthService antecipaAuthService) implements RequestInterceptor {

        @Override
            public void apply(RequestTemplate requestTemplate) {
                requestTemplate.header("Authorization", this.antecipaAuthService.getToken());
            }
        }
}