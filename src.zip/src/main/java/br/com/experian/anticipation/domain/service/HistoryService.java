package br.com.experian.anticipation.domain.service;

import br.com.experian.swagger.anticipation.model.HistoryResponseTO;

import java.util.Optional;

public interface HistoryService {

    Optional<HistoryResponseTO> findHistoryWithReceivables(String startAnticipationDate,
                                                           String endAnticipationDate,
                                                           String statusId,
                                                           String pageId,
                                                           Integer pageSize);

    Optional<HistoryResponseTO> findHistoryWithReceivables(String startAnticipationDate,
                                                           String endAnticipationDate,
                                                           String statusId,
                                                           Integer offset,
                                                           Integer limit);
}
