package br.com.experian.anticipation.domain.service;

import br.com.experian.anticipation.domain.model.HistoryDetailResponse;
import br.com.experian.swagger.anticipation.model.AnticipationDetailResponseTO;
import br.com.experian.swagger.anticipation.model.AnticipationHistoryResponseTO;

import java.util.Optional;

public interface HistoryService {

    Optional<AnticipationHistoryResponseTO> findHistoryPaginated(String capitalSourceDocument,
                                                        String startAnticipationDate,
                                                        String endAnticipationDate,
                                                        String statusId,
                                                        String pageId,
                                                        Integer pageSize);

    Optional<AnticipationDetailResponseTO> findHistoryDetailById(String id, String pageId, Integer pageSize);
}
