package br.com.experian.anticipation.domain.service;

import br.com.experian.swagger.anticipation.model.AnticipationDetailResponseTO;
import br.com.experian.swagger.anticipation.model.AnticipationHistoryResponseTO;

import java.util.Optional;

public interface HistoryService {

    Optional<AnticipationHistoryResponseTO> findHistory(String capitalSourceDocument,
                                                        String anticipationDate,
                                                        String statusId,
                                                        String pageId,
                                                        Integer pageSize);

    Optional<AnticipationDetailResponseTO> findHistoryById(String id);
}
