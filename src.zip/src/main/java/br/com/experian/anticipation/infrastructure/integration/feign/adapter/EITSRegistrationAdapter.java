package br.com.experian.anticipation.infrastructure.integration.feign.adapter;

import br.com.experian.anticipation.domain.dto.response.BusinessRegistration;
import br.com.experian.anticipation.domain.dto.response.PartnerAndManagerRegistration;
import br.com.experian.swagger.etis.registration.model.*;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class EITSRegistrationAdapter {

    private static final String MISSING_VALUE = "missing_value";

    public static BusinessRegistration toBusiness(ETISBusinessRegistrationDataTO  businessRegistrationTO) {
        return BusinessRegistration.builder()
                .companyName(businessRegistrationTO.getNaFullName())
                .companyAlias(businessRegistrationTO.getNaCompanyAlias())
                .nationalRegistrationId(businessRegistrationTO.getNuDocument())
                .phoneNumber(getPhoneNumber(businessRegistrationTO.getPhones()))
                .email(getEmail(businessRegistrationTO.getEmails()))
                .address(getAddress(businessRegistrationTO.getAddresses()))
                .build();
    }

    public static List<PartnerAndManagerRegistration> toPartnerAndManagers(ETISPartnersAndManagersTO partnerAndManagersTO) {
        return Optional.of(partnerAndManagersTO)
                .map(ETISPartnersAndManagersTO::getContent)
                .orElseGet(Collections::emptyList)
                .stream()
                .map(EITSRegistrationAdapter::buildPartnerAndManager)
                .toList();
    }

    private static String getPhoneNumber(List<ETISBusinessRegistrationDataPhoneTO> phones) {
        return phones
                .stream()
                .filter(p -> Integer.valueOf(1).equals(p.getNuPriority()))
                .findFirst()
                .map(phone -> String.format("%s%s", phone.getNuDddPhone(), phone.getNuPhone()))
                .orElse(MISSING_VALUE);
    }

    private static String getEmail(List<ETISBusinessRegistrationDataEmailTO> emails) {
        return emails
                .stream()
                .filter(p -> Integer.valueOf(1).equals(p.getNuPriority()))
                .findFirst()
                .map(ETISBusinessRegistrationDataEmailTO::getDeEmail)
                .orElse(MISSING_VALUE);
    }

    private static BusinessRegistration.Address getAddress(List<ETISBusinessRegistrationDataAddressTO> addresses) {
        return addresses
                .stream()
                .filter(p -> Integer.valueOf(1).equals(p.getNuPriority()))
                .findFirst()
                .map(address -> BusinessRegistration.Address.builder()
                        .street(address.getDeAddress())
                        .complement(address.getDeAddressComplement())
                        .neighborhood(address.getNaNeighborhood())
                        .city(address.getNaCity())
                        .state(address.getCoUf())
                        .zipCode(String.valueOf(address.getNuZipCode()))
                        .country("Brasil")
                        .build())
                .orElse(null);
    }

    private static PartnerAndManagerRegistration buildPartnerAndManager(ETISPartnerAndManagerTO partnerAndManagerTO) {
        return PartnerAndManagerRegistration.builder()
                .fullName(partnerAndManagerTO.getName())
                .document(Objects.nonNull(partnerAndManagerTO.getDocument()) ? partnerAndManagerTO.getDocument().getDocumentId() : MISSING_VALUE)
                .phoneNumber("219999-99999") //TODO: remover assim que o parceiro remover a exigência desse campo. ADD MISSING_VALUE
                .email(MISSING_VALUE)
                .build();
    }
}