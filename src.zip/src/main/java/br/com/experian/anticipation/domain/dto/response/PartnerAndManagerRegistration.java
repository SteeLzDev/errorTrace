package br.com.experian.anticipation.domain.dto.response;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Builder
public class PartnerAndManagerRegistration {
    private String fullName;
    private String document;
    @Setter
    private String email;
    @Setter
    private String phoneNumber;
}