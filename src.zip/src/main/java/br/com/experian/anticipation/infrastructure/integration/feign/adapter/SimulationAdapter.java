package br.com.experian.anticipation.infrastructure.integration.feign.adapter;

import br.com.experian.swagger.antecipa.model.AntecipaOfferAnnticipationCardReceivableDto;
import br.com.experian.swagger.antecipa.model.AntecipaSimulationAnticipationCardReceivableDto;
import br.com.experian.swagger.anticipation.model.BankAccountInfoTO;
import br.com.experian.swagger.anticipation.model.SimulationResponseTO;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.extern.log4j.Log4j2;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Log4j2
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class SimulationAdapter {


    public static SimulationResponseTO toSimulationResponse(List<AntecipaSimulationAnticipationCardReceivableDto> institutions) {
        log.info("Transforming Antecipa simulation response (array of institutions) to domain response");

        SimulationResponseTO response = new SimulationResponseTO();

        List<String> offerIds = new ArrayList<>();
        Set<String> cardBrands = new HashSet<>();
        List<BankAccountInfoTO> bankAccounts = new ArrayList<>();
        int totalReceivablesCount = 0;
        BigDecimal grossTotal = BigDecimal.ZERO;
        BigDecimal totalDiscount = BigDecimal.ZERO;
        BigDecimal netAmount = BigDecimal.ZERO;

        for (AntecipaSimulationAnticipationCardReceivableDto institution : institutions) {
            //Adicionar nome da credenciadora ao cardBrands
            if (institution.getAccreditingInstitution() != null
                    && institution.getAccreditingInstitution().getName() != null) {
                cardBrands.add(String.valueOf(institution.getAccreditingInstitution().getName()));
            }
            //Processar ofertas desta instituição
            if (institution.getOffers() != null) {
                for (AntecipaOfferAnnticipationCardReceivableDto offer : institution.getOffers()) {

                    //ADD ID da Oferta
                    if (offer.getId() != null) {
                        offerIds.add(offer.getId());
                    }


                    //Criar BankAccount com dados da oferta
                    BankAccountInfoTO bankAccount = new BankAccountInfoTO();
                    if (offer.getBankAccount() != null) {
                        bankAccount.setBankName(String.valueOf(offer.getBankAccount().getBankName()));
                        bankAccount.setAgencyNumber(formatAgency(offer.getBankAccount().getBranchNumber(),
                                offer.getBankAccount().getBranchDigit()
                        ));
                        bankAccount.setAccountNumber(formatAccount(
                                offer.getBankAccount().getAccountNumber(),
                                offer.getBankAccount().getAccountDigit()
                        ));
                    }

                    //creditedAmount = selectedAmount(valor com taxas)
                    BigDecimal creditedAmount = offer.getSelectedAmount() != null
                            ? BigDecimal.valueOf(offer.getSelectedAmount())
                            : BigDecimal.ZERO;
                    bankAccount.setCreditedAmount(creditedAmount);

                    //associatedBrand = nome da credenciadora desta oferta
                    if (institution.getAccreditingInstitution() != null
                            && institution.getAccreditingInstitution().getName() != null) {
                        bankAccount.setAssociatedBrand(String.valueOf(institution.getAccreditingInstitution().getName()));
                    }
                    bankAccounts.add(bankAccount);

                    //somar valores monetários
                    grossTotal = grossTotal.add(creditedAmount);

                    BigDecimal discount = offer.getDiscount() != null
                            ? BigDecimal.valueOf(offer.getDiscount())
                            : BigDecimal.ZERO;
                    totalDiscount = totalDiscount.add(discount);

                    BigDecimal finalAmount = offer.getFinalAmount() != null
                            ? BigDecimal.valueOf(offer.getFinalAmount())
                            : BigDecimal.ZERO;
                    netAmount = netAmount.add(finalAmount);

                    //Contar total de recebíveis
                    if (offer.getCardReceivables() != null) {
                        totalReceivablesCount += offer.getCardReceivables().size();
                    }
                }
            }
        }
            response.setReceivableOfferIds(offerIds);
            response.setCardBrands(new ArrayList<>(cardBrands));
            response.setBankAccounts(bankAccounts);
            response.setReceivablesCount(totalReceivablesCount);
            response.setGrossTotalAmount(grossTotal);
            response.setTotalDiscountAmount(totalDiscount);
            response.setNetAmountToReceive(netAmount);

            log.info("Transformation completed. Total offers: {}, Total receivables: {}",
                    offerIds.size(), totalReceivablesCount);
            return response;
        }

        private static String formatAgency (String branchNumber, String branchDigit){
            if (branchNumber == null) return "";
            if (branchDigit == null || branchDigit.isEmpty()) return branchNumber;
            return branchNumber + "-" + branchDigit;
        }

        private static String formatAccount (String accountNumber, String accountDigit){
            if (accountNumber == null) return "";
            if (accountDigit == null || accountDigit.isEmpty()) return accountNumber;
            return accountNumber + "-" + accountDigit;
        }


    }
