package br.com.experian.anticipation.domain.client;

import br.com.experian.anticipation.domain.dto.request.ConfirmationRequest;

public interface OfferClient {

    String confirmOffer(ConfirmationRequest confirmation);
}