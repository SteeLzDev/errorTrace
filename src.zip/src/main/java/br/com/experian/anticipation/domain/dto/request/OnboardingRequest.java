package br.com.experian.anticipation.domain.dto.request;

import br.com.experian.anticipation.domain.dto.response.BusinessRegistration;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class OnboardingRequest {
    private String capitalSourceDocument;
    private BusinessRegistration businessRegistration;
}