package br.com.experian.anticipation.infrastructure.integration.feign.client.antecipa;

import br.com.experian.swagger.antecipa.model.*;
import br.com.experian.anticipation.domain.exception.FailedDependecyException;
import br.com.experian.anticipation.domain.port.AuthenticationPort;
import br.com.experian.anticipation.domain.service.AntecipaService;

import feign.FeignException;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Log4j2
@Service
@RequiredArgsConstructor
public class AntecipaServiceImpl implements AntecipaService {

    private AntecipaClient antecipaClient;
    private final AuthenticationPort authenticationPort;
    private static final String FAILED_DEPENDENCY_MESSAGE = "Failure in communication with the anticipation service. Please try again later.";

    @Override
    @Retry(name = "AntecipaClient")
    public AntecipaSimulationAnticipationCardReceivableDto simulate(String supplierDocument, AntecipaSimulateAnticipationCommandViewModel command) {
        try {
            log.info("Initializing simulation for document: {}", supplierDocument);

            String bearerToken = "Bearer " + authenticationPort.getValidToken();

            AntecipaSimulationAnticipationCardReceivableDto result = antecipaClient.simulate(bearerToken, supplierDocument, command);

            log.info("Simulation successfully completed for document: {}", supplierDocument);
            return result;

        } catch (FeignException e) {
            log.error("Error when simulating anticipation: {}, Body: {}", e.status(), e.contentUTF8(), e);
            throw new FailedDependecyException(FAILED_DEPENDENCY_MESSAGE, e);
        }
    }

    @Override
    @Retry(name = "AntecipaClient")
    public void execute(String supplierDocument, String capitalSourceDocument, String offerId) {
        try {
            log.info("Initializing of anticipation execution for document : {}, CapitalSource: {}, Offer: {}", supplierDocument, capitalSourceDocument, offerId);

            String bearerToken = "Bearer " + authenticationPort.getValidToken();

            antecipaClient.execute(bearerToken, supplierDocument, capitalSourceDocument, offerId);
            log.info("Anticipation executed successfully - Document: {}, Offer: {}", supplierDocument, offerId);

        } catch (FeignException e) {
            log.error("Error when simulating anticipation: {}, Body: {}", e.status(), e.contentUTF8(), e);
            throw new FailedDependecyException(FAILED_DEPENDENCY_MESSAGE, e);
        }

    }

    @Override
    @Retry(name = "AntecipaClient")
    public AntecipaAnticipationCardReceivableListDtoPagedCollectionItems getAnticipations(String supplierDocument, String capitalSourceDocument, String anticipationDate,
                                                                                  String statusId, String pageId, Integer pageSize) {
        try {
            log.info("Looking for anticipations for document: {}", supplierDocument);
            log.debug("Filtros - CapitalSource: {}, Data: {}, Status: {}, Page: {}, Size: {}", capitalSourceDocument, anticipationDate, statusId, pageId, pageSize);

            String bearerToken = "Bearer " + authenticationPort.getValidToken();

            AntecipaAnticipationCardReceivableListDtoPagedCollectionItems result = antecipaClient.getAnticipations(
                     bearerToken, supplierDocument, capitalSourceDocument, anticipationDate, statusId, pageId, pageSize);

             log.info("Anticipations found for document: {}", supplierDocument);
             return result;

        } catch (FeignException e) {
            log.error("Error when searching for anticipations. Status: {}, Body: {}", e.status(), e.contentUTF8(), e);
            throw new FailedDependecyException(FAILED_DEPENDENCY_MESSAGE, e);
        }

    }

    @Override
    @Retry(name = "AntecipaClient")
    public AntecipaAnticipationCardReceivableDto getAnticipationById(String supplierDocument, String id) {
        try {
            log.info("Looking  anticipations for ID {} for document: {}", id, supplierDocument);

            String bearerToken = "Bearer " + authenticationPort.getValidToken();

            AntecipaAnticipationCardReceivableDto result = antecipaClient.getAnticipationById(bearerToken, supplierDocument, id);
            log.info("Anticipation found - ID: {}, Document: {}", id, supplierDocument);
            return result;

        } catch (FeignException e) {
            log.error("Error when searching anticipations by ID. Status: {}, Body: {}", e.status(), e.contentUTF8(), e);
            throw new FailedDependecyException(FAILED_DEPENDENCY_MESSAGE, e);
        }

    }

    @Override
    @Retry(name = "AntecipaClient")
    public AntecipaSupplierRegistrationDto getSupplier(String capitalSourceDocument, String supplierDocument) {
        try {
            log.info("Looking for supplier - CapitalSource: {}, Document: {}",capitalSourceDocument, supplierDocument);

            String bearerToken = "Bearer " + authenticationPort.getValidToken();

            AntecipaSupplierRegistrationDto result =  antecipaClient.getSupplierRegistration(bearerToken, capitalSourceDocument, supplierDocument);
            log.info("Supplier found Document: {}", supplierDocument);
            return result;

        } catch (FeignException e) {
            log.error("Error when searching for supplier. Status: {}, Body: {}", e.status(), e.contentUTF8(), e);
            throw new FailedDependecyException(FAILED_DEPENDENCY_MESSAGE, e);
        }

    }

    @Override
    @Retry(name = "AntecipaClient")
    public AntecipaBasicResultDto addSupplier(String capitalSourceDocument, AntecipaSupplierAddCommandViewModel command) {
        try {
            log.info("Added new supplier -  CapitalSource: {}, Document: {}", capitalSourceDocument, command.getDocument());

            String bearerToken = "Bearer " + authenticationPort.getValidToken();

            AntecipaBasicResultDto result = antecipaClient.addSupplier(bearerToken, capitalSourceDocument, command);

            log.info("Supplier successfully added - Document: {}, ID: {}", command.getDocument(), result.getId());
            return result;

        } catch (FeignException e) {
            log.error("Error adding supplier. Status: {}, Body: {}", e.status(), e.contentUTF8(), e);
            throw new FailedDependecyException(FAILED_DEPENDENCY_MESSAGE, e);
        }
    }

    @Override
    @Retry(name = "AntecipaClient")
    public AntecipaCardReceivableListDtoPagedCollectionItems getCardReceivables(
            String supplierDocument, String statusId, String accreditingInstitutionDocument, String capitalSourceDocument,
            String startDueDate, String endDueDate, String orderedBy, String pageId, Integer pageSize) {
        try {
            log.info("Searching for receivables from card to document : {}", supplierDocument);

            String bearerToken = "Bearer " + authenticationPort.getValidToken();
            log.debug("Filters - Status: {}, Accreditor: {}, CapitalSource: {}, Period {} a {}", statusId, accreditingInstitutionDocument,
                    capitalSourceDocument, startDueDate, endDueDate);
            AntecipaCardReceivableListDtoPagedCollectionItems result = antecipaClient.getCardReceivables(bearerToken, supplierDocument, statusId,
                    accreditingInstitutionDocument, capitalSourceDocument, startDueDate, endDueDate, orderedBy, pageId, pageSize);

            log.info("Receivables found for document: {}", supplierDocument);
            return result;

        } catch (FeignException e) {
            log.error("Error when searching for card receivables. Status: {}, Body: {}", e.status(), e.contentUTF8(), e);
            throw new FailedDependecyException(FAILED_DEPENDENCY_MESSAGE, e);
        }
    }

    @Override
    @Retry(name = "AntecipaClient")
    public AntecipaCardReceivableDto getCardReceivableById (String supplierDocument, String id) {
        try {
            log.info("Searching receivable for ID {} para o document: {}", id, supplierDocument);

            String bearerToken = "Bearer " + authenticationPort.getValidToken();

            AntecipaCardReceivableDto result = antecipaClient.getCardReceivableById(bearerToken, supplierDocument, id);
            log.info("Receivable found - ID {}, Documento: {} ", id, supplierDocument);
            return result;

        }catch (FeignException e) {
            log.error("Erro when searching for receivable by ID. Status: {}, Body {}", e.status(), e.contentUTF8(), e);
            throw new FailedDependecyException(FAILED_DEPENDENCY_MESSAGE, e);
        }
    }


}
