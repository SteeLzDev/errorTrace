package br.com.experian.anticipation.infrastructure.integration.feign.client.antecipa;

import br.com.experian.anticipation.domain.client.OfferClient;
import br.com.experian.anticipation.domain.client.OnboardingClient;
import br.com.experian.anticipation.domain.constant.OnboardingStatus;
import br.com.experian.anticipation.domain.dto.request.ConfirmationRequest;
import br.com.experian.anticipation.domain.dto.response.BusinessRegistration;
import br.com.experian.anticipation.domain.dto.response.OnboardingResponse;
import br.com.experian.anticipation.domain.exception.FailedDependencyException;
import br.com.experian.anticipation.infrastructure.integration.feign.adapter.AntecipaAdapter;
import br.com.experian.anticipation.infrastructure.integration.feign.constant.Resilience4jConstant;
import br.com.experian.observability.annotation.LogMethod;
import br.com.experian.swagger.antecipa.model.AntecipaAddCapitalSourceSupplierRegistrationCommandViewModel;
import br.com.experian.swagger.antecipa.model.AntecipaBasicResultDto;
import br.com.experian.swagger.antecipa.model.AntecipaExecuteAnticipationCardReceivableCommandViewModel;
import br.com.experian.swagger.antecipa.model.AntecipaSupplierRegistrationDto;
import feign.FeignException;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Log4j2
@Service
public class AntecipaServiceImpl implements OnboardingClient, OfferClient {

    private final String capitalSourceDocument;
    private final String capitalSourceLogoUrl;
    private final String capitalSourceRedirectUrl;
    private final AntecipaClient antecipaClient;

    public AntecipaServiceImpl(@Value("${api.onboarding.capital-source.document}") String capitalSourceDocument,
                               @Value("${api.onboarding.capital-source.logo.url}") String capitalSourceLogoUrl,
                               @Value("${api.onboarding.capital-source.redirect.url}") String capitalSourceRedirectUrl,
                               AntecipaClient antecipaClient) {
        this.capitalSourceDocument = capitalSourceDocument;
        this.capitalSourceLogoUrl = capitalSourceLogoUrl;
        this.capitalSourceRedirectUrl = capitalSourceRedirectUrl;
        this.antecipaClient = antecipaClient;
    }

    @Override
    @LogMethod(LogMethod.LogType.FULL)
    @Retry(name = Resilience4jConstant.ANTECIPA_CERC)
    public OnboardingStatus getStatus(String supplierDocument) {
        try {
            log.info("Consulting onboarding status in the API for document: {}", supplierDocument);

            AntecipaSupplierRegistrationDto supplierRegistration =
                    this.antecipaClient.getSupplierRegistration(this.capitalSourceDocument, supplierDocument);

            if(supplierRegistration == null) {
                log.info("API returned null there is no record for document:{} ", supplierDocument);
                return null;
            }

            String statusString = supplierRegistration.getStatus();
            Integer statusId = supplierRegistration.getStatusId();

            OnboardingStatus mappedStatus = mapApiStatusToEnum(statusString, statusId);

            log.info("Status obtained from the API: '{}' (ID: {}) -> Mapped to: {} for document: {}",
                    statusString,
                    statusId,
                    mappedStatus,
                    supplierDocument);

            return mappedStatus;

        } catch (FeignException e) {
            log.error("Error querying onboarding status in the API. Status: {}, Body: {}", e.status(), e.contentUTF8(), e);
            return null;
        }
    }

    @Override
    @LogMethod(LogMethod.LogType.FULL)
    @Retry(name = Resilience4jConstant.ANTECIPA_CERC)
    public OnboardingResponse create(BusinessRegistration businessRegistration) {
        try {
            AntecipaAddCapitalSourceSupplierRegistrationCommandViewModel command = AntecipaAdapter.build(businessRegistration);

            log.info("Added new supplier -  CapitalSource: {}, Document: {}", this.capitalSourceDocument, command.getDocument());

            AntecipaBasicResultDto result = this.antecipaClient.addSupplier(this.capitalSourceDocument, command);

            log.info("Supplier successfully added - Document: {}, ID: {}", command.getDocument(), result.getId());

            return OnboardingResponse.builder()
                    .requestId(result.getId())
                    .capitalSourceDocument(this.capitalSourceDocument)
                    .capitalSourceLogoUrl(this.capitalSourceLogoUrl)
                    .capitalSourceRedirectUrl(this.capitalSourceRedirectUrl)
                    .build();

        } catch (FeignException e) {
            log.error("Error adding supplier. Status: {}, Body: {}", e.status(), e.contentUTF8(), e);
            throw new FailedDependencyException("1", "ANTECIPA:create");
        }
    }

    private OnboardingStatus mapApiStatusToEnum(String status, Integer statusId) {
        log.debug("Mapped API status with ID: '{}' with ID: {}", status, statusId);

        //priorizar mapeamento por statusId
        if (statusId != null) {
            switch (statusId) {
                case 1:
                    return OnboardingStatus.STARTED; //New
                case 2:
                    return OnboardingStatus.PENDING; //In Review
                case 3:
                    return OnboardingStatus.PENDING; //Pending
                case 4:
                    return OnboardingStatus.APPROVED; //Approved
                case 5:
                    return OnboardingStatus.REJECTED; // Blocked
                case 99:
                    return OnboardingStatus.PENDING; //ContractSent
                default:
                    log.warn("Unknown ID Status: {}, trying map by string", statusId);
            }
        }

        //Padrão, se não conseguir mapear, assumir PENDING
        log.warn("Unable to map status: '{}' (ID: {}). Using PENDING as default.", status, statusId);
        return OnboardingStatus.PENDING;
    }

    @Override
    @LogMethod(LogMethod.LogType.FULL)
    @Retry(name = Resilience4jConstant.ANTECIPA_CERC)
    public String confirmOffer(ConfirmationRequest confirmation) {
        try {
            AntecipaBasicResultDto response = this.antecipaClient.execute(
                    confirmation.getNationalRegistrationId(),
                    confirmation.getId(),
                    new AntecipaExecuteAnticipationCardReceivableCommandViewModel(confirmation.getUserId())
            );

            return response.getId();
        } catch (FeignException ex) {
            throw new FailedDependencyException("1", "ANTECIPA:confirmOffer");
        }
    }
}