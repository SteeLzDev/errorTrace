package br.com.experian.anticipation.infrastructure.integration.feign.client.antecipa;

import br.com.experian.anticipation.domain.client.OnboardingClient;
import br.com.experian.anticipation.domain.constant.OnboardingStatus;
import br.com.experian.anticipation.domain.dto.request.OnboardingRequest;
import br.com.experian.anticipation.domain.exception.FailedDependecyException;
import br.com.experian.anticipation.domain.port.AuthenticationPort;
import br.com.experian.anticipation.infrastructure.integration.feign.adapter.AntecipaAdapter;
import br.com.experian.anticipation.infrastructure.integration.feign.constant.Resilience4jConstant;
import br.com.experian.observability.annotation.LogMethod;
import br.com.experian.swagger.antecipa.model.*;
import feign.FeignException;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Log4j2
@Service
public class AntecipaServiceImpl implements OnboardingClient {

    private static final String FAILED_DEPENDENCY_MESSAGE = "Failure in communication with the anticipation service. Please try again later.";

    private final AntecipaClient antecipaClient;
    private final AuthenticationPort authenticationPort;
    private final String defaultCapitalSourceDocument;

    public AntecipaServiceImpl(AuthenticationPort authenticationPort, AntecipaClient antecipaClient,
                               @Value("${api.onboarding.capital-source.document}") String capitalSourceDocument) {
        this.authenticationPort = authenticationPort;
        this.defaultCapitalSourceDocument = capitalSourceDocument;
        this.antecipaClient = antecipaClient;
    }

    @Override
    @LogMethod(LogMethod.LogType.FULL)
    @Retry(name = Resilience4jConstant.ANTECIPA_CERC)
    public OnboardingStatus getStatus(String supplierDocument) {
        try {
            log.info("Consulting onboarding status in the API for document: {}", supplierDocument);

            //Obter token válido
            String bearerToken = "Bearer " + authenticationPort.getValidToken();
            log.debug("Token obtained for authentication");

            AntecipaSupplierRegistrationDto supplierRegistration = antecipaClient.getSupplierRegistration(
                    bearerToken,
                    defaultCapitalSourceDocument,
                    supplierDocument
            );

            if(supplierRegistration == null) {
                log.info("API returned null there is no record for document:{} ", supplierDocument);
                return null;
            }

            String statusString = supplierRegistration.getStatus();
            Integer statusId = supplierRegistration.getStatusId();

            OnboardingStatus mappedStatus = mapApiStatusToEnum(statusString, statusId);

            log.info("Status obtained from the API: '{}' (ID: {}) -> Mapped to: {} for document: {}",
                    statusString,
                    statusId,
                    mappedStatus,
                    supplierDocument);

            return mappedStatus;

        } catch (FeignException e) {
            log.error("Error querying onboarding status for API. Status: {}, Body: {}",
                    e.status(), e.contentUTF8(), e);

            if(e.status() == 401) {
                log.info("Invalid token, trying to renew...");
                authenticationPort.refreshToken();
                throw new FailedDependecyException("Invalid authentication token", e);
            }

            if (e.status() == 404 || e.status() == 204) {
                log.info("Supplier not found in the API - there is no onboarding for document: {}", supplierDocument);

                return null;
            }
            throw new FailedDependecyException(FAILED_DEPENDENCY_MESSAGE, e);
        }
    }

    @Override
    @LogMethod(LogMethod.LogType.FULL)
    @Retry(name = Resilience4jConstant.ANTECIPA_CERC)
    public String create(OnboardingRequest onboardingRequest) {
        try {
            String capitalSourceDocument = onboardingRequest.getCapitalSourceDocument();

            AntecipaSupplierAddCommandViewModel command = AntecipaAdapter.build(onboardingRequest.getBusinessRegistration());

            log.info("Added new supplier -  CapitalSource: {}, Document: {}", capitalSourceDocument, command.getDocument());

            String bearerToken = "Bearer " + authenticationPort.getValidToken();

            AntecipaBasicResultDto result = antecipaClient.addSupplier(bearerToken, capitalSourceDocument, command);

            log.info("Supplier successfully added - Document: {}, ID: {}", command.getDocument(), result.getId());
            return result.getId();

        } catch (FeignException e) {
            log.error("Error adding supplier. Status: {}, Body: {}", e.status(), e.contentUTF8(), e);
            throw new FailedDependecyException(FAILED_DEPENDENCY_MESSAGE, e);
        }
    }

    private OnboardingStatus mapApiStatusToEnum(String status, Integer statusId) {
        log.debug("Mapped API status with ID: '{}' with ID: {}", status, statusId);

        //priorizar mapeamento por statusId
        if (statusId != null) {
            switch (statusId) {
                case 1:
                    return OnboardingStatus.APPROVED; //Active
                case 2:
                    return OnboardingStatus.PENDING; //Pending
                case 3:
                    return OnboardingStatus.REJECTED; //Inactive
                case 4:
                    return OnboardingStatus.STARTED; //InAnalysis
                case 5:
                    return OnboardingStatus.REVIEW; //InReview
                default:
                    log.warn("Unknown ID Status: {}, trying map by string", statusId);
            }
        }

        //Padrão, se não conseguir mapear, assumir PENDRING
        log.warn("Unable to map status: '{}' (ID: {}). Using PENDING as default.", status, statusId);
        return OnboardingStatus.PENDING;
    }

    @LogMethod(LogMethod.LogType.FULL)
    @Retry(name = Resilience4jConstant.ANTECIPA_CERC)
    public AntecipaSimulationAnticipationCardReceivableDto simulate(String supplierDocument, AntecipaSimulateAnticipationCommandViewModel command) {
        try {
            log.info("Initializing simulation for document: {}", supplierDocument);

            String bearerToken = "Bearer " + authenticationPort.getValidToken();

            AntecipaSimulationAnticipationCardReceivableDto result = antecipaClient.simulate(bearerToken, supplierDocument, command);

            log.info("Simulation successfully completed for document: {}", supplierDocument);
            return result;

        } catch (FeignException e) {
            log.error("Error when simulating anticipation: {}, Body: {}", e.status(), e.contentUTF8(), e);
            throw new FailedDependecyException(FAILED_DEPENDENCY_MESSAGE, e);
        }
    }

    @LogMethod(LogMethod.LogType.FULL)
    @Retry(name = Resilience4jConstant.ANTECIPA_CERC)
    public void execute(String supplierDocument, String capitalSourceDocument, String offerId) {
        try {
            log.info("Initializing of anticipation execution for document : {}, CapitalSource: {}, Offer: {}", supplierDocument, capitalSourceDocument, offerId);

            String bearerToken = "Bearer " + authenticationPort.getValidToken();

            antecipaClient.execute(bearerToken, supplierDocument, capitalSourceDocument, offerId);
            log.info("Anticipation executed successfully - Document: {}, Offer: {}", supplierDocument, offerId);

        } catch (FeignException e) {
            log.error("Error when simulating anticipation: {}, Body: {}", e.status(), e.contentUTF8(), e);
            throw new FailedDependecyException(FAILED_DEPENDENCY_MESSAGE, e);
        }

    }

    @LogMethod(LogMethod.LogType.FULL)
    @Retry(name = Resilience4jConstant.ANTECIPA_CERC)
    public AntecipaAnticipationCardReceivableListDtoPagedCollectionItems getAnticipations(String supplierDocument, String capitalSourceDocument, String anticipationDate,
                                                                                  String statusId, String pageId, Integer pageSize) {
        try {
            log.info("Looking for anticipations for document: {}", supplierDocument);
            log.debug("Filtros - CapitalSource: {}, Data: {}, Status: {}, Page: {}, Size: {}", capitalSourceDocument, anticipationDate, statusId, pageId, pageSize);

            String bearerToken = "Bearer " + authenticationPort.getValidToken();

            AntecipaAnticipationCardReceivableListDtoPagedCollectionItems result = antecipaClient.getAnticipations(
                     bearerToken, supplierDocument, capitalSourceDocument, anticipationDate, statusId, pageId, pageSize);

             log.info("Anticipations found for document: {}", supplierDocument);
             return result;

        } catch (FeignException e) {
            log.error("Error when searching for anticipations. Status: {}, Body: {}", e.status(), e.contentUTF8(), e);
            throw new FailedDependecyException(FAILED_DEPENDENCY_MESSAGE, e);
        }

    }

    @LogMethod(LogMethod.LogType.FULL)
    @Retry(name = Resilience4jConstant.ANTECIPA_CERC)
    public AntecipaAnticipationCardReceivableDto getAnticipationById(String supplierDocument, String id) {
        try {
            log.info("Looking  anticipations for ID {} for document: {}", id, supplierDocument);

            String bearerToken = "Bearer " + authenticationPort.getValidToken();

            AntecipaAnticipationCardReceivableDto result = antecipaClient.getAnticipationById(bearerToken, supplierDocument, id);
            log.info("Anticipation found - ID: {}, Document: {}", id, supplierDocument);
            return result;

        } catch (FeignException e) {
            log.error("Error when searching anticipations by ID. Status: {}, Body: {}", e.status(), e.contentUTF8(), e);
            throw new FailedDependecyException(FAILED_DEPENDENCY_MESSAGE, e);
        }

    }

    @LogMethod(LogMethod.LogType.FULL)
    @Retry(name = Resilience4jConstant.ANTECIPA_CERC)
    public AntecipaSupplierRegistrationDto getSupplier(String capitalSourceDocument, String supplierDocument) {
        try {
            log.info("Looking for supplier - CapitalSource: {}, Document: {}",capitalSourceDocument, supplierDocument);

            String bearerToken = "Bearer " + authenticationPort.getValidToken();

            AntecipaSupplierRegistrationDto result =  antecipaClient.getSupplierRegistration(bearerToken, capitalSourceDocument, supplierDocument);
            log.info("Supplier found Document: {}", supplierDocument);
            return result;

        } catch (FeignException e) {
            log.error("Error when searching for supplier. Status: {}, Body: {}", e.status(), e.contentUTF8(), e);
            throw new FailedDependecyException(FAILED_DEPENDENCY_MESSAGE, e);
        }

    }

    @LogMethod(LogMethod.LogType.FULL)
    @Retry(name = Resilience4jConstant.ANTECIPA_CERC)
    public AntecipaCardReceivableListDtoPagedCollectionItems getCardReceivables(
            String supplierDocument, String statusId, String accreditingInstitutionDocument, String capitalSourceDocument,
            String startDueDate, String endDueDate, String orderedBy, String pageId, Integer pageSize) {
        try {
            log.info("Searching for receivables from card to document : {}", supplierDocument);

            String bearerToken = "Bearer " + authenticationPort.getValidToken();
            log.debug("Filters - Status: {}, Accreditor: {}, CapitalSource: {}, Period {} a {}", statusId, accreditingInstitutionDocument,
                    capitalSourceDocument, startDueDate, endDueDate);
            AntecipaCardReceivableListDtoPagedCollectionItems result = antecipaClient.getCardReceivables(bearerToken, supplierDocument, statusId,
                    accreditingInstitutionDocument, capitalSourceDocument, startDueDate, endDueDate, orderedBy, pageId, pageSize);

            log.info("Receivables found for document: {}", supplierDocument);
            return result;

        } catch (FeignException e) {
            log.error("Error when searching for card receivables. Status: {}, Body: {}", e.status(), e.contentUTF8(), e);
            throw new FailedDependecyException(FAILED_DEPENDENCY_MESSAGE, e);
        }
    }

    @LogMethod(LogMethod.LogType.FULL)
    @Retry(name = Resilience4jConstant.ANTECIPA_CERC)
    public AntecipaCardReceivableDto getCardReceivableById (String supplierDocument, String id) {
        try {
            log.info("Searching receivable for ID {} para o document: {}", id, supplierDocument);

            String bearerToken = "Bearer " + authenticationPort.getValidToken();

            AntecipaCardReceivableDto result = antecipaClient.getCardReceivableById(bearerToken, supplierDocument, id);
            log.info("Receivable found - ID {}, Documento: {} ", id, supplierDocument);
            return result;

        }catch (FeignException e) {
            log.error("Erro when searching for receivable by ID. Status: {}, Body {}", e.status(), e.contentUTF8(), e);
            throw new FailedDependecyException(FAILED_DEPENDENCY_MESSAGE, e);
        }
    }
}
