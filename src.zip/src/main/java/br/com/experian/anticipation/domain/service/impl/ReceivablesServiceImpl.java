package br.com.experian.anticipation.domain.service.impl;

import br.com.experian.anticipation.domain.client.AccountClient;
import br.com.experian.anticipation.domain.client.RegistrationClient;
import br.com.experian.anticipation.domain.dto.ReceivableResponseDto;
import br.com.experian.anticipation.domain.dto.ReceivablesPageDto;
import br.com.experian.anticipation.domain.dto.response.BusinessRegistration;
import br.com.experian.anticipation.domain.dto.response.PartnerAndManagerRegistration;
import br.com.experian.anticipation.domain.dto.response.UserAccount;
import br.com.experian.anticipation.domain.exception.ConflictException;
import br.com.experian.anticipation.domain.model.Agreement;
import br.com.experian.anticipation.domain.port.ReceivablesPort;
import br.com.experian.anticipation.domain.repository.AgreementRepository;
import br.com.experian.anticipation.domain.service.ReceivablesService;
import br.com.experian.observability.annotation.LogMethod;
import lombok.extern.log4j.Log4j2;

import java.net.URI;
import java.util.List;
import java.util.Optional;

@Log4j2
public class ReceivablesServiceImpl implements ReceivablesService {

    private final ReceivablesPort receivablesPort;
    private final AgreementRepository agreementRepository;
    private final AccountClient accountClient;
    private final RegistrationClient registrationClient;

    public ReceivablesServiceImpl(ReceivablesPort receivablesPort,
                                  AccountClient accountClient,
                                  RegistrationClient registrationClient,
                                  AgreementRepository agreementRepository) {
        this.receivablesPort = receivablesPort;
        this.agreementRepository = agreementRepository;
        this.accountClient = accountClient;
        this.registrationClient = registrationClient;
    }

    @Override
    @LogMethod
    public Optional<ReceivableResponseDto> getReceivables(String supplierDocument, Integer limit, Integer offset) {
        log.info("Getting receivables for supplier document: {} with limit: {} and offset: {} ",
                supplierDocument, limit, offset);

        Agreement agreement = getUserAgreement();
        UserAccount userAccount = accountClient.getMyUserAccount();
        BusinessRegistration businessInfo = registrationClient.findBusinessInfo(agreement.getNationalRegistrationId());

        Optional<ReceivablesPageDto> receivablesPage = receivablesPort.getReceivables(supplierDocument, limit, offset);

        if (receivablesPage.isEmpty()) {
            log.info("No Receivables found for supplier document: {}", supplierDocument);
            return Optional.empty();
        }

        log.info("Successfully retrieved receivables for supplier document: {}", supplierDocument);

        return Optional.of(new ReceivableResponseDto(receivablesPage.get()));
    }

    @Override
    @LogMethod
    public Optional<ReceivableResponseDto> getReceivablesFromUserToken(Integer limit, Integer offset) {

        Agreement agreement = getUserAgreement();
        String supplierDocument = agreement.getNationalRegistrationId();

        Optional<ReceivablesPageDto> receivablesPage = receivablesPort.getReceivables(supplierDocument, limit, offset);

        return Optional.of(new ReceivableResponseDto(receivablesPage.get()));

    }

    private Agreement getUserAgreement() {
        return this.agreementRepository.getUserAgreement().orElseThrow(() -> new ConflictException("3"));
    }

}
