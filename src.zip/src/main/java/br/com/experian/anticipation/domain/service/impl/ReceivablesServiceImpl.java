package br.com.experian.anticipation.domain.service.impl;

import br.com.experian.anticipation.domain.client.AccountClient;
import br.com.experian.anticipation.domain.client.RegistrationClient;
import br.com.experian.anticipation.domain.dto.ReceivableResponseDto;
import br.com.experian.anticipation.domain.dto.ReceivablesPageDto;
import br.com.experian.anticipation.domain.exception.ConflictException;
import br.com.experian.anticipation.domain.model.Agreement;
import br.com.experian.anticipation.domain.port.ReceivablesPort;
import br.com.experian.anticipation.domain.repository.AgreementRepository;
import br.com.experian.anticipation.domain.service.ReceivablesService;
import br.com.experian.observability.annotation.LogMethod;
import lombok.extern.log4j.Log4j2;

import java.util.Optional;

@Log4j2
public class ReceivablesServiceImpl implements ReceivablesService {

    private final ReceivablesPort receivablesPort;
    private final AgreementRepository agreementRepository;
    private final AccountClient accountClient;
    private final RegistrationClient registrationClient;

    public ReceivablesServiceImpl(ReceivablesPort receivablesPort,
                                  AccountClient accountClient,
                                  RegistrationClient registrationClient,
                                  AgreementRepository agreementRepository) {
        this.receivablesPort = receivablesPort;
        this.agreementRepository = agreementRepository;
        this.accountClient = accountClient;
        this.registrationClient = registrationClient;
    }

    @Override
    @LogMethod
    public Optional<ReceivableResponseDto> getReceivables(Integer limit, Integer offset) {
        Agreement agreement = this.getUserAgreement();
        log.info("Getting receivables for document: {} with limit: {} and offset: {} ", agreement.getNationalRegistrationId(),  limit, offset);


        Optional<ReceivablesPageDto> receivablesPage = receivablesPort.getReceivables(agreement.getNationalRegistrationId(), limit, offset);

        if (receivablesPage.isEmpty()) {
            log.info("No Receivables found for supplier document: {}", agreement.getNationalRegistrationId());
            return Optional.empty();
        }

        log.info("Successfully retrieved receivables for supplier document: {}", agreement.getNationalRegistrationId());

        return Optional.of(new ReceivableResponseDto(receivablesPage.get()));
    }

    private Agreement getUserAgreement() {
        return this.agreementRepository.getUserAgreement().orElseThrow(() -> new ConflictException("3"));
    }

}
