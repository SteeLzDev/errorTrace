package br.com.experian.anticipation.application.rest;

import br.com.experian.anticipation.domain.service.SimulationService;
import br.com.experian.observability.annotation.LogMethod;
import br.com.experian.swagger.anticipation.api.SimulationApi;
import br.com.experian.swagger.anticipation.model.SimulationRequestTO;
import br.com.experian.swagger.anticipation.model.SimulationResponseTO;
import lombok.extern.log4j.Log4j2;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@Log4j2
@RestController
public class SimulationController extends BaseController implements SimulationApi {

    private final SimulationService simulationService;

    public SimulationController(SimulationService simulationService) {
        this.simulationService = simulationService;
    }

    @Override
    @PreAuthorize(HAS_RULES)
    @LogMethod(LogMethod.LogType.FULL)
    public ResponseEntity<SimulationResponseTO> simulate (SimulationRequestTO request) {
        log.info("Received simulation request with {} card receivable groups",
                request.getCardReceivables() != null ? request.getCardReceivables().size() : 0);

        Optional<SimulationResponseTO> response = simulationService.simulate(request);

        if (response.isEmpty()) {
            log.info("No offers available, return 204 no content");
            return ResponseEntity.noContent().build();
        }

        log.info("Simulation successful, returning 201 created");
        return ResponseEntity.status(HttpStatus.CREATED).body(response.get());
    }
}
