package br.com.experian.anticipation.infrastructure.config;

import br.com.experian.anticipation.domain.client.AccountClient;
import br.com.experian.anticipation.domain.client.OnboardingClient;
import br.com.experian.anticipation.domain.client.RegistrationClient;
import br.com.experian.anticipation.domain.port.AuthenticationPort;
import br.com.experian.anticipation.domain.port.ReceivablesPort;
import br.com.experian.anticipation.domain.repository.AgreementRepository;
import br.com.experian.anticipation.domain.service.HistoryService;
import br.com.experian.anticipation.domain.service.OnboardingService;
import br.com.experian.anticipation.domain.service.ReceivablesService;
import br.com.experian.anticipation.domain.service.impl.HistoryServiceImpl;
import br.com.experian.anticipation.domain.service.impl.OnboardingServiceImpl;
import br.com.experian.anticipation.domain.service.impl.ReceivablesServiceImpl;
import br.com.experian.anticipation.infrastructure.integration.feign.client.antecipa.AntecipaClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BeanConfiguration {

    @Bean
    public OnboardingService onboardingService(@Value("${api.onboarding.capital-source.document}") String capitalSourceDocument,
                                               @Value("${api.onboarding.capital-source.redirect}") String capitalSourceRedirect,
                                               OnboardingClient onboardingClient,
                                               AccountClient accountClient,
                                               RegistrationClient registrationClient,
                                               AgreementRepository agreementRepository) {
        return new OnboardingServiceImpl(capitalSourceDocument, capitalSourceRedirect, onboardingClient, accountClient, registrationClient, agreementRepository);
    }

    @Bean
    public ReceivablesService receivablesService(ReceivablesPort receivablesPort,
                                                 AccountClient accountClient,
                                                 RegistrationClient registrationClient,
                                                 AgreementRepository agreementRepository) {
        return new ReceivablesServiceImpl(receivablesPort, accountClient, registrationClient, agreementRepository);

    }

    @Bean
    public HistoryService historyService(AntecipaClient antecipaClient,
                                         AgreementRepository agreementRepository, AuthenticationPort authenticationPort) {
        return new HistoryServiceImpl(antecipaClient, agreementRepository, authenticationPort);
    }
}