package br.com.experian.anticipation.infrastructure.config;

import br.com.experian.anticipation.domain.client.AccountClient;
import br.com.experian.anticipation.domain.client.OnboardingClient;
import br.com.experian.anticipation.domain.client.RegistrationClient;
import br.com.experian.anticipation.domain.port.AuthenticationPort;
import br.com.experian.anticipation.domain.port.ReceivablesPort;
import br.com.experian.anticipation.domain.repository.AgreementRepository;
import br.com.experian.anticipation.domain.service.*;
import br.com.experian.anticipation.domain.service.impl.*;
import br.com.experian.anticipation.infrastructure.integration.feign.client.antecipa.AntecipaClient;
import br.com.experian.pme.security.user.UserSecurityService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BeanConfiguration {

    @Bean
    public OnboardingService onboardingService(@Value("${api.onboarding.capital-source.document}") String capitalSourceDocument,
                                               @Value("${api.onboarding.capital-source.redirect}") String capitalSourceRedirect,
                                               @Value("${api.onboarding.partner.logo-url}") String partnerLogoUrl,
                                               OnboardingClient onboardingClient,
                                               AccountClient accountClient,
                                               RegistrationClient registrationClient,
                                               AgreementRepository agreementRepository) {
        return new OnboardingServiceImpl(capitalSourceDocument, capitalSourceRedirect, partnerLogoUrl, onboardingClient, accountClient, registrationClient, agreementRepository);
    }

    @Bean
    public ReceivablesService receivablesService(ReceivablesPort receivablesPort,
                                                 AccountClient accountClient,
                                                 RegistrationClient registrationClient,
                                                 AgreementRepository agreementRepository) {
        return new ReceivablesServiceImpl(receivablesPort, accountClient, registrationClient, agreementRepository);

    }

    @Bean
    public HistoryService historyService(AntecipaClient antecipaClient,
                                         AgreementRepository agreementRepository, AuthenticationPort authenticationPort,
                                         @Qualifier("antecipaObjectMapper")ObjectMapper objectMapper, AccountClient accountClient, RegistrationClient registrationClient) {
        return new HistoryServiceImpl(antecipaClient, agreementRepository, authenticationPort, objectMapper, accountClient, registrationClient);
    }

    @Bean
    public MarketAvailabilityService marketAvailabilityService(@Value("${api.market.holidays}") String holidays,
                                                         @Value("${api.market.open-time}") String openTime,
                                                         @Value("${api.market.close-time}") String closeTime,
                                                         AgreementRepository agreementRepository,
                                                         AccountClient accountClient,
                                                         RegistrationClient registrationClient) {
        return new MarketAvailabilityServiceImpl(holidays, openTime, closeTime, agreementRepository, accountClient, registrationClient);
    }

    @Bean
    public SimulationService simulationService(@Value("${api.onboarding.capital-source.document}")String capitalSourceDocument, AntecipaClient antecipaClient,
                                               AgreementRepository agreementRepository,
                                               AuthenticationPort authenticationPort,
                                               AccountClient accountClient,
                                               RegistrationClient registrationClient,
                                               UserSecurityService userSecurityService) {
        return new SimulationServiceImpl(capitalSourceDocument, antecipaClient, agreementRepository, authenticationPort, accountClient, registrationClient, userSecurityService);
    }
}