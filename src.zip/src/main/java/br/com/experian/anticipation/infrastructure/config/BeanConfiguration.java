package br.com.experian.anticipation.infrastructure.config;

import br.com.experian.anticipation.domain.port.OnboardingPort;
import br.com.experian.anticipation.domain.port.AuthenticationPort;
import br.com.experian.anticipation.domain.service.OnboardingService;
import br.com.experian.anticipation.infrastructure.repository.adapter.OnboardingAdapter;
import br.com.experian.anticipation.infrastructure.integration.feign.client.antecipa.AntecipaClient;
import br.com.experian.anticipation.infrastructure.integration.feign.client.antecipa.OnboardingServiceImpl;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
public class BeanConfiguration {

    @Primary
    @Bean
    public OnboardingPort antecipaOnboardingPort(AntecipaClient antecipaClient,
                                                 AuthenticationPort authenticationPort,
                                                 @Value("${api.antecipa.default-capital-source}") String defaultCapitalSourceDocument){
        return new OnboardingAdapter(antecipaClient,authenticationPort, defaultCapitalSourceDocument);
    }

    @Bean
    public OnboardingService onboardingService(OnboardingPort onboardingPort) {
        return new OnboardingServiceImpl(onboardingPort);
    }
}