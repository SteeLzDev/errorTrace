package br.com.experian.anticipation.infrastructure.config;

import br.com.experian.anticipation.domain.client.AccountClient;
import br.com.experian.anticipation.domain.client.OfferClient;
import br.com.experian.anticipation.domain.client.OnboardingClient;
import br.com.experian.anticipation.domain.client.RegistrationClient;
import br.com.experian.anticipation.domain.port.ReceivablesPort;
import br.com.experian.anticipation.domain.repository.AnticipationHistoryRepository;
import br.com.experian.anticipation.domain.repository.OnboardingHistoryRepository;
import br.com.experian.anticipation.domain.service.*;
import br.com.experian.anticipation.domain.service.impl.*;
import br.com.experian.anticipation.infrastructure.integration.feign.client.antecipa.AntecipaClient;
import br.com.experian.pme.security.user.UserSecurityService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BeanConfiguration {

    @Bean
    public OnboardingService onboardingService(OnboardingClient onboardingClient,
                                               AccountClient accountClient,
                                               RegistrationClient registrationClient,
                                               AgreementService agreementService,
                                               OnboardingHistoryRepository onboardingHistoryRepository) {
        return new OnboardingServiceImpl(onboardingClient, accountClient, registrationClient, agreementService, onboardingHistoryRepository);
    }

    @Bean
    public ReceivablesService receivablesService(ReceivablesPort receivablesPort,
                                                 AgreementService agreementService) {
        return new ReceivablesServiceImpl(receivablesPort, agreementService);

    }

    @Bean
    public HistoryService historyService(AntecipaClient antecipaClient,
                                         AgreementService agreementService,
                                         @Qualifier("antecipaObjectMapper") ObjectMapper objectMapper) {
        return new HistoryServiceImpl(antecipaClient, agreementService, objectMapper);
    }

    @Bean
    public MarketAvailabilityService marketAvailabilityService(@Value("${api.market.holidays}") String holidays,
                                                               @Value("${api.market.open-time}") String openTime,
                                                               @Value("${api.market.close-time}") String closeTime) {
        return new MarketAvailabilityServiceImpl(holidays, openTime, closeTime);
    }

    @Bean
    public SimulationService simulationService(@Value("${api.onboarding.capital-source.document}")String capitalSourceDocument, AntecipaClient antecipaClient,
                                               AgreementService agreementService,
                                               UserSecurityService userSecurityService) {
        return new SimulationServiceImpl(capitalSourceDocument, antecipaClient, agreementService, userSecurityService);
    }

    @Bean
    public OfferService offerService(OfferClient offerClient,
                                     AgreementService agreementService,
                                     AnticipationHistoryRepository anticipationHistoryRepository) {
        return new OfferServiceImpl(offerClient, agreementService, anticipationHistoryRepository);
    }
}