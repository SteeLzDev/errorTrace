package br.com.experian.anticipation.domain.dto.response;

import br.com.experian.anticipation.domain.enums.OnboardingStatus;

public class OnboardingStatusResponseDto {

    private OnboardingStatus status;


    public OnboardingStatusResponseDto() {

    }

    public OnboardingStatusResponseDto(OnboardingStatus status) {
        this.status = status;
    }

    public OnboardingStatus getStatus() {
        return status;
    }

    public void setStatus(OnboardingStatus status) {
        this.status = status;
    }

    @Override
    public boolean equals (Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OnboardingStatusResponseDto that = (OnboardingStatusResponseDto) o;
        return status == that.status;
    }

    @Override
    public int hashCode() {
        return status != null ? status.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "OnboardingStatusResponseDto{" +
                "status=" + status +
                '}';
    }
}
