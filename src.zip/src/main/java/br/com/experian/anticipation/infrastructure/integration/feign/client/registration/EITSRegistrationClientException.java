package br.com.experian.anticipation.infrastructure.integration.feign.client.registration;

import br.com.experian.anticipation.domain.exception.AbstractException;
import org.springframework.http.HttpStatus;

class EITSRegistrationClientException extends AbstractException {

    public EITSRegistrationClientException(String code, String message) {
        super(code, message, HttpStatus.FAILED_DEPENDENCY);
    }
}