package br.com.experian.anticipation.domain.model;


import br.com.experian.anticipation.domain.constant.HistoryStatus;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class HistoryItem {

    private String id;
    private LocalDate requestDate;
    private Integer receivablesCount;
    private HistoryStatus status;
    private BigDecimal requesteAmount;




}
