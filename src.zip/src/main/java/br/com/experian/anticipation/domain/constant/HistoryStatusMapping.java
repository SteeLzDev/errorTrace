package br.com.experian.anticipation.domain.constant;

import lombok.Getter;

import java.util.Arrays;

public enum HistoryStatusMapping {

    CREATED(1, "Created", HistoryStatus.PENDING),
    BOOKED(2, "Booked", HistoryStatus.PENDING),
    PROCESSING(3, "Processing", HistoryStatus.PENDING),
    ANTICIPATED(4, "Anticipated", HistoryStatus.CONCLUDED),
    PARTIALLY_ANTICIPATED(5, "PartiallyAnticipated", HistoryStatus.PARTIALLY_APPROVED),
    ANTICIPATION_FAILED(6, "AnticipationFailed", HistoryStatus.ERROR),
    PENDING_DOCUMENT(7, "PendingDocument", HistoryStatus.REJECTED);


    @Getter
    private final Integer externalStatusId;
    private final String externalStatusName;
    private final HistoryStatus projectStatus;

    HistoryStatusMapping(Integer externalStatusId, String externalStatusName, HistoryStatus projectStatus) {
        this.externalStatusId = externalStatusId;
        this.externalStatusName = externalStatusName;
        this.projectStatus = projectStatus;
    }

    public static HistoryStatus mapFromExternalStatus(String externalStatusName) {
        return Arrays.stream(values())
                .filter(mapping -> mapping.externalStatusName.equals(externalStatusName))
                .map(mapping -> mapping.projectStatus)
                .findFirst()
                .orElse(HistoryStatus.ERROR); //Default para status não mapeados
    }

    public static  HistoryStatus mapFromExternalStatusId(Integer externalStatusId) {
        return Arrays.stream(values())
                .filter(mapping -> mapping.externalStatusId.equals(externalStatusId))
                .map(mapping -> mapping.projectStatus)
                .findFirst()
                .orElse(HistoryStatus.ERROR); //Default para status não mapeados
    }

    public static String mapExternalIdToResponseStatus(Integer externalStatusId) {
        HistoryStatus status = mapFromExternalStatusId(externalStatusId);
        return switch (status) {
            case CONCLUDED -> "CONCLUDED";
            case PENDING -> "PENDING";
            case PARTIALLY_APPROVED -> "PARTIALLY_APPROVED";
            case ERROR -> "ERROR";
            case REJECTED -> "REJECTED";
            case ANTICIPABLE -> "ANTICIPABLE";

        };

    }
}

