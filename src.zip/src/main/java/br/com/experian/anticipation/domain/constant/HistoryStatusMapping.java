package br.com.experian.anticipation.domain.constant;

import lombok.Getter;

import java.util.Arrays;

public enum HistoryStatusMapping {

    CREATED(1, "Created", HistoryStatus.PENDING),
    PROCESSING(3, "Processing", HistoryStatus.PENDING),
    ANTICIPATED(4, "Anticipated", HistoryStatus.CONCLUDED),
    PARTIALLY_ANTICIPATED(5, "PartiallyAnticipated", HistoryStatus.PARTIALLY_APPROVED),
    ANTICIPATION_FAILED(6, "AnticipationFailed", HistoryStatus.ERROR);


    @Getter
    private final Integer externalStatusId;
    private final String externalStatusName;
    private final HistoryStatus projectStatus;

    HistoryStatusMapping(Integer externalStatusId, String externalStatusName, HistoryStatus projectStatus) {
        this.externalStatusId = externalStatusId;
        this.externalStatusName = externalStatusName;
        this.projectStatus = projectStatus;
    }

    public static HistoryStatus mapFromExternalStatus(String externalStatusName) {
        return Arrays.stream(values())
                .filter(mapping -> mapping.externalStatusName.equals(externalStatusName))
                .map(mapping -> mapping.projectStatus)
                .findFirst()
                .orElse(HistoryStatus.ERROR); //Default para status não mapeados
    }

    public static  HistoryStatus mapFromExternalStatusId(Integer externalStatusId) {
        return Arrays.stream(values())
                .filter(mapping -> mapping.externalStatusId.equals(externalStatusId))
                .map(mapping -> mapping.projectStatus)
                .findFirst()
                .orElse(HistoryStatus.ERROR); //Default para status não mapeados
    }
}

