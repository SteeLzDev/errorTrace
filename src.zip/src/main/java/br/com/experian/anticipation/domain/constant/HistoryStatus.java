package br.com.experian.anticipation.domain.constant;

import lombok.Getter;

public enum HistoryStatus {

    CONCLUDED("PAGO"),
    PENDING("Pendente"),
    PARTIALLY_APPROVED("Pago Parcialmente"),
    ERROR("Erro de antecipação"),
    REJECTED("Não aprovado"),
    ANTICIPABLE("Antecipável");
    //PENDING_DOCUMENT("Documento Pendente");


    @Getter
    private final String description;

    HistoryStatus(String description) {
        this.description = description;
    }

}
