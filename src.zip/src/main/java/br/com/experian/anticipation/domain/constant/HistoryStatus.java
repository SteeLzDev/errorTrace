package br.com.experian.anticipation.domain.constant;

import lombok.Getter;

public enum HistoryStatus {

    CONCLUDED("PAGO"),
    PENDING("Pendente"),
    PARTIALLY_APPROVED("Pago Parcialmente"),
    ERROR("Erro de antecipação"),
    REJECTED("Não aprovado"),
    ANTICIPABLE("Antecipável");


    @Getter
    private final String description;

    HistoryStatus(String description) {
        this.description = description;
    }

}
