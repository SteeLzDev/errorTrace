package br.com.experian.anticipation.domain.exception;


import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public class FailedDependencyException extends AbstractException {

    public FailedDependencyException(String code, String message) {
        super(code, message, HttpStatus.FAILED_DEPENDENCY);
    }

    public FailedDependencyException(String code, String message, Throwable throwable) {
        super(code, message, throwable, HttpStatus.FAILED_DEPENDENCY);
    }
}