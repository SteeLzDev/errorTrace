package br.com.experian.anticipation.infrastructure.integration.feign.client.antecipa;

import br.com.experian.swagger.antecipa.model.*;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "AntecipaClient", url ="${api.antecipa.base.uri}")
public interface AntecipaClient {

    @GetMapping("/Originators/CapitalSources/{CapitalSourceDocument}/Suppliers/{SupplierDocument}")
    AntecipaSupplierRegistrationDto getSupplierRegistration(
            @RequestHeader("Authorization") String bearerToken,
            @PathVariable("CapitalSourceDocument") String capitalSourceDocument,
            @PathVariable("SupplierDocument") String supplierDocument);

    @PostMapping("/Originators/CapitalSources/{CapitalSourceDocument}/Suppliers")
    AntecipaBasicResultDto addSupplier(
            @RequestHeader("Authorization") String bearerToken,
            @PathVariable("CapitalSourceDocument") String capitalSourceDocument,
            @RequestBody AntecipaAddCapitalSourceSupplierRegistrationCommandViewModel supplierAddCommand);

    @GetMapping("/Originators/CardReceivables/suppliers/{SupplierDocument}")
    AntecipaCardReceivableListDtoPagedCollectionItems getCardReceivables(
            @RequestHeader("Authorization") String bearerToken,
            @PathVariable("SupplierDocument") String supplierDocument,
            @RequestParam(value = "StatusId", required = false) String statusId,
            @RequestParam(value = "AccreditingInstitutionDocument", required = false) String accreditingInstitutionDocument,
            @RequestParam(value = "CapitalSourceDocument", required = false) String capitalSourceDocument,
            @RequestParam(value = "StartDueDate", required = false) String startDueDate,
            @RequestParam(value = "EndDueDate", required = false) String endDueDate,
            @RequestParam(value = "OrderedBy", required = false) String orderedBy,
            @RequestParam(value = "PageId", required = false) String pageId,
            @RequestParam(value = "PageSize", required = false) Integer pageSize);

    @GetMapping("/Originators/CardReceivables/{SupplierDocument}/{Id}")
    AntecipaCardReceivableDto getCardReceivableById(
            @RequestHeader("Authorization") String bearerToken,
            @PathVariable("SupplierDocument") String supplierDocument,
            @PathVariable("Id") String id);


    @GetMapping("/Originators/CardReceivables/Suppliers/{SupplierDocument}/Anticipations")
    AntecipaAnticipationCardReceivableListDtoPagedCollectionItems getAnticipations(
            @RequestHeader("Authorization") String bearerToken,
            @PathVariable("SupplierDocument") String supplierDocument,
            @RequestParam(value = "CapitalSourceDocument", required = false) String capitalSourceDocument,
            @RequestParam(value = "StartAnticipationDate", required = false) String startAnticipationDate,
            @RequestParam(value = "EndAnticipationDate", required = false) String endAnticipationDate,
            @RequestParam(value = "StatusId", required = false) String statusId,
            @RequestParam(value = "PageId", required = false) String pageId,
            @RequestParam(value = "PageSize", required = false)Integer pageSize);

    @GetMapping("/Originators/CardReceivables/Suppliers/{SupplierDocument}/Anticipations/{Id}")
    AntecipaAnticipationCardReceivableDto getAnticipationById(
            @RequestHeader("Authorization") String bearerToken,
            @PathVariable("SupplierDocument") String supplierDocument,
            @PathVariable("Id") String id);

    @PostMapping("/Originators/CardReceivables/Anticipations/Simulate/{SupplierDocument}")
    AntecipaSimulationAnticipationCardReceivableDto simulate(
            @RequestHeader("Authorization") String bearerToken,
            @PathVariable("SupplierDocument") String supplierDocument,
            @RequestBody AntecipaSimulateAnticipationCardReceivableCommandViewModel simulateAnticipationCommand);


    @PostMapping("/Originators/CardReceivables/Anticipations/Execute/{SupplierDocument}/{CapitalSourceDocument}/{OfferId}")
    void execute(
            @RequestHeader("Authorization") String bearerToken,
            @PathVariable("SupplierDocument") String supplierDocument,
            @PathVariable("CapitalSourceDocument") String capitalSourceDocument,
            @PathVariable("OfferId") String offerId);
}