package br.com.experian.anticipation.infrastructure.integration.feign.client.antecipa;

import br.com.experian.anticipation.infrastructure.integration.feign.client.antecipa.auth.AntecipaAuthFeignConfig;
import br.com.experian.swagger.antecipa.model.*;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "AntecipaClient", url ="${api.antecipa.base.uri}", configuration = AntecipaAuthFeignConfig.class)
public interface AntecipaClient {

    @GetMapping("/Originators/CapitalSources/{CapitalSourceDocument}/Suppliers/{SupplierDocument}")
    AntecipaSupplierRegistrationDto getSupplierRegistration(
            @PathVariable("CapitalSourceDocument") String capitalSourceDocument,
            @PathVariable("SupplierDocument") String supplierDocument);

    @PostMapping("/Originators/CapitalSources/{CapitalSourceDocument}/Suppliers")
    AntecipaBasicResultDto addSupplier(
            @PathVariable("CapitalSourceDocument") String capitalSourceDocument,
            @RequestBody AntecipaAddCapitalSourceSupplierRegistrationCommandViewModel supplierAddCommand);

    @GetMapping("/Originators/CardReceivables/suppliers/{SupplierDocument}")
    AntecipaCardReceivableListDtoPagedCollectionItems getCardReceivables(
            @PathVariable("SupplierDocument") String supplierDocument,
            @RequestParam(value = "StatusId", required = false) String statusId,
            @RequestParam(value = "AccreditingInstitutionDocument", required = false) String accreditingInstitutionDocument,
            @RequestParam(value = "CapitalSourceDocument", required = false) String capitalSourceDocument,
            @RequestParam(value = "StartDueDate", required = false) String startDueDate,
            @RequestParam(value = "EndDueDate", required = false) String endDueDate,
            @RequestParam(value = "OrderedBy", required = false) String orderedBy,
            @RequestParam(value = "PageId", required = false) String pageId,
            @RequestParam(value = "PageSize", required = false) Integer pageSize);

    @GetMapping("/Originators/CardReceivables/Suppliers/{SupplierDocument}/Anticipations")
    AntecipaAnticipationCardReceivableListDtoPagedCollectionItems getAnticipations(
            @PathVariable("SupplierDocument") String supplierDocument,
            @RequestParam(value = "CapitalSourceDocument", required = false) String capitalSourceDocument,
            @RequestParam(value = "StartAnticipationDate", required = false) String startAnticipationDate,
            @RequestParam(value = "EndAnticipationDate", required = false) String endAnticipationDate,
            @RequestParam(value = "StatusId", required = false) String statusId,
            @RequestParam(value = "PageId", required = false) String pageId,
            @RequestParam(value = "PageSize", required = false)Integer pageSize);

    @GetMapping("/Originators/CardReceivables/Suppliers/{SupplierDocument}/Anticipations/{Id}")
    AntecipaAnticipationCardReceivableDto getAnticipationById(
            @PathVariable("SupplierDocument") String supplierDocument,
            @PathVariable("Id") String id);

    @PostMapping("/Originators/CardReceivables/Suppliers/{SupplierDocument}/Anticipations/Simulate")
    List<AntecipaSimulationAnticipationCardReceivableDto> simulate(
            @PathVariable("SupplierDocument") String supplierDocument,
            @RequestBody AntecipaSimulateAnticipationCardReceivableCommandViewModel simulateAnticipationCommand);


    @PostMapping("/Originators/CardReceivables/Suppliers/{SupplierDocument}/Anticipations/Execute/{OfferId}")
    AntecipaBasicResultDto execute(
            @PathVariable("SupplierDocument") String supplierDocument,
            @PathVariable("OfferId") String offerId,
            @RequestBody AntecipaExecuteAnticipationCardReceivableCommandViewModel simulateAnticipationCommand);
}