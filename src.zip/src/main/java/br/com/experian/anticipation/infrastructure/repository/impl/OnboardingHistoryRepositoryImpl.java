package br.com.experian.anticipation.infrastructure.repository.impl;

import br.com.experian.anticipation.domain.model.OnboardingHistory;
import br.com.experian.anticipation.domain.repository.OnboardingHistoryRepository;
import br.com.experian.anticipation.infrastructure.repository.DocumentDbOnboardingHistoryRepository;
import br.com.experian.anticipation.infrastructure.repository.adapter.OnboardingHistoryAdapter;
import org.springframework.stereotype.Component;

@Component
public class OnboardingHistoryRepositoryImpl implements OnboardingHistoryRepository {

    private final DocumentDbOnboardingHistoryRepository onboardingHistoryRepository;

    public OnboardingHistoryRepositoryImpl(DocumentDbOnboardingHistoryRepository onboardingHistoryRepository) {
        this.onboardingHistoryRepository = onboardingHistoryRepository;
    }

    @Override
    public void save(OnboardingHistory onboardingHistory) {
        this.onboardingHistoryRepository.save(OnboardingHistoryAdapter.build(onboardingHistory));
    }
}