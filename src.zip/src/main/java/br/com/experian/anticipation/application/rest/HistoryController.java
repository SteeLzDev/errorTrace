package br.com.experian.anticipation.application.rest;

import br.com.experian.anticipation.domain.dto.response.UserAccount;
import br.com.experian.anticipation.domain.service.HistoryService;
import br.com.experian.anticipation.domain.service.impl.HistoryServiceImpl;
import br.com.experian.anticipation.domain.service.impl.ReceivablesServiceImpl;
import br.com.experian.observability.annotation.LogMethod;
import br.com.experian.swagger.anticipation.api.HistoryApi;
import br.com.experian.swagger.anticipation.model.HistoryResponseTO;
import lombok.extern.log4j.Log4j2;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.Optional;

@Log4j2
@RestController
public class HistoryController extends BaseController implements HistoryApi {

    private final HistoryService historyService;

    public HistoryController(HistoryService historyService) {
        this.historyService = historyService;
    }

    @Override
    @PreAuthorize(HAS_RULES)
    @LogMethod(LogMethod.LogType.FULL)
    public ResponseEntity<HistoryResponseTO> findHistory(LocalDate anticipationDate,
                                                         String statusId,
                                                         Integer limit,
                                                         Integer offset) {
        final int pageLimit = limit != null ? limit : 10;
        final int pageOffset = offset != null ? offset : 0;

        String anticipationDateStr = anticipationDate != null ? anticipationDate.toString() : null;

        Optional<HistoryResponseTO> historyOpt = this.historyService.findHistoryWithReceivables(null,
                anticipationDateStr, null, statusId, pageOffset, pageLimit);

        if (historyOpt.isEmpty()) {
            log.info("No anticipation history found for the given filters");
            return ResponseEntity.noContent().build();
        }

        return ResponseEntity.ok(historyOpt.get());

    }
}
