package br.com.experian.anticipation.application.rest;

import br.com.experian.anticipation.domain.dto.response.UserAccount;
import br.com.experian.anticipation.domain.service.HistoryService;
import br.com.experian.anticipation.domain.service.impl.HistoryServiceImpl;
import br.com.experian.anticipation.domain.service.impl.ReceivablesServiceImpl;
import br.com.experian.observability.annotation.LogMethod;
import br.com.experian.swagger.anticipation.api.HistoryApi;
import br.com.experian.swagger.anticipation.model.HistoryResponseTO;
import lombok.extern.log4j.Log4j2;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.Optional;

@Log4j2
@RestController
public class HistoryController extends BaseController implements HistoryApi {

    private final HistoryService historyService;

    public HistoryController(HistoryService historyService) {
        this.historyService = historyService;
    }

    @Override
    @PreAuthorize(HAS_RULES)
    @LogMethod(LogMethod.LogType.FULL)
    public ResponseEntity<HistoryResponseTO> findHistory(String capitalSourceDocument,
                                                         LocalDate anticipationDate,
                                                         String statusId,
                                                         String pageId,
                                                         Integer pageSize) {
        String anticipationDateStr = anticipationDate != null ? anticipationDate.toString() : null;

        Optional<HistoryResponseTO> historyOpt = this.historyService.findHistoryWithReceivables(capitalSourceDocument,
                anticipationDateStr, null, statusId, pageId, pageSize);

        if (historyOpt.isEmpty()) {
            log.info("No anticipation history found for the given filters");
            return ResponseEntity.noContent().build();
        }

        return ResponseEntity.ok(historyOpt.get());

    }
}
