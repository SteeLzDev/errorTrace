package br.com.experian.anticipation.domain.model;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class HistoryDetailItem {

    private LocalDate receiveDate;
    private String cnpj;
    private String acquirer;
    private Integer installmentNumber;
    private BigDecimal originalValue;
    private BigDecimal discountAmount;
    private BigDecimal netValue;


}
