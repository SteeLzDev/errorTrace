package br.com.experian.anticipation.domain.service;

import br.com.experian.anticipation.domain.dto.ReceivableResponseDto;

import java.net.URI;
import java.util.Optional;

public interface ReceivablesService {


    Optional<ReceivableResponseDto> getReceivables(String supplierDocument, Integer limit, Integer offset);
}
