package br.com.experian.anticipation.domain.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

import java.time.LocalDateTime;

@Getter
@Builder
@AllArgsConstructor
public class Agreement {
    private String id;
    private String userId;
    private String businessId;
    private String nationalRegistrationId;
    private Status status;
    private int version;
    private String url;
    private LocalDateTime acceptedAt;
    private LocalDateTime revokedAt;
    private LocalDateTime updatedAt;

    public enum Status {
        ACCEPTED, NOT_ACCEPTED, UPDATE, REVOKED
    }
}