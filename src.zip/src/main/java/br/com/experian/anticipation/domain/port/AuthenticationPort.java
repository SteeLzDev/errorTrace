package br.com.experian.anticipation.domain.port;

public interface AuthenticationPort {

    String getValidToken();

    String refreshToken();

    boolean isTokenValid();
}