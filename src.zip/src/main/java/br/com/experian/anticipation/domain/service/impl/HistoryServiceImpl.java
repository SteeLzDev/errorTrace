package br.com.experian.anticipation.domain.service.impl;

import br.com.experian.anticipation.domain.constant.HistoryStatusMapping;
import br.com.experian.anticipation.domain.exception.ConflictException;
import br.com.experian.anticipation.domain.model.Agreement;
import br.com.experian.anticipation.domain.port.AuthenticationPort;
import br.com.experian.anticipation.domain.repository.AgreementRepository;
import br.com.experian.anticipation.domain.service.HistoryService;
import br.com.experian.anticipation.infrastructure.integration.feign.client.antecipa.AntecipaClient;
import br.com.experian.observability.annotation.LogMethod;
import br.com.experian.swagger.antecipa.model.AntecipaAnticipationCardReceivabletDto;
import br.com.experian.swagger.antecipa.model.*;
import br.com.experian.swagger.anticipation.model.*;
import lombok.extern.log4j.Log4j2;
import org.openapitools.jackson.nullable.JsonNullable;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Log4j2
public class HistoryServiceImpl implements HistoryService {


    private final AntecipaClient antecipaClient;
    private final AgreementRepository agreementRepository;
    private final AuthenticationPort authenticationPort;

    public HistoryServiceImpl(AntecipaClient antecipaClient,
                              AgreementRepository agreementRepository, AuthenticationPort authenticationPort) {
        this.antecipaClient = antecipaClient;
        this.agreementRepository = agreementRepository;
        this.authenticationPort = authenticationPort;
    }


//    @Override
//    @LogMethod
//    public Optional<HistoryResponseTO> findHistoryPaginated(String capitalSourceDocument,
//                                                            String startAnticipationDate,
//                                                            String endAnticipationDate,
//                                                            String statusId,
//                                                            String pageId,
//                                                            Integer pageSize) {
//        //Agreement agreement = this.getUserAgreement();
//        //String supplierDocument = agreement.getNationalRegistrationId();
//        //TODO Temporário - Usar documento fixo para testes, depois voltar com o getUserAgreement
//        String supplierDocument = "45181802000183";
//
//        log.info("Fetching paginated anticipation history for supplier: {}", supplierDocument);
//
//        try {
//            String token = "Bearer " + authenticationPort.getValidToken();
//
//            AntecipaAnticipationCardReceivableListDtoPagedCollectionItems page =
//                    antecipaClient.getAnticipations(token,
//                            supplierDocument,
//                            capitalSourceDocument,
//                            startAnticipationDate,
//                            endAnticipationDate,
//                            statusId,
//                            pageId,
//                            pageSize);
//
//            List<AntecipaAnticipationCardReceivableListDto> externalItems = extractItems(page);
//            if (externalItems == null || externalItems.isEmpty()) {
//                log.info("No anticipation history found for supplier: {}", supplierDocument);
//                return Optional.empty();
//            }
//
//            List<HistoryItemTO> historyItems = new ArrayList<>();
//
//            for (AntecipaAnticipationCardReceivableListDto ext : externalItems) {
//                HistoryItemTO item = new HistoryItemTO();
//
//                //id
//                String id = ext.getId() != null ? String.valueOf(ext.getId()) : null;
//                item.setId(id);
//
//
//                //requestDate (YYY-MM-DD) a partir de createdAt
//                if (ext.getCreatedAt() != null) {
//                    LocalDateTime ldt = parseToLocalDate(ext.getCreatedAt().toString());
//                    if (ldt != null) {
//                        item.setRequestDate(ldt.toLocalDate());
//                    }
//
//                }
//                //Status mapping usando mapeamento
//                if (ext.getStatusId() != null) {
//                    String mappedStatus = HistoryStatusMapping.mapExternalIdToResponseStatus(ext.getStatusId());
//                    item.setStatus(HistoryItemTO.StatusEnum.valueOf(mappedStatus));
//                }
//
//                //ReceivablesCount -> somatório (anticipated + noAnticipated) do detalhe
//                if (id != null) {
//                    try {
//                        AntecipaAnticipationCardReceivableDto detail =
//                                antecipaClient.getAnticipationById(token, supplierDocument, id);
//                        int count = countReceivables(detail);
//                        item.setReceivablesCount(count);
//                    } catch (Exception e) {
//                        log.warn("Failed to fetch receivables count for ID: {}", id, e);
//                        item.setReceivablesCount(0);
//                    }
//                } else {
//                    item.setReceivablesCount(0);
//                }
//                historyItems.add(item);
//            }
//            HistoryResponseTO response = new HistoryResponseTO();
//            response.setItems(historyItems);
//            response.setNextPage(extractNextPageId(page));
//            response.setPageSize(pageSize != null ? pageSize : 10);
//            log.info("Successfully retrieved {} anticipation records for supplier: {}", historyItems.size(), supplierDocument);
//            return Optional.of(response);
//
//        } catch (Exception e) {
//            log.error("Error fetching anticipation history for supplier: {}", supplierDocument, e);
//            return Optional.empty();
//        }
//    }

    @Override
    @LogMethod
    public Optional<HistoryResponseTO> findHistoryWithReceivables(String supplierDocument,
                                                                  String capitalSourceDocument,
                                                                  String startAnticipationDate,
                                                                  String endAnticipationDate,
                                                                  String statusId,
                                                                  String pageId,
                                                                  Integer pageSize) {
        supplierDocument = "45181802000183";
        log.info("Fetching anticipation history with receivables for supplier: {}", supplierDocument);


        try {
            String token = "Bearer " + authenticationPort.getValidToken();

            AntecipaAnticipationCardReceivableListDtoPagedCollectionItems pagedResponse =
                    antecipaClient.getAnticipations(token,
                            supplierDocument,
                            capitalSourceDocument,
                            startAnticipationDate,
                            endAnticipationDate,
                            statusId,
                            pageId,
                            pageSize);
            List<AntecipaAnticipationCardReceivableListDto> externalItems = extractItems(pagedResponse);

            if (externalItems == null || externalItems.isEmpty()) {
                log.info("No anticipation history for supplier: {}", supplierDocument);
                return Optional.empty();
            }
            List<HistoryItemTO> historyItems = new ArrayList<>();

            for (AntecipaAnticipationCardReceivableListDto ext : externalItems) {
                HistoryItemTO item = new HistoryItemTO();

                //ID
                String id = ext.getId() != null ? String.valueOf(ext.getId()) : null;
                item.setId(id);

                //requestDate (YYYY-MM-DD) a partir de createdAt
                if (ext.getCreatedAt() != null) {
                    LocalDateTime ldt = parseToLocalDate(ext.getCreatedAt().toString());
                    if (ldt != null) {
                        item.setRequestDate(ldt.toLocalDate());
                    }
                }

                //Status mapping usando mapeamento
                if (ext.getStatusId() != null) {
                    String mappedStatus = HistoryStatusMapping.mapExternalIdToResponseStatus(ext.getStatusId());
                    item.setStatus(HistoryItemTO.StatusEnum.valueOf(mappedStatus));
                }

//                //requestedAmount = selectedAmount do parceiro
//                if (ext.getSelectedAmount() != null) {
//                    item.setRequestedAmount(BigDecimal.valueOf(ext.getSelectedAmount()));
//                }
                //Buscar detalhe de antecipação para obter receivables
                if (id != null) {
                    try {
                        AntecipaAnticipationCardReceivableDto detail =
                                antecipaClient.getAnticipationById(token, supplierDocument, id);

                        //Processar receivables do detalhe
                        List<ReceivableItemTO> receivables = processReceivables(detail, ext);
                        item.setReceivables(receivables);

                        //Calcular totais
                        BigDecimal totalNetValue = receivables.stream()
                                .map(ReceivableItemTO::getNetValue)
                                .filter(Objects::nonNull)
                                .reduce(BigDecimal.ZERO, BigDecimal::add);

                        item.setTotalNetValue(totalNetValue);
                        item.setReceivablesCount(receivables.size());

                    } catch (Exception e) {
                        log.warn("Failed to fetch receivables details for ID: {}", id, e);
                        item.setReceivables(new ArrayList<>());
                        item.setTotalNetValue(BigDecimal.ZERO);
                        item.setReceivablesCount(0);
                    }
                } else {
                    item.setReceivables(new ArrayList<>());
                    item.setTotalNetValue(BigDecimal.ZERO);
                    item.setReceivablesCount(0);
                }
                historyItems.add(item);
            }
            HistoryResponseTO response = new HistoryResponseTO();
            response.setItems(historyItems);
            response.setNextPage(null);
            response.setPageSize(pageSize != null ? pageSize : 10);

            log.info("Successfully retrieved {} anticipation records with receivables for supplier: {}", historyItems.size(), supplierDocument);
            return Optional.of(response);

        } catch (Exception e) {
            log.error("Error fetching anticipation history with receivables for supplier: {}", supplierDocument, e);
            return Optional.empty();
        }
    }

    private List<AntecipaAnticipationCardReceivableListDto> extractItems(
            AntecipaAnticipationCardReceivableListDtoPagedCollectionItems pagedResponse) {
        if (pagedResponse == null || pagedResponse.getItems() == null) {
            return new ArrayList<>();
        }
        return pagedResponse.getItems().get();
    }


    private List<ReceivableItemTO> processReceivables(AntecipaAnticipationCardReceivableDto detail,
                                                    AntecipaAnticipationCardReceivableListDto listItem) {
        List<ReceivableItemTO> receivables = new ArrayList<>();

        if (detail == null) return receivables;

        // Processar anticipated items
        if (detail.getAnticipatedItems() != null && detail.getAnticipatedItems().isPresent()) {
            Object anticipatedItemsObj = detail.getAnticipatedItems().get();
            if (anticipatedItemsObj instanceof List<?>) {
                List<?> anticipatedItems = (List<?>) anticipatedItemsObj;

                for (Object itemObj : anticipatedItems) {
                    if (itemObj instanceof br.com.experian.swagger.antecipa.model.AntecipaAnticipationCardReceivabletDto) {
                        br.com.experian.swagger.antecipa.model.AntecipaAnticipationCardReceivabletDto sourceItem =
                                (br.com.experian.swagger.antecipa.model.AntecipaAnticipationCardReceivabletDto) itemObj;
                        ReceivableItemTO item = convertToReceivableItem(sourceItem, detail, listItem);
                        if (item != null) {
                            receivables.add(item);
                        }
                    } else {
                        log.warn("Unexpected item type in anticipatedItems: {}", itemObj.getClass().getName());
                    }
                }
            }
        }

        // Processar not anticipated items
        if (detail.getNotAnticipatedItems() != null && detail.getNotAnticipatedItems().isPresent()) {
            Object notAnticipatedItemsObj = detail.getNotAnticipatedItems().get();
            if (notAnticipatedItemsObj instanceof List<?>) {
                List<?> notAnticipatedItems = (List<?>) notAnticipatedItemsObj;

                for (Object itemObj : notAnticipatedItems) {
                    if (itemObj instanceof br.com.experian.swagger.antecipa.model.AntecipaAnticipationCardReceivabletDto) {
                        br.com.experian.swagger.antecipa.model.AntecipaAnticipationCardReceivabletDto sourceItem =
                                (br.com.experian.swagger.antecipa.model.AntecipaAnticipationCardReceivabletDto) itemObj;
                        ReceivableItemTO item = convertToReceivableItem(sourceItem, detail, listItem);
                        if (item != null) {
                            receivables.add(item);
                        }
                    } else {
                        log.warn("Unexpected item type in notAnticipatedItems: {}", itemObj.getClass().getName());
                    }
                }
            }
        }

        return receivables;
    }




//    private List<ReceivableItemTO> processReceivables(AntecipaAnticipationCardReceivableDto detail,
//                                                      AntecipaAnticipationCardReceivableListDto listItem) {
//        List<ReceivableItemTO> receivables = new ArrayList<>();
//
//        if (detail == null) return receivables;
//
//        //Processar anticipated items
//        if (detail.getAnticipatedItems() != null && detail.getAnticipatedItems().isPresent()) {
//            List<AntecipaAnticipationCardReceivabletDto> anticipatedItems =
//                    (List<AntecipaAnticipationCardReceivabletDto>) detail.getAnticipatedItems().get();
//
//            for (AntecipaAnticipationCardReceivabletDto sourceItem : anticipatedItems) {
//                ReceivableItemTO item = convertToReceivableItem(sourceItem, detail, listItem);
//                if (item != null) {
//                    receivables.add(item);
//                }
//
//            }
//        }
//
//        //Processar noAnticipated items
//        if (detail.getNotAnticipatedItems() != null && detail.getNotAnticipatedItems().isPresent()) {
//            List<AntecipaAnticipationCardReceivabletDto> noAnticipatedItems =
//                    (List<AntecipaAnticipationCardReceivabletDto>) detail.getNotAnticipatedItems().get();
//
//            for (AntecipaAnticipationCardReceivabletDto sourceItem : noAnticipatedItems) {
//                ReceivableItemTO item = convertToReceivableItem(sourceItem, detail, listItem);
//                if (item != null) {
//                    receivables.add(item);
//                }
//            }
//        }
//        return receivables;
//    }

    private static <T> List<T> listOrEmpty(JsonNullable<List<T>> maybe) {
        return (maybe != null && maybe.isPresent() && maybe.get() != null) ? maybe.get() : List.of();
    }

    private ReceivableItemTO convertToReceivableItem(AntecipaAnticipationCardReceivabletDto sourceItem,
                                                     AntecipaAnticipationCardReceivableDto parentDetail,
                                                     AntecipaAnticipationCardReceivableListDto parentListItem) {
        if (sourceItem == null) return null;

        ReceivableItemTO item = new ReceivableItemTO();

        //CNPJ - pegar do supplier do detalhe pai
        if (parentDetail.getSupplier() != null && parentDetail.getSupplier().getDocument() != null) {
            item.setCnpj(String.valueOf(parentDetail.getSupplier().getDocument()));
        }

        //Accrediting Institution - pegar do accreditingInstitution
        if (parentDetail.getAccreditingInstitution() != null && parentDetail.getAccreditingInstitution().getName() != null) {
            item.setAccreditingInstitution(String.valueOf(parentDetail.getAccreditingInstitution().getName()));
        }

        //Installments - assumindo 1 se não especificado
        item.setInstallments(1);

        //InstallmentValue - valor da parcela
        if (sourceItem.getSelectedAmount() != null) {
            item.setInstallmentValue(BigDecimal.valueOf(sourceItem.getSelectedAmount()));
        }

        //FeePercentage - effectiveRate
        if (sourceItem.getEffectiveRate() != null) {
            item.setFeePercentage(BigDecimal.valueOf(sourceItem.getEffectiveRate()));
        }

//        if (parentListItem != null && parentListItem.getAnticipatedDiscount() != null) {
//            item.setDiscountValue(BigDecimal.valueOf(parentListItem.getAnticipatedDiscount()));
//        } else if (parentListItem.getAnticipatedDiscount() != null){
//            item.setDiscountValue(BigDecimal.valueOf(parentListItem.getAnticipatedDiscount()));
//        } else {
//            item.setDiscountValue(BigDecimal.ZERO);
//        }

        //DiscountValue - desconto de antecipação
        if (parentListItem.getAnticipatedDiscount() != null) {
            item.setDiscountValue(BigDecimal.valueOf(parentListItem.getAnticipatedDiscount()));
        } else {
            item.setDiscountValue(BigDecimal.ZERO);
        }

        if (parentDetail.getReceivedAmount() != null) {
            item.setNetValue(BigDecimal.valueOf(parentDetail.getReceivedAmount()));
        } else if (sourceItem.getNetValue() != null) {
            item.setNetValue(BigDecimal.valueOf(sourceItem.getNetValue()));
        } else {
            item.setNetValue(BigDecimal.ZERO);
        }

//        if (parentDetail.getReceivedAmount() != null) {
//            item.setNetValue(BigDecimal.valueOf(parentDetail.getReceivedAmount()));
//        }

        return item;
    }

    private HistoryResponseTO createEmptyHistoryResponse(Integer pageSize) {
        HistoryResponseTO response = new HistoryResponseTO();
        response.setItems(new ArrayList<>());
        response.setNextPage(null);
        response.setPageSize(pageSize != null ? pageSize : 10);
        return response;
    }




    private static int countReceivables(AntecipaAnticipationCardReceivableDto detail) {
        if (detail == null) return 0;
        int anticipated = sizeOf(detail.getAnticipatedItems());
        int noAnticipated = sizeOf(detail.getNotAnticipatedItems());
        return anticipated + noAnticipated;
    }

    private static int sizeOf(JsonNullable<? extends List<?>> maybeList) {
        return (maybeList != null && maybeList.isPresent() && maybeList.get() != null) ? maybeList.get().size() : 0;
    }

    private static LocalDateTime parseToLocalDate(String s) {
        if (s == null || s.isBlank()) return null;
        try {
            return OffsetDateTime.parse(s).toLocalDateTime();
        } catch (DateTimeParseException ignore) {
        }
        try {
            return LocalDateTime.parse(s);
        } catch (DateTimeParseException ignore) {
        }
        try {
            return LocalDate.parse(s).atStartOfDay();
        } catch (DateTimeParseException ignore) {
        }

        return null;
    }

    private Agreement getUserAgreement() {
        return this.agreementRepository.getUserAgreement()
                .orElseThrow(() -> new ConflictException("3"));
    }

}
