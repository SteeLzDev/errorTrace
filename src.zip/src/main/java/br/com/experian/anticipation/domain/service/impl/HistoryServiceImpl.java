package br.com.experian.anticipation.domain.service.impl;

import br.com.experian.anticipation.domain.constant.HistoryStatusMapping;
import br.com.experian.anticipation.domain.exception.ConflictException;
import br.com.experian.anticipation.domain.model.Agreement;
import br.com.experian.anticipation.domain.model.HistoryItem;
import br.com.experian.anticipation.domain.model.HistoryResponse;
import br.com.experian.anticipation.domain.repository.AgreementRepository;
import br.com.experian.anticipation.domain.service.HistoryService;
import br.com.experian.anticipation.infrastructure.integration.feign.client.antecipa.AntecipaClient;
import br.com.experian.observability.annotation.LogMethod;
import br.com.experian.swagger.antecipa.model.AntecipaAnticipationCardReceivableDto;
import br.com.experian.swagger.antecipa.model.AntecipaAnticipationCardReceivableListDto;
import br.com.experian.swagger.antecipa.model.AntecipaAnticipationCardReceivableListDtoPagedCollectionItems;
import br.com.experian.swagger.anticipation.model.AnticipationDetailResponseTO;
import br.com.experian.swagger.anticipation.model.AnticipationHistoryItemTO;
import br.com.experian.swagger.anticipation.model.AnticipationHistoryResponseTO;
import lombok.extern.log4j.Log4j2;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Log4j2
public class HistoryServiceImpl implements HistoryService {


    private final AntecipaClient antecipaClient;
    private final AgreementRepository agreementRepository;
    private final String authToken;

    public HistoryServiceImpl(AntecipaClient antecipaClient,
                              AgreementRepository agreementRepository,
                              String authToken) {
        this.antecipaClient = antecipaClient;
        this.agreementRepository = agreementRepository;
        this.authToken = authToken;
    }

    @Override
    @LogMethod
    public Optional<AnticipationHistoryResponseTO> findHistory(String capitalSourceDocument,
                                                               String anticipationDate,
                                                               String statusId,
                                                               String pageId,
                                                               Integer pageSize) {
        Agreement agreement = this.getUserAgreement();
        String supplierDocument = agreement.getNationalRegistrationId();

        log.info("Fetching anticipation history for supplier: {}", supplierDocument);

        try {
            AntecipaAnticipationCardReceivableListDtoPagedCollectionItems externalHistory =
                    this.antecipaClient.getAnticipations("Bearer " + authToken,
                            supplierDocument,
                            capitalSourceDocument,
                            anticipationDate,
                            null,
                            statusId,
                            pageId,
                            pageSize);
            if (externalHistory == null || externalHistory.getItems() == null || externalHistory.getItems().get().isEmpty()) {
                return Optional.empty();
            }

            AnticipationHistoryResponseTO history = convertToHistoryResponse(externalHistory);
            log.info("Successfully retrieved {} anticipation records for supplier: {}",
                    history.getItems().size(), supplierDocument);
            return Optional.empty(history);

        } catch (Exception e) {
            log.error("Error retrieving anticipation history for supplier: {}", supplierDocument, e);
            throw e;
        }

    }


    public HistoryResponse findHistoryPaginated(String capitalSourceDocument,
                                                String anticipationDate,
                                                String statusId,
                                                String pageId,
                                                Integer pageSize) {
        Agreement agreement = this.getUserAgreement();
        String supplierDocument = agreement.getNationalRegistrationId();

        log.info("Fetching paginated anticipation history for supplier: {}", supplierDocument);

        try {
            AntecipaAnticipationCardReceivableListDtoPagedCollectionItems externalHistory =
                    this.antecipaClient.getAnticipations("Bearer " + authToken,
                            supplierDocument,
                            capitalSourceDocument,
                            anticipationDate,
                            anticipationDate,
                            statusId,
                            pageId,
                            pageSize);
            if (externalHistory == null || externalHistory.getItems() == null) {
                log.info("No anticipation history found for supplier: {}", supplierDocument);
                return new HistoryResponse(List.of(), null, pageSize != null ? pageSize : 10);
            }

            List<HistoryItem> historyItems = externalHistory.getItems().stream()
                    .map(this::convertToHistoryItem)
                    .collect(Collectors.toList());

            HistoryResponse response = new HistoryResponse(historyItems,
                    externalHistory.getPageNextId(),
                    pageSize != null ? pageSize : 10);

            log.info("Successfully retieved {} anticipation records for supplier: {}",
                    historyItems.size(), supplierDocument);
            return response;

        } catch (Exception e) {
            log.error("Error retrieving paginated anticipation history for supplier: {}", supplierDocument, e);
            throw e;
        }
    }


    @Override
    @LogMethod
    public Optional<AnticipationDetailResponseTO> findHistoryById(String id) {
        Agreement agreement = this.getUserAgreement();
        String supplierDocument = agreement.getNationalRegistrationId();

        log.info("Fetching anticipation details for supplier: {} and ID: {}", supplierDocument, id);
        try {
            AntecipaAnticipationCardReceivableDto externalDetail =
                    this.antecipaClient.getAnticipationById("Bearer " + authToken, supplierDocument, id);

            if (externalDetail == null) {
                log.info("No anticipation found for supplier: {} and ID: {}", supplierDocument, id);
                return Optional.empty();
            }

            AnticipationDetailResponseTO detail = convertToDetailResponse(externalDetail);
            log.info("Successfully retrieved anticipation details for supplier: {} and ID: {}", supplierDocument, id);
            return Optional.of(detail);
        } catch (Exception e) {
            log.error("Error retrieving anticipation details for supplier: {} and ID: {}", supplierDocument, id, e);
            throw e;
        }
    }

    private HistoryItem convertToHistoryItem(AntecipaAnticipationCardReceivableListDto externalItem) {
        HistoryItem item = new HistoryItem();
        item.setId(String.valueOf(externalItem.getId()));


        if (externalItem.getCreatedAt() != null) {
            item.setRequestDate(externalItem.getCreatedAt().toLocalDate());
        }

        if (externalItem.getC() != null) {
            item.setStatus(HistoryStatusMapping.mapFromExternalStatusId(externalItem.getStatusId()));
        }
        if (externalItem.getReceivedAmount() != null) {
            item.setRequestedValue(BigDecimal.valueOf(externalItem.getReceivedAmount()));
        }
        return item;
    }

    private AnticipationHistoryResponseTO convertToHistoryResponse (AntecipaAnticipationCardReceivableListDtoPagedCollectionItems externalHistory) {
        AnticipationHistoryResponseTO response = new AnticipationHistoryResponseTO();

        return response;
    }



    private AnticipationDetailResponseTO convertToDetailResponse(AntecipaAnticipationCardReceivableDto
                                                                         externalHistory) {
        AnticipationDetailResponseTO response = new AnticipationDetailResponseTO();
        if (externalHistory.getId() != null) {
            List<AnticipationHistoryItemTO> items = externalHistory.getId().stream()
                    .map(this::convertToHistoryItemTO)
                    .collect(Collectors.toList());
            response.setId(items);
        }
        return response;
    }


    private Agreement getUserAgreement() {
        return this.agreementRepository.getUserAgreement()
                .orElseThrow(() -> new ConflictException("3"));
    }

}
