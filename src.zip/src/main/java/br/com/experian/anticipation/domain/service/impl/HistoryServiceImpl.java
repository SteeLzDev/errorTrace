package br.com.experian.anticipation.domain.service.impl;

import br.com.experian.anticipation.domain.client.AccountClient;
import br.com.experian.anticipation.domain.client.RegistrationClient;
import br.com.experian.anticipation.domain.constant.HistoryStatusMapping;
import br.com.experian.anticipation.domain.exception.ConflictException;
import br.com.experian.anticipation.domain.model.Agreement;
import br.com.experian.anticipation.domain.port.AuthenticationPort;
import br.com.experian.anticipation.domain.repository.AgreementRepository;
import br.com.experian.anticipation.domain.service.HistoryService;
import br.com.experian.anticipation.infrastructure.integration.feign.client.antecipa.AntecipaClient;
import br.com.experian.observability.annotation.LogMethod;
import br.com.experian.swagger.antecipa.model.*;
import br.com.experian.swagger.anticipation.model.*;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import feign.FeignException;
import lombok.extern.log4j.Log4j2;
import org.openapitools.jackson.nullable.JsonNullable;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;


@Log4j2
public class HistoryServiceImpl implements HistoryService {


    private final AntecipaClient antecipaClient;
    private final AgreementRepository agreementRepository;
    private final AuthenticationPort authenticationPort;
    private final ObjectMapper objectMapper;
    private final AccountClient accountClient;
    private final RegistrationClient registrationClient;

    public HistoryServiceImpl(AntecipaClient antecipaClient,
                              AgreementRepository agreementRepository, AuthenticationPort authenticationPort, ObjectMapper objectMapper, AccountClient accountClient,
                              RegistrationClient registrationClient) {
        this.antecipaClient = antecipaClient;
        this.agreementRepository = agreementRepository;
        this.authenticationPort = authenticationPort;
        this.objectMapper = objectMapper;
        this.accountClient = accountClient;
        this.registrationClient = registrationClient;

    }


    @Override
    @LogMethod
    public Optional<HistoryResponseTO> findHistoryWithReceivables(String capitalSourceDocument,
                                                                  String startAnticipationDate,
                                                                  String endAnticipationDate,
                                                                  String statusId,
                                                                  String pageId,
                                                                  Integer pageSize) {
        Agreement agreement = this.getUserAgreement();
        log.info("Fetching anticipation history with receivables for supplier: {}", agreement.getNationalRegistrationId());


        try {
            String token = "Bearer " + authenticationPort.getValidToken();

            AntecipaAnticipationCardReceivableListDtoPagedCollectionItems pagedResponse =
                    antecipaClient.getAnticipations(token, agreement.getNationalRegistrationId(),
                            capitalSourceDocument,
                            startAnticipationDate,
                            endAnticipationDate,
                            statusId,
                            pageId,
                            pageSize);
            List<AntecipaAnticipationCardReceivableListDto> externalItems = extractItems(pagedResponse);

            if (externalItems.isEmpty()) {
                log.info("No anticipation history for supplier: {}", agreement);
                return Optional.empty();
            }

            List<HistoryItemTO> historyItems = buildHistoryItems(externalItems, agreement.getNationalRegistrationId(), token);

            HistoryResponseTO response = new HistoryResponseTO();
            response.setItems(historyItems);
            response.setNextPage(null);
            response.setPageSize(pageSize != null ? pageSize : 10);
            log.info("Successfully retrieved {} anticipation records with receivables for supplier: {}", historyItems.size(), agreement.getNationalRegistrationId());
            return Optional.of(response);
        } catch (Exception e) {
            log.error("Error fetching anticipation history for supplier: {}: {}", agreement.getNationalRegistrationId(), e.getMessage(), e);
            return Optional.empty();
        }
    }

    private List<HistoryItemTO> buildHistoryItems(List<AntecipaAnticipationCardReceivableListDto> externalItems,
                                                  String supplierDocument,
                                                  String token) {
        List<HistoryItemTO> historyItems = new ArrayList<>();

        for (AntecipaAnticipationCardReceivableListDto ext : externalItems) {
            HistoryItemTO item = createHistoryItem(ext, supplierDocument, token);
            historyItems.add(item);
        }
        return historyItems;
    }

    private HistoryItemTO createHistoryItem(AntecipaAnticipationCardReceivableListDto ext, String supplierDocument, String token) {

        HistoryItemTO item = new HistoryItemTO();


        String id = extractId(ext);
        item.setId(id);


        setRequestDate(item, ext);


        setStatus(item, ext);


        setReceivablesData(item, id, supplierDocument, token, ext);

        return item;
    }


    private String extractId(AntecipaAnticipationCardReceivableListDto ext) {
        if (ext.getId() != null && ext.getId().isPresent()) {
            return String.valueOf(ext.getId().get());
        }
        return null;
    }


    private void setRequestDate(HistoryItemTO item, AntecipaAnticipationCardReceivableListDto ext) {
        if (ext.getCreatedAt() != null) {
            LocalDateTime ldt = parseToLocalDate(ext.getCreatedAt().toString());
            if (ldt != null) {
                String formattedDate = ldt.toLocalDate().format(DateTimeFormatter.ISO_LOCAL_DATE);
                item.setRequestDate(LocalDate.parse(formattedDate));
            }
        }
    }

    private void setStatus(HistoryItemTO item, AntecipaAnticipationCardReceivableListDto ext) {
        if (ext.getStatusId() != null) {
            String mappedStatus = HistoryStatusMapping.mapExternalIdToResponseStatus(ext.getStatusId());
            item.setStatus(HistoryItemTO.StatusEnum.valueOf(mappedStatus));
            item.setStatus(HistoryItemTO.StatusEnum.valueOf(mappedStatus));
        }
    }

    private void setReceivablesData(HistoryItemTO item, String id, String supplierDocument,
                                    String token, AntecipaAnticipationCardReceivableListDto ext) {
        if (id != null) {

            try {
                AntecipaAnticipationCardReceivableDto detail =
                        antecipaClient.getAnticipationById(token, supplierDocument, id);


                List<ReceivableItemTO> receivables = processReceivables(detail, ext);
                item.setReceivables(receivables);


                BigDecimal totalNetValue = calculateTotalNetValue(receivables);
                item.setTotalNetValue(totalNetValue);
                item.setReceivablesCount(receivables.size());

            } catch (Exception e) {
                log.warn("Failed to fetch receivables details for ID: {}", id, e);
                setEmptyReceivablesData(item);
            }
        } else {
            setEmptyReceivablesData(item);
        }
    }

    private BigDecimal calculateTotalNetValue(List<ReceivableItemTO> receivables) {
        return receivables.stream()
                .map(ReceivableItemTO::getNetValue)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private void setEmptyReceivablesData(HistoryItemTO item) {
        item.setReceivables(new ArrayList<>());
        item.setTotalNetValue(BigDecimal.ZERO);
        item.setReceivablesCount(0);
    }

    private List<AntecipaAnticipationCardReceivableListDto> extractItems(
            AntecipaAnticipationCardReceivableListDtoPagedCollectionItems pagedResponse) {

        if (pagedResponse == null) return Collections.emptyList();

        var itemsNullable = pagedResponse.getItems();

        Object raw = itemsNullable.get();
        if (!(raw instanceof List<?> rawList) || rawList.isEmpty()) return Collections.emptyList();

        try {
            byte[] bytes = objectMapper.writeValueAsBytes(rawList);
            return objectMapper.readValue(bytes, new TypeReference<>() {
            });

        } catch (Exception e) {
            log.error("Error deserializing items list", e);
            return Collections.emptyList();
        }
    }


    private List<ReceivableItemTO> processReceivables(AntecipaAnticipationCardReceivableDto detail,
                                                      AntecipaAnticipationCardReceivableListDto listItem) {
        List<ReceivableItemTO> receivables = new ArrayList<>();

        if (detail == null) return receivables;

        processAnticipatedItems(detail, listItem, receivables);
        processNoAnticipatedItems(detail, listItem, receivables);

        return receivables;
    }

    private void processAnticipatedItems(AntecipaAnticipationCardReceivableDto detail,
                                         AntecipaAnticipationCardReceivableListDto listItem,
                                         List<ReceivableItemTO> receivables) {

        if (detail.getAnticipatedItems() != null && detail.getAnticipatedItems().isPresent()) {
            List<?> anticipatedItemsObj = detail.getAnticipatedItems().get();
            if (anticipatedItemsObj != null) {

                processReceivablesList(anticipatedItemsObj, detail, listItem, receivables);
            }
        }
    }

    private void processNoAnticipatedItems(AntecipaAnticipationCardReceivableDto detail,
                                           AntecipaAnticipationCardReceivableListDto listItem,
                                           List<ReceivableItemTO> receivables) {
        if (detail.getNotAnticipatedItems() != null && detail.getNotAnticipatedItems().isPresent()) {
            List<?> notAnticipatedItemsObj = detail.getNotAnticipatedItems().get();
            if (notAnticipatedItemsObj != null) {
                processReceivablesList(notAnticipatedItemsObj, detail, listItem, receivables);
            }
        }
    }

    private void processReceivablesList(List<?> itemsList,
                                        AntecipaAnticipationCardReceivableDto detail,
                                        AntecipaAnticipationCardReceivableListDto listItem,
                                        List<ReceivableItemTO> receivables) {
        for (Object itemObj : itemsList) {

            try {
                AntecipaAnticipationCardReceivableItemDto sourceItem = convertToSourceItem(itemObj);
                if (sourceItem != null) {
                    ReceivableItemTO item = convertToReceivableItem(sourceItem, detail, listItem);
                    if (item != null) {
                        receivables.add(item);
                    }
                }
            } catch (Exception e) {
                log.error("Error converting anticipated item to DTO: {}", e.getMessage(), e);
            }
        }
    }

    private AntecipaAnticipationCardReceivableItemDto convertToSourceItem(Object itemObj) {
        if (itemObj instanceof AntecipaAnticipationCardReceivableItemDto) {
            return (AntecipaAnticipationCardReceivableItemDto) itemObj;
        } else if (itemObj instanceof LinkedHashMap) {
            return objectMapper.convertValue(itemObj, AntecipaAnticipationCardReceivableItemDto.class);
        } else {
            log.warn("Unexpected item type in anticipatedItems: {}", itemObj.getClass().getName());
            return null;
        }
    }

    private ReceivableItemTO convertToReceivableItem(AntecipaAnticipationCardReceivableItemDto sourceItem,
                                                     AntecipaAnticipationCardReceivableDto parentDetail,
                                                     AntecipaAnticipationCardReceivableListDto parentListItem) {
        if (sourceItem == null) return null;

        ReceivableItemTO item = new ReceivableItemTO();

        setCnpj(item, parentDetail);
        setAccreditingInstitution(item, parentDetail);
        setBasicReceivableData(item, sourceItem);
        return item;

    }

    private void setCnpj(ReceivableItemTO item, AntecipaAnticipationCardReceivableDto parentDetail) {
        if (parentDetail.getSupplier() != null && parentDetail.getSupplier().getDocument() != null) {
            JsonNullable<String> documentNullable = parentDetail.getSupplier().getDocument();
            if (documentNullable.isPresent()) {
                item.setCnpj(documentNullable.get());
            }
        }
    }

    private void setAccreditingInstitution(ReceivableItemTO item, AntecipaAnticipationCardReceivableDto parentDetail) {

        if (parentDetail.getAccreditingInstitution() != null && parentDetail.getAccreditingInstitution().getName() != null) {
            JsonNullable<String> nameNullable = parentDetail.getAccreditingInstitution().getName();
            if (nameNullable.isPresent()) {
                item.setAccreditingInstitution(nameNullable.get());
            }
        }
    }

    private void setBasicReceivableData(ReceivableItemTO item, AntecipaAnticipationCardReceivableItemDto sourceItem) {


        item.setInstallments(1);


        if (sourceItem.getSelectedAmount() != null) {
            item.setInstallmentValue(BigDecimal.valueOf(sourceItem.getSelectedAmount()));
        }


        if (sourceItem.getEffectiveRate() != null) {
            item.setFeePercentage(BigDecimal.valueOf(sourceItem.getEffectiveRate()));
        }


        if (sourceItem.getDiscount() != null) {
            item.setDiscountValue(BigDecimal.valueOf(sourceItem.getDiscount()));
        } else {
            item.setDiscountValue(BigDecimal.ZERO);
        }

        if (sourceItem.getNetValue() != null) {
            item.setNetValue(BigDecimal.valueOf(sourceItem.getNetValue()));
        } else {
            item.setNetValue(BigDecimal.ZERO);
        }
    }

    private static LocalDateTime parseToLocalDate(String s) {
        if (s == null || s.isBlank()) return null;
        try {
            return OffsetDateTime.parse(s).toLocalDateTime();
        } catch (DateTimeParseException ignore) {
        }
        try {
            return LocalDateTime.parse(s);
        } catch (DateTimeParseException ignore) {
        }
        try {
            return LocalDate.parse(s).atStartOfDay();
        } catch (DateTimeParseException ignore) {

        }

        return null;
    }

    private Agreement getUserAgreement() {
        return this.agreementRepository.getUserAgreement()
                .orElseThrow(() -> new ConflictException("3"));
    }

}
