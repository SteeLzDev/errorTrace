package br.com.experian.anticipation.domain.service.impl;

import br.com.experian.anticipation.domain.exception.ConflictException;
import br.com.experian.anticipation.domain.model.Agreement;
import br.com.experian.anticipation.domain.port.AuthenticationPort;
import br.com.experian.anticipation.domain.repository.AgreementRepository;
import br.com.experian.anticipation.domain.service.HistoryService;
import br.com.experian.anticipation.infrastructure.integration.feign.client.antecipa.AntecipaClient;
import br.com.experian.observability.annotation.LogMethod;
import br.com.experian.swagger.antecipa.model.AntecipaAnticipationCardReceivableDto;
import br.com.experian.swagger.antecipa.model.AntecipaAnticipationCardReceivableListDto;
import br.com.experian.swagger.antecipa.model.AntecipaAnticipationCardReceivableListDtoPagedCollectionItems;
import br.com.experian.swagger.anticipation.model.*;
import lombok.extern.log4j.Log4j2;
import org.openapitools.jackson.nullable.JsonNullable;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Executors;

@Log4j2
public class HistoryServiceImpl implements HistoryService {


    private final AntecipaClient antecipaClient;
    private final AgreementRepository agreementRepository;
    private final AuthenticationPort authenticationPort;

    public HistoryServiceImpl(AntecipaClient antecipaClient,
                              AgreementRepository agreementRepository, AuthenticationPort authenticationPort) {
        this.antecipaClient = antecipaClient;
        this.agreementRepository = agreementRepository;
        this.authenticationPort = authenticationPort;
    }


    @Override
    @LogMethod
    public Optional<AnticipationHistoryResponseTO> findHistoryPaginated(String capitalSourceDocument,
                                                                        String startAnticipationDate,
                                                                        String endAnticipationDate,
                                                                        String statusId,
                                                                        String pageId,
                                                                        Integer pageSize) {
        //Agreement agreement = this.getUserAgreement();
        //String supplierDocument = agreement.getNationalRegistrationId();
        //TODO Temporário - Usar documento fixo para testes, depois voltar com o getUserAgreement
        String supplierDocument = "45181802000183";

        log.info("Fetching paginated anticipation history for supplier: {}", supplierDocument);

        try {
            String token = "Bearer " + authenticationPort.getValidToken();

            AntecipaAnticipationCardReceivableListDtoPagedCollectionItems page =
                    antecipaClient.getAnticipations(token,
                            supplierDocument,
                            capitalSourceDocument,
                            startAnticipationDate,
                            endAnticipationDate,
                            statusId,
                            pageId,
                            pageSize);

            List<AntecipaAnticipationCardReceivableListDto> externalItems = page != null && page.getItems() != null ? page.getItems().get() : List.of();
            if (externalItems == null || externalItems.isEmpty()) {
                log.info("No anticipation history found for supplier: {}", supplierDocument);
                return Optional.empty();
            }
            List<AnticipationHistoryItemTO> historyItems = new ArrayList<>(externalItems.size());
            try (var exec = Executors.newVirtualThreadPerTaskExecutor()) {
                var futures = externalItems.stream().map(ext -> exec.submit(() -> {
                    AnticipationHistoryItemTO item = new AnticipationHistoryItemTO();

                    //id
                    String id = ext.getId() != null ? String.valueOf(ext.getId()) : null ;
                        item.setId(id);


                    //requestDate (YYY-MM-DD) a partir de createdAt
                    if (ext.getCreatedAt() != null) {
                        final LocalDateTime ldt = parseToLocalDate(ext.getCreatedAt().toString());
                        if (ldt != null) item.setRequestDate(LocalDate.parse(ldt.toLocalDate().toString()));

                    }
                    //status mapa para semantica
                    item.setStatus(AnticipationHistoryItemTO.StatusEnum.valueOf(mapStatusForList(ext.getStatusId())));

                    //RequestedAmount = selectedAmount do parceiro
                    if (ext.getSelectedAmount() != null) {
                        item.setRequestedAmount(BigDecimal.valueOf(ext.getSelectedAmount()));
                    }

                    //ReceivablesCount -> somatório (anticipated + noAnticipated) do detalhe
                    int count = 0;
                    if (id != null) {
                        AntecipaAnticipationCardReceivableDto detail =
                                antecipaClient.getAnticipationById(token, supplierDocument, id);
                        count = countReceivables(detail);

                        item.setReceivablesCount(count);
                    }

                    return item;

                })).toList();

                for (var f : futures) externalItems.add(f.get());

            } catch (Exception e) {
                log.warn("Parallel detail fetch failed, falling back to sequential processing", e);
                externalItems.clear();
                for (var ext : externalItems) {
                    AnticipationHistoryItemTO item = new AnticipationHistoryItemTO();
                    String id = ext.getId() != null ? String.valueOf(ext.getId()) : null;
                    item.setId(id);
                    if (ext.getCreatedAt() != null) {
                        final LocalDateTime ldt = parseToLocalDate(ext.getCreatedAt().toString());
                        if (ldt != null) item.setRequestDate(LocalDate.parse(ldt.toLocalDate().toString()));
                    }
                    item.setStatus(AnticipationHistoryItemTO.StatusEnum.valueOf(mapStatusForList(ext.getStatusId())));
                    if (ext.getSelectedAmount() != null)
                    item.setRequestedAmount(BigDecimal.valueOf(ext.getSelectedAmount()));
                }
                int count = 0;
                if (id != null) {
                    AntecipaAnticipationCardReceivableDto detail =
                            antecipaClient.getAnticipationById(token, supplierDocument, id);

                }
            }


            AnticipationHistoryResponseTO response = new AnticipationHistoryResponseTO();
            response.setItems(historyItems);
            //se o wrapper do parceiro tiver nextPage/pageNextId, preencher aqui
            response.setNextPage(extractNextPageId(page));
            response.setPageSize(pageSize != null ? pageSize : 10);

            log.info("Sucessfully retrieved {} anticipation records for supplier: {}", historyItems.size(), supplierDocument);
            return Optional.of(response);

        } catch (Exception e) {
            log.error("Error fetching anticipation history for supplier: {}", supplierDocument, e);
            return Optional.empty();
        }
    }

    @Override
    @LogMethod
    public Optional<AnticipationDetailResponseTO> findHistoryDetailById(String supplierDocument, String id, Integer pageSize) {

        String token = "Bearer " + authenticationPort.getValidToken();

        AntecipaAnticipationCardReceivableDto externalDetail =
                antecipaClient.getAnticipationById(token, supplierDocument, id);

        if (externalDetail == null)
            return Optional.empty();



        AnticipationDetailResponseTO detailResponse = new AnticipationDetailResponseTO();
        detailResponse.setId(externalDetail.getId() != null && externalDetail.getId().isPresent() ? String.valueOf(externalDetail.getId().get()) : id);
        detailResponse.setItems(toDetailItems(externalDetail));
        detailResponse.setNextPage(null);
        detailResponse.setPageSize(pageSize != null ? pageSize : 10);

        return Optional.of(detailResponse);

    }

    private List<AnticipationDetailItemTO> toDetailItems(AntecipaAnticipationCardReceivableDto externalDetail) {
        List<AnticipationDetailItemTO> list = new ArrayList<>();
    }

    private static int sizeOfList(List<?> list) {
        return list == null ?  0: list.size();
    }
    private static int sizeOf(JsonNullable<? extends List<?>> maybe) {
        return (maybe != null && maybe.isPresent() && maybe.get() != null) ? maybe.get().size() : 0;
    }
    private int fetchReceivablesCount(String token, String supplierDocument, String id) {
        var detail = antecipaClient.getAnticipationById(token, supplierDocument, id);

        int anticipated = 0;
        int noAnticipated = 0;

        try {anticipated = sizeOf(detail.getAnticipatedItems()); } catch (Throwable ignore){}
        try {noAnticipated = sizeOf(detail.getNotAnticipatedItems()); } catch (Throwable ignore){}

        return anticipated + noAnticipated;
    }


    private AnticipationHistoryItemTO toHistoryItem(AntecipaAnticipationCardReceivableListDto src) {
        AnticipationHistoryItemTO item = new AnticipationHistoryItemTO();

        if (src.getId() != null && src.getId().isPresent()) {
            item.setId(String.valueOf(src.getId().get()));
        }

        if (src.getCreatedAt() != null) {
            item.setRequestDate(src.getCreatedAt().toLocalDate());
        } else if (src.getPaymentDate() != null && src.getPaymentDate().isPresent()){
            item.setRequestDate(parseToLocalDate(src.getPaymentDate().get()).toLocalDate());
        }

        if (src.getSelectedAmount() != null) {
            item.setRequestedAmount(BigDecimal.valueOf(src.getSelectedAmount()));
        }

        if (src.getStatusId() != null) {
            item.setStatus(AnticipationHistoryItemTO.StatusEnum.valueOf(mapStatusForList(src.getStatusId())));
        }
        item.setReceivablesCount(null);


        return item;
    }

    private String mapStatusForList(Integer externalStatusId) {
        if (externalStatusId == null) return "PENDING";
        return switch (externalStatusId) {
            case 1 -> "REJECTED";
            case 2 -> "CONCLUDED";
            case 3 -> "PARTIALLY_APPROVED";
            case 4 -> "ERROR";
            case 5 -> "ANTICIPABLE";
            default -> "PENDING";
        };
    }

    private static int countReceivables(AntecipaAnticipationCardReceivableDto detail) {
        if (detail == null) return 0;
        int a = detail.getAnticipatedItems() != null ? detail.getAnticipatedItems().get().size() : 0;
        int n = detail.getNotAnticipatedItems() != null ? detail.getNotAnticipatedItems().get().size() : 0;
        return a + n;
    }

    private static LocalDateTime parseToLocalDate(String s) {
        if (s == null || s.isBlank()) return null;
        try {
            return OffsetDateTime.parse(s).toLocalDateTime();
        } catch (DateTimeParseException ignore) {
        }
        try {
            return LocalDateTime.parse(s);
        } catch (DateTimeParseException ignore) {
        }
        try {
            return LocalDate.parse(s).atStartOfDay();
        } catch (DateTimeParseException ignore) {
        }

        return null;
    }

    private List<AntecipaAnticipationCardReceivableListDto> extractItems(
            AntecipaAnticipationCardReceivableListDtoPagedCollectionItems page) {
        if (page == null) return List.of();
        try {
            JsonNullable<List<AntecipaAnticipationCardReceivableListDto>> maybe = page.getItems();
            if (maybe != null && maybe.isPresent() && maybe.get() != null) {
                return maybe.get();
        }
    } catch (Throwable ignore){}

        try {
            List<AntecipaAnticipationCardReceivableListDto> list = page.getItemsDirect();
            if (list != null) return list;
        } catch (Throwable ignore){}

        return List.of();
    }


    private Agreement getUserAgreement() {
        return this.agreementRepository.getUserAgreement()
                .orElseThrow(() -> new ConflictException("3"));
    }

}
