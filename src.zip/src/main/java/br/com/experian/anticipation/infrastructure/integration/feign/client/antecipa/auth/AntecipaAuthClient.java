package br.com.experian.anticipation.infrastructure.integration.feign.client.antecipa.auth;

import br.com.experian.anticipation.domain.dto.AuthenticationResponseDto;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name = "AntecipaAuthClient", url = "${api.antecipa.auth.uri}")
public interface AntecipaAuthClient {

    @PostMapping("/authentication/signin")
    @CircuitBreaker(name = "AntecipaAuthClient")
    @Retry(name = "AntecipaAuthClient")
    AuthenticationResponseDto signin(@RequestHeader("Authorization") String basicAuth);
}