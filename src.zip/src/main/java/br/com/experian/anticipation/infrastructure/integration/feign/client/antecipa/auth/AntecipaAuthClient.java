package br.com.experian.anticipation.infrastructure.integration.feign.client.antecipa.auth;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

@FeignClient(name = "AntecipaAuthClient", url = "${api.antecipa.auth.uri}", configuration = AntecipaAuthConfig.class)
interface AntecipaAuthClient {

    @PostMapping("/authentication/signin")
    AntecipaAuthResponse signin();
}