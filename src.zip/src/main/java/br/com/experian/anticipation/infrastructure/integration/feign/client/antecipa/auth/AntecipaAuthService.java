package br.com.experian.anticipation.infrastructure.integration.feign.client.antecipa.auth;

import br.com.experian.anticipation.domain.dto.AuthenticationResponseDto;
import br.com.experian.anticipation.domain.exception.AuthenticationException;
import br.com.experian.anticipation.domain.port.AuthenticationPort;
import feign.FeignException;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.concurrent.locks.ReentrantLock;

@Log4j2
@Component
public class AntecipaAuthService implements AuthenticationPort {

    private final AntecipaAuthClient authClient;
    private final String basicAuthHeader;
    private final  ReentrantLock lock = new ReentrantLock();

    //Cache token atual
    private volatile AuthenticationResponseDto currentToken;

    public AntecipaAuthService(AntecipaAuthClient authClient,
                               @Value("${api.antecipa.auth.username}")
                                       String username,
                               @Value("${api.antecipa.auth.password}")
                               String password){
        this.authClient= authClient;
        String credentials = username + ":" + password;
        this.basicAuthHeader = "Basic " + java.util.Base64.getEncoder().encodeToString(credentials.getBytes());
        log.info(" Initializing with  Basic Auth header");
    }

    @Override
    public String getValidToken(){
        //Verificação rápida sem lock
        if(isCurrentTokenValid()) {
            return currentToken.getAccessToken();
        }
        //verificação com lock para thread safet
        lock.lock();
        try {
            if (isCurrentTokenValid()) {
                return currentToken.getAccessToken();
            }

            log.info("Invalid or expired token, renewing...");
            return refreshToken();
        } finally {
            lock.unlock();
        }
    }

    @Override
    public String refreshToken(){
        lock.lock();
        try {
            log.info("Renewing authentication token...");

            AuthenticationResponseDto newToken = performAuthentication();
            this.currentToken = newToken;

            log.info("Renewed token, expires in {} seconds",
                    newToken.getExpiresIn());
            return newToken.getAccessToken();
        } catch (Exception e) {
            log.error("Error renewing authentication token", e);
            throw new AuthenticationException("API failed authentication", e);
        } finally {
            lock.unlock();
        }
    }

    @Override
    public boolean isTokenValid(){
        return isCurrentTokenValid();
    }

    //Realiza chamada de autenticação na API
    private AuthenticationResponseDto performAuthentication(){
        try {
            log.debug("Performing signin in the authentication API...");

            AuthenticationResponseDto response = authClient.signin(basicAuthHeader);

            if (response == null || response.getAccessToken() == null) {
                throw new AuthenticationException("Invalid authentication response");
            }

            log.debug("Authentication successful. Token type: {}",
                    response.getTokenType());
            return response;
        } catch (FeignException e) {
            log.error("Authentication call error. Status: {}, Body: {}", e.status(), e.contentUTF8());

            if (e.status() == 401) {
                throw new AuthenticationException("Invalid authentication credentials", e);
            } else {
                throw new AuthenticationException("Error in communication with authentication service", e);
            }
        }
    }

    //Verifica se token atual é válido
    private boolean isCurrentTokenValid() {
        return currentToken != null &&
                currentToken.getAccessToken() != null &&
                !currentToken.isExpired() &&
                !currentToken.isExpiringSoon();
    }
}