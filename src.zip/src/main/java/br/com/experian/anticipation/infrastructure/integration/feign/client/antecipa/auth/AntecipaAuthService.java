package br.com.experian.anticipation.infrastructure.integration.feign.client.antecipa.auth;

public interface AntecipaAuthService {

    String getToken();
}