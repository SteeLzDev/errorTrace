package br.com.experian.anticipation.domain.service;

import java.util.Set;

public interface OfferService {

    void confirm(Set<String> offerIds);
}
