package br.com.experian.anticipation.domain.service.impl;

import br.com.experian.anticipation.domain.client.AccountClient;
import br.com.experian.anticipation.domain.client.RegistrationClient;
import br.com.experian.anticipation.domain.exception.ConflictException;
import br.com.experian.anticipation.domain.model.Agreement;
import br.com.experian.anticipation.domain.port.AuthenticationPort;
import br.com.experian.anticipation.domain.repository.AgreementRepository;
import br.com.experian.anticipation.domain.service.SimulationService;
import br.com.experian.anticipation.infrastructure.integration.feign.client.antecipa.AntecipaClient;
import br.com.experian.observability.annotation.LogMethod;
import br.com.experian.pme.security.user.UserSecurityService;
import br.com.experian.swagger.antecipa.model.AntecipaCardReceivableSimulationAnticipationViewModel;
import br.com.experian.swagger.antecipa.model.AntecipaSimulateAnticipationCardReceivableCommandViewModel;
import br.com.experian.swagger.anticipation.model.SimulationRequestTO;
import br.com.experian.swagger.anticipation.model.SimulationResponseTO;
import lombok.extern.log4j.Log4j2;

import java.util.List;
import java.util.Optional;


@Log4j2
public class SimulationServiceImpl implements SimulationService {

    private final AntecipaClient antecipaClient;
    private final AgreementRepository agreementRepository;
    private final AuthenticationPort authenticationPort;
    private final AccountClient accountClient;
    private final RegistrationClient registrationClient;
    private final UserSecurityService userSecurityService;

    public SimulationServiceImpl(AntecipaClient antecipaClient,
                                 AgreementRepository agreementRepository,
                                 AuthenticationPort authenticationPort,
                                 AccountClient accountClient,
                                 RegistrationClient registrationClient,
                                 UserSecurityService userSecurityService) {
        this.antecipaClient = antecipaClient;
        this.agreementRepository = agreementRepository;
        this.authenticationPort = authenticationPort;
        this.accountClient = accountClient;
        this.registrationClient = registrationClient;
        this.userSecurityService = userSecurityService;
    }

    @Override
    @LogMethod(LogMethod.LogType.FULL)
    public Optional<SimulationResponseTO> simulate(SimulationRequestTO request) {
        Agreement agreement = getUserAgreement();
        String finalUsername = userSecurityService.getUserId();
        log.info("Starting card receivable simulation for user: {}", userSecurityService.getUserId());

        //Buscar documento do supplier (CNPJ da empresa)
        //String supplierDocument = userSecurityService.getBusinessRegistration().getDocument;

        //Obter finalUsername do Token
        String finalUserName = userSecurityService.getUserId();

        //Construir payload para Parceiro
        List<AntecipaCardReceivableSimulationAnticipationViewModel> cardReceivables = request.getCardReceivables()
                .stream()
                .map(group -> new AntecipaCardReceivableSimulationAnticipationViewModel()
                        .accreditingInstitutionDocument(group.getAccreditingInstitutionDocument())
                        .ids(group.getIds()))
                .toList();

        AntecipaSimulateAnticipationCardReceivableCommandViewModel command =
                new AntecipaSimulateAnticipationCardReceivableCommandViewModel()
                        .finalUserName(finalUserName)
                        .cardReceivables(cardReceivables);
        return Optional.empty();
    }


    private Agreement getUserAgreement() {
        return this.agreementRepository.getUserAgreement()
                .orElseThrow(() -> new ConflictException("3"));

    }
}
