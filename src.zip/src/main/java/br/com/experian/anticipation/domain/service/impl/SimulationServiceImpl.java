package br.com.experian.anticipation.domain.service.impl;

import br.com.experian.anticipation.domain.client.AccountClient;
import br.com.experian.anticipation.domain.client.RegistrationClient;
import br.com.experian.anticipation.domain.exception.ConflictException;
import br.com.experian.anticipation.domain.model.Agreement;
import br.com.experian.anticipation.domain.port.AuthenticationPort;
import br.com.experian.anticipation.domain.repository.AgreementRepository;
import br.com.experian.anticipation.domain.service.SimulationService;
import br.com.experian.anticipation.infrastructure.integration.feign.adapter.SimulationAdapter;
import br.com.experian.anticipation.infrastructure.integration.feign.client.antecipa.AntecipaClient;
import br.com.experian.observability.annotation.LogMethod;
import br.com.experian.pme.security.user.UserSecurityService;
import br.com.experian.swagger.antecipa.model.AntecipaCardReceivableSimulationAnticipationViewModel;
import br.com.experian.swagger.antecipa.model.AntecipaSimulateAnticipationCardReceivableCommandViewModel;
import br.com.experian.swagger.antecipa.model.AntecipaSimulationAnticipationCardReceivableDto;
import br.com.experian.swagger.anticipation.model.SimulationRequestTO;
import br.com.experian.swagger.anticipation.model.SimulationResponseTO;
import lombok.extern.log4j.Log4j2;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@Log4j2
public class SimulationServiceImpl implements SimulationService {

    private String capitalSourceDocument;
    private final AntecipaClient antecipaClient;
    private final AgreementRepository agreementRepository;
    private final AuthenticationPort authenticationPort;
    private final AccountClient accountClient;
    private final RegistrationClient registrationClient;
    private final UserSecurityService userSecurityService;

    public SimulationServiceImpl(String capitalSourceDocument, AntecipaClient antecipaClient,
                                 AgreementRepository agreementRepository,
                                 AuthenticationPort authenticationPort,
                                 AccountClient accountClient,
                                 RegistrationClient registrationClient,
                                 UserSecurityService userSecurityService) {
        this.capitalSourceDocument = capitalSourceDocument;
        this.antecipaClient = antecipaClient;
        this.agreementRepository = agreementRepository;
        this.authenticationPort = authenticationPort;
        this.accountClient = accountClient;
        this.registrationClient = registrationClient;
        this.userSecurityService = userSecurityService;
    }

    @Override
    @LogMethod(LogMethod.LogType.FULL)
    public Optional<SimulationResponseTO> simulate(SimulationRequestTO request) {
        Agreement agreement = getUserAgreement();
        String finalUsername = userSecurityService.getUserId();
        String bearerToken = "Bearer " + authenticationPort.getValidToken();
        log.info("Starting card receivable simulation for supplier: {} with finalUsername: {}", agreement.getNationalRegistrationId(), finalUsername);

        AntecipaSimulateAnticipationCardReceivableCommandViewModel antecipaRequest =
                new AntecipaSimulateAnticipationCardReceivableCommandViewModel();
        antecipaRequest.setFinalUserName(finalUsername);

        antecipaRequest.setCapitalSourceDocument(this.capitalSourceDocument);

        //Converter receivables do local para formato do parceiro
        List<AntecipaCardReceivableSimulationAnticipationViewModel> cardReceivables = new ArrayList<>();
        if (request.getCardReceivables() != null) {
            for (var receivableGroup : request.getCardReceivables()) {
                AntecipaCardReceivableSimulationAnticipationViewModel antecipaReceivable =
                        new AntecipaCardReceivableSimulationAnticipationViewModel();
                antecipaReceivable.setAccreditingInstitutionDocument(
                        receivableGroup.getAccreditingInstitutionDocument());
                antecipaReceivable.setIds(receivableGroup.getIds());
                cardReceivables.add(antecipaReceivable);
            }
        }
        antecipaRequest.setCardReceivables(cardReceivables);

        try {
            //Chamar API parceiro
            List<AntecipaSimulationAnticipationCardReceivableDto> antecipaResponse =
                    antecipaClient.simulate(bearerToken, agreement.getNationalRegistrationId(), antecipaRequest);

            //Verificar se há ofertas disponíveis
            if (antecipaResponse == null || antecipaResponse.isEmpty()) {
                log.info("No Offers available for supplier: {}", agreement.getNationalRegistrationId());
                return Optional.empty();
            }

            //Verificar se alguma instituição tem oferta
            boolean hasOffers = antecipaResponse.stream()
                    .anyMatch(institution -> institution.getOffers()
                            != null && !institution.getOffers().isEmpty());

            if (!hasOffers) {
                log.info("No Offers available for supplier: {}", agreement.getNationalRegistrationId());
                return Optional.empty();
            }

            SimulationResponseTO response = SimulationAdapter.toSimulationResponse(antecipaResponse);

            log.info("Simulation completed successfully for supplier: {}. Total offers: {}", agreement.getNationalRegistrationId(),
                    response.getReceivableOfferIds() != null ? response.getReceivableOfferIds().size() : 0);

            return Optional.of(response);
        } catch (Exception e) {
            log.error("Error during simulation for supplier: {}", agreement.getNationalRegistrationId(), e);
            throw e;
        }
    }


    private Agreement getUserAgreement() {
        return this.agreementRepository.getUserAgreement()
                .orElseThrow(() -> new ConflictException("3"));

    }
}
