package br.com.experian.anticipation.domain.service.impl;

import br.com.experian.anticipation.domain.client.AccountClient;
import br.com.experian.anticipation.domain.client.RegistrationClient;
import br.com.experian.anticipation.domain.exception.ConflictException;
import br.com.experian.anticipation.domain.model.Agreement;
import br.com.experian.anticipation.domain.repository.AgreementRepository;
import br.com.experian.anticipation.domain.service.MarketAvailabilityService;
import br.com.experian.observability.annotation.LogMethod;
import lombok.extern.log4j.Log4j2;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Log4j2
public class MarketAvailabilityServiceImpl implements MarketAvailabilityService {


    private final LocalTime marketOpenTime;
    private final LocalTime marketCloseTime;
    private final List<LocalDate> holidays;
    private final AgreementRepository agreementRepository;
    private final AccountClient accountClient;
    private final RegistrationClient registrationClient;


    public MarketAvailabilityServiceImpl(String holidaysConfig, String openTime,String closeTime,
                                         AgreementRepository agreementRepository,
                                         AccountClient accountClient,
                                         RegistrationClient registrationClient) {

        this.agreementRepository = agreementRepository;
        this.accountClient = accountClient;
        this.registrationClient = registrationClient;
        this.holidays = parseHolidays(holidaysConfig);
        this.marketOpenTime = parseTime(openTime, "09:00");
        this.marketCloseTime = parseTime(closeTime, "15:00");
    }

    @Override
    @LogMethod
    public boolean isMarketAvailable() {
        //valida usuário através do agreement
        validateUserAgreement();

        LocalDate today = LocalDate.now();
        LocalTime now = LocalTime.now();

        log.debug("Checking market availability for date: {} and time: {}", today, now);

        //verifica se é fim de semana
        if (isWeekend(today)) {
            log.info("Market is closed: Weekend ({})", today.getDayOfWeek());
            return false;
        }
        //Verifica se é feriado
        if (isHoliday(today)) {
            log.info("Market is closed: Holiday ({})", today);
            return false;
        }
        //Verifica horário de funcionamento
        if (isOutSideBusinessHours(now)) {
            log.info("Market is closed: Outside business hours (current time: {})", now);
            return false;
        }

        log.info("Market is open and available for operations");
        return true;
    }
    private boolean isWeekend(LocalDate date) {
        DayOfWeek dayOfWeek = date.getDayOfWeek();
        return dayOfWeek == DayOfWeek.SATURDAY || dayOfWeek == DayOfWeek.SUNDAY;
    }

    private boolean isHoliday(LocalDate date) {
        return holidays.contains(date);
    }

    private boolean isOutSideBusinessHours(LocalTime time) {
        return time.isBefore(marketOpenTime) ||
                time.isAfter(marketCloseTime) ||
                time.equals(marketCloseTime);
    }

    private LocalTime parseTime(String timeConfig, String defaultTime) {
        if (timeConfig == null || timeConfig.trim().isEmpty()) {
            log.warn("No time configured, using default: {}", defaultTime);
            return LocalTime.parse(defaultTime, DateTimeFormatter.ofPattern("HH:mm"));
        }
        try {
            return LocalTime.parse(timeConfig.trim(), DateTimeFormatter.ofPattern("HH:mm"));
        } catch (Exception e) {
            log.error("Error parsing time configuration: {}, using default: {}", timeConfig, defaultTime, e);
            return LocalTime.parse(defaultTime, DateTimeFormatter.ofPattern("HH:mm"));
        }
    }

    private List<LocalDate> parseHolidays(String holidaysConfig) {
        if (holidaysConfig == null || holidaysConfig.trim().isEmpty()) {
            log.warn("No holidays configured");
            return List.of();
        }
        try {
            return Arrays.stream(holidaysConfig.split(","))
                    .map(String::trim)
                    .filter(date -> !date.isEmpty())
                    .map(date -> LocalDate.parse(date, DateTimeFormatter.ISO_LOCAL_DATE))
                    .collect(Collectors.toList());

        } catch (Exception e) {
            log.error("Error parsing holidays configuration: {}", holidaysConfig, e);
            return List.of();
        }
    }

    private void validateUserAgreement() {
        Agreement agreement = this.agreementRepository.getUserAgreement()
                .orElseThrow(() -> new ConflictException("3"));
    }


}
