package br.com.experian.anticipation.domain.service;

public interface MarketAvailabilityService {

    boolean isMarketAvailable();


}
