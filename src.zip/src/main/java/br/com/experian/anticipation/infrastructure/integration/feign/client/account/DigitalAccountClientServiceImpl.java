package br.com.experian.anticipation.infrastructure.integration.feign.client.account;

import br.com.experian.anticipation.domain.client.AccountClient;
import br.com.experian.anticipation.infrastructure.integration.feign.constant.Resilience4jConstant;
import feign.FeignException;
import io.github.resilience4j.retry.annotation.Retry;
import org.springframework.stereotype.Service;

@Service
class DigitalAccountClientServiceImpl implements AccountClient {

    private final DigitalAccountClient digitalAccountClient;

    DigitalAccountClientServiceImpl(DigitalAccountClient digitalAccountClient) {
        this.digitalAccountClient = digitalAccountClient;
    }

    @Override
    @Retry(name = Resilience4jConstant.DIGITAL_ACCOUNT)
    public String findNationalRegistrationId(String businessId) {
        try {
            return this.digitalAccountClient.findByBusinessId(businessId)
                    .getCompanyDocument()
                    .getNationalRegistrationId();
        } catch (FeignException ex) {
            throw new DigitalAccountClientException("1", "DIGITAL:businessAccount");
        }
    }
}