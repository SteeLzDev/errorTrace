package br.com.experian.anticipation.infrastructure.integration.feign.client.account;

import br.com.experian.anticipation.domain.client.AccountClient;
import br.com.experian.anticipation.domain.dto.response.UserAccount;
import br.com.experian.anticipation.infrastructure.integration.feign.adapter.DigitalAccountAdapter;
import br.com.experian.anticipation.infrastructure.integration.feign.constant.Resilience4jConstant;
import br.com.experian.observability.annotation.LogMethod;
import feign.FeignException;
import io.github.resilience4j.retry.annotation.Retry;
import org.springframework.stereotype.Service;

@Service
class DigitalAccountClientServiceImpl implements AccountClient {

    private final DigitalAccountClient digitalAccountClient;

    DigitalAccountClientServiceImpl(DigitalAccountClient digitalAccountClient) {
        this.digitalAccountClient = digitalAccountClient;
    }

    @Override
    @LogMethod(LogMethod.LogType.FULL)
    @Retry(name = Resilience4jConstant.DIGITAL_ACCOUNT)
    public UserAccount getMyUserAccount() {
        try {
            return DigitalAccountAdapter.build(this.digitalAccountClient.findMyUserAccount());
        } catch (FeignException ex) {
            throw new DigitalAccountClientException("1", "DIGITAL:getMyUserAccount");
        }
    }
}