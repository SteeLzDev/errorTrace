<a name="readme-top"></a>

<p align="center">
    <img width=200px height=200px src="https://code.experian.local/projects/PMBF/avatar.png" alt="Project logo">
</p>

<div id ="info" align="center">

<h3>@project.name@</h3>

[![Tribe][tribe-shield]][tribe-url]
[![Squad][squad-shield]][squad-url]
[![Gearr][gearr-shield]][gearr-url]
![Version][project-version]
![Java][java-shield]
[![SpringBoot][spring-boot-shield]][spring-boot-url]

[![SonarqubeStatus][sonarqube-status]][sonarqube-status-url]
[![SonarqubeLinesOfCode][sonarqube-lines-of-code]][sonarqube-lines-of-code-url]
[![SonarqubeCoverage][sonarqube-coverage]][sonarqube-coverage-url]
[![SonarqubeBugs][sonarqube-bugs]][sonarqube-bugs-url]
[![SonarqubeVulnerabilities][sonarqube-vulnerabilities]][sonarqube-vulnerabilities-url]
[![SonarqubeCodeSmells][sonarqube-code-smells]][sonarqube-code-smells-url]
[![SonarqubeMaintainability][sonarqube-maintainability]][sonarqube-maintainability-url]

</div>

[tribe-shield]: https://img.shields.io/static/v1?label=tribe&message=pme&color=red
[tribe-url]: https://pages.experian.local/display/TM/Nova+Estrutura+de+Tribos+e+Squads+-+2023
[squad-shield]: https://img.shields.io/static/v1?label=squad&message=gestao-financeira&color=orange
[squad-url]: https://pages.experian.local/pages/viewpage.action?pageId=1062372537
[gearr-shield]: https://img.shields.io/static/v1?label=gearr-id&message=@gearr.id@&color=54d6d0
[gearr-url]: https://experian.service-now.com/now/nav/ui/classic/params/target/cmdb_ci_business_app_list.do%3Fsysparm_query%3Du_application_id%253D@gearr.id@
[project-version]: https://img.shields.io/static/v1?label=project-version&message=@project.version@&color=blue
[java-shield]: https://img.shields.io/badge/java-@maven.compiler.source@-yellow?&logo=openjdk&logoColor=FFFFFF
[spring-boot-shield]: https://img.shields.io/badge/spring-@spring-boot.version@-green?label=spring-boot&logo=spring-boot&logoColor=6DB33F
[spring-boot-url]: https://mvnrepository.com/artifact/org.springframework.boot/spring-boot-starter-parent

[sonarqube-status]: https://sonarqube.devsecops-paas-prd.br.experian.eeca/api/project_badges/measure?project=@project.name@&metric=alert_status&token=@sonar.token@
[sonarqube-status-url]: https://sonarqube.devsecops-paas-prd.br.experian.eeca/dashboard?id=@project.name@
[sonarqube-lines-of-code]: https://sonarqube.devsecops-paas-prd.br.experian.eeca/api/project_badges/measure?project=@project.name@&metric=ncloc&token=@sonar.token@
[sonarqube-lines-of-code-url]: https://sonarqube.devsecops-paas-prd.br.experian.eeca/code?id=@project.name@
[sonarqube-coverage]: https://sonarqube.devsecops-paas-prd.br.experian.eeca/api/project_badges/measure?project=@project.name@&metric=coverage&token=@sonar.token@
[sonarqube-coverage-url]: https://sonarqube.devsecops-paas-prd.br.experian.eeca/component_measures?metric=coverage&id=@project.name@
[sonarqube-bugs]: https://sonarqube.devsecops-paas-prd.br.experian.eeca/api/project_badges/measure?project=@project.name@&metric=bugs&token=@sonar.token@
[sonarqube-bugs-url]: https://sonarqube.devsecops-paas-prd.br.experian.eeca/project/issues?resolved=false&types=BUG&id=@project.name@
[sonarqube-vulnerabilities]: https://sonarqube.devsecops-paas-prd.br.experian.eeca/api/project_badges/measure?project=@project.name@&metric=vulnerabilities&token=@sonar.token@
[sonarqube-vulnerabilities-url]: https://sonarqube.devsecops-paas-prd.br.experian.eeca/project/issues?resolved=false&types=VULNERABILITY&id=@project.name@
[sonarqube-code-smells]: https://sonarqube.devsecops-paas-prd.br.experian.eeca/api/project_badges/measure?project=@project.name@&metric=code_smells&token=@sonar.token@
[sonarqube-code-smells-url]: https://sonarqube.devsecops-paas-prd.br.experian.eeca/project/issues?resolved=false&types=CODE_SMELL&id=@project.name@
[sonarqube-maintainability]: https://sonarqube.devsecops-paas-prd.br.experian.eeca/api/project_badges/measure?project=@project.name@&metric=sqale_rating&token=@sonar.token@
[sonarqube-maintainability-url]: https://sonarqube.devsecops-paas-prd.br.experian.eeca/component_measures?metric=Maintainability&id=@project.name@

---

## 🧐 Sobre
*TODO*

---

## 💻 Pré-requisitos

Antes de começar, verifique se você atendeu aos seguintes requisitos:
* ![OpenJdk][openjdk-shield]
* ![DocumentDB][documentdb-shield]
* ![RabbitMQ][rabbitmq-shield]
* ![Maven][apache-maven-shield]
* ![GitSCM][git-scm-shield]

[openjdk-shield]:       https://img.shields.io/badge/-JDK%20@maven.compiler.source@-white?logo=openjdk&logoColor=white&labelColor=4A4A4A
[documentdb-shield]:    https://img.shields.io/badge/-DocumentDB-white?logo=amazondocumentdb&logoColor=white&labelColor=166BFF
[rabbitmq-shield]:      https://img.shields.io/badge/-RabbitMQ-white?logo=rabbitmq&logoColor=white&labelColor=FF6600
[apache-maven-shield]:  https://img.shields.io/badge/-Maven-white?logo=apache-maven&logoColor=white&labelColor=C71A36
[git-scm-shield]:       https://img.shields.io/badge/-Git-white?logo=git&logoColor=white&labelColor=F05032

---

# Handover

## 1. Solution Briefing
### 1.1. Stakeholders
|   Stakeholders   |             Papel              |              E-mail              |
|:----------------:|:------------------------------:|:--------------------------------:|
| Danilo Rodrigues |      IT Application Owner      | Danilo.Rodrigues@br.experian.com |
|   Odair Junior   | IT Application Secondary Owner |   Odair.Junior@br.experian.com   |
|  Murilo Santos   |         Product Owner          | Murilo.DosSantos@br.experian.com |
| Larisse Oliveira |     Business Product Owner     | Larisse.Oliveira@br.experian.com |
|   Wesley Rosa    |      Head of Development       |   Wesley.Rosa@br.experian.com    |

--- 

### 1.2. Customer Data (VIP/Not-VIP)
*TODO*

--- 

### 1.3. SLA/SLOs
A aplicação não comporta testes de performance por hora, porém sendo uma aplicação que é utilizada pelo cliente, 
em caso de indisponibilidade da aplicação poderá gerar um impacto na não realização ou preenchimento de proposta para 
crédito/emprestimo, portanto poderá haver um impacto financeiro.

--- 

### 1.4. Plataform (Cloud, Open, Mainframe)
O microsserviço @project.name@ é implantado e executado em um cluster EKS dentro da AWS.

* **AWS Account ID** = *535753273025*
* **Conta EEC:** *ec-aws-br-pme-services-prod*
* **AWS EKS Namespace** = *pme-bfm*
* **AWS EKS Application** = *@project.name@*
* **Host POD:** https://@project.name@.pmeinfra-prod.br.experian.eeca/serasaempreendedor/receivables-anticipation/v1
* **Host Apigee:** https://api.serasaexperian.com.br/serasaempreendedor/receivables-anticipation/v1

- [X] Cloud
- [ ] Open
- [ ] Mainframe

--- 

### 1.5. Access Media
- [ ] Site
- [X] Rest Api
- [ ] WebService
- [ ] Socket
- [ ] Websphere MQ
- [ ] Host a Host

--- 

### 1.6. Business Stream
*TODO*

--- 

### 1.7. Capacity
O microsserviço @project.name@ possui **autoscaling** configurado, com os seguintes parâmetros (em PROD):

**resources**:
- limits:
    - cpu: 500m
    - memory: 2Gi
- requests:
    - cpu: 250m
    - memory: 1Gi

**autoscaling**:
- enabled: true
- minReplicas: 2
- maxReplicas: 8
- targetCPUUtilizationPercentage: 80
- targetMemoryUtilizationPercentage: 80

--- 

### 1.8. Environment (UAT & PROD)
| Ambiente | URL                                                                                  |
|----------|--------------------------------------------------------------------------------------|
| UAT      | https://uat-api.serasaexperian.com.br/serasaempreendedor/receivables-anticipation/v1 |
| PROD     | https://api.serasaexperian.com.br/serasaempreendedor/receivables-anticipation/v1     |

Abaixo, estão listadas as URLs dos serviços produtivos que estão relacionados à aplicação @project.name@:

|          Serviço           |          Vertente          |
|:--------------------------:|:--------------------------:|
|  [Veracode][veracode-url]  |          Veracode          |
|   [Grafana][grafana-url]   |      Log Centralizado      |
| [Dynatrace][dynatrace-url] | Dashboard de Monitoramento |

Abaixo, também estão listadas as APIs que são consultadas por essa aplicação:

| API                         | URL                                                                                                                        |
|-----------------------------|----------------------------------------------------------------------------------------------------------------------------|
| DT-IAM-BR                   | https://api.serasaexperian.com.br/security/iam/v1                                                                          |
| DT-BUSINESS-ACCOUNT-BR      | https://api.serasaexperian.com.br/cross-domain/account/v1                                                                  |

---  

## **2. App Details**
### **2.1. Solution Design**
* **APP ID:** @gearr.id@
* **APP NAME:** @project.name@
* **Type:** Logical Application Component
* **Desenho de arquitetura da solução:**

*TODO*

--- 

### **2.2. System Users**
**N/A** - *Não há usuário sistêmico*

--- 

### **2.3. Return Code and Actions**
| API                 | Descrição                                 |
|---------------------|-------------------------------------------|
| PME-Open-Banking-BR | [![Swagger][swagger-shield]][swagger-url] |

--- 

### **2.4. ITSM & Sustain Process**
Caso identifiquem algum desvio relacionados as métricas disponibilizadas e não restabelecimento automático desses
serviços no painel de monitoração ou algum reporte massivo de falhas relacionadas a @project.name@, direcionem o
incidente para o **Assigment group: Brazil MPME - Squad Gestão Financeira (Open Finance)** no ServiceNow. 

De acordo com a criticidade do incidente classificado, utilizem a matriz de escalação para acionar o time de desenvolvimento.

---  

## **3. Escalation Matrix**
|       Quem        |     Contato     |              E-mail              |
|:-----------------:|:---------------:|:--------------------------------:|
| Murilo dos Santos | (11) 97360-7107 | murilo.dossantos@br.experian.com |
|    Wesley Rosa    | (11) 96496-0772 |   wesley.rosa@br.experian.com    |

---  

# Monitoring & Observability

## Availability
Todo o monitoramento de disponibilidade é feito através do Dynatrace e Grafana:

* [![Dynatrace][dynatrace-shield]][dynatrace-url] 
* [![Grafana][grafana-shield]][grafana-url]

---  

## Performance
*Não há testes de performance*

---  

## Synthetic
*N/A* - A ferramenta de simulação de jornada será executada via *Front-end*

---  

## Business View
*[Cora PMExpert][cora-pmexpert-url]*

---  

## Frontend (User Experience)
*N/A* - Esta é uma aplicação Back-End.

---  
## Golden Signals
Por se tratar de um novo produto, ainda não possuímos dados de referência.

---  

[swagger-shield]: https://img.shields.io/badge/-swagger-fff?labelColor=fff&logo=swagger&logoColor=85EA2D
[swagger-url]: https://code.experian.local/projects/PMBF/repos/@project.name@/browse/src/main/resources/PME-Receivables-Anticipation-BR.yaml
[grafana-shield]: https://img.shields.io/badge/-Grafana-fff??style=flat&logo=grafana&logoColor=orange
[grafana-url]: https://spobrgrafa01:3000/d/13ZL-KjIk/webscenarios-serasa-descomplica?orgId=1&refresh=5m&var-group=WebMonitor%2FSites&var-host=Site%20@project.name@
[dynatrace-shield]: https://img.shields.io/badge/-Dynatrace-1496FF?style=flat&logo=dynatrace&logoColor=white
[dynatrace-url]: https://jyx58709.live.dynatrace.com/ui/entity/CLOUD_APPLICATION-567BDC96DF7587BE?gtf=-30m&gf=all&sessionId=zlWCTisr_TLpXb_5
[veracode-url]: https://analysiscenter.veracode.com/auth/index.jsp#HomeAppProfile:10416:2649494
[cora-pmexpert-url]: https://teams.microsoft.com/l/app/f6405520-7907-4464-8f6e-9889e2fb7d8f?templateInstanceId=b3c6c11c-6a67-4b72-a98a-303416455b32&environment=4a5ee7fa-f8e8-e640-8da3-695feafee014